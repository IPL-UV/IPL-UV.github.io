function pinta(a,na)
figure(na),image(64*(a-mini(a))/(maxi(a)-mini(a))),colormap(gray),ax