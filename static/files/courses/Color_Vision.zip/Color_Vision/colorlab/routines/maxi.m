function [m]=maxi(a)

% 'MAXI' calcula max(max(a))
%  USO: m=maxi(a);

m=max(max(a));