function [XYZ]=luv2xyz(C,bbb);

% LUV2XYZ computes the tristimulus values of a set of colours from their lightness, L*,
% and chromatic coordinates u* and v* in CIELUV.
%
% CIELUV is a simple appearance model providing perceptual descriptors (lightness, hue
% and chroma) for related colours (colours in a scene).
%
% In this representation, information about the illumination conditions or, alternatively,
% about the scene, is included in a reference stimulus. Using CIELUV in the standard
% conditions implies that the reference stilulus is a perfect difuser illuminated as the
% test.
% 
% SYNTAX
% ----------------------------------------------------------------------------
% XYZ=luv2xyz(LUV,XYZR)
%
% LUV  = For N colours, Nx3 matrix, containing, in columns, the lightness L*,
%        and the chromaticity coordinates u* and v*.
%
% XYZR = Tristimulus values of the reference stimulus.
%        If the reference stimulus is the same for all the test stimuli, this
%        is a 1x3 matrix. If the reference is different for each tes stimulus
%        XYZR is a Nx3 matrix.
%
% XYZ = Tristimulus values of the test stimuli.
%       For N colours, this is a Nx3 matrix.
%
% RELATED FUNCTIONS
% ----------------------------------------------------------------------------
% xyz2luv, luv2perc, perc2luv
%

s=size(C);
ss=size(bbb);
if ss(1)~=s(1)
   bbb=ones(s(1),1)*bbb(1,:);
end

for i=1:s(1)
   c=C(i,:);
   b=bbb(i,:);
   uo=4*b(1)/(b(1)+15*b(2)+3*b(3));
   vo=9*b(2)/(b(1)+15*b(2)+3*b(3));

   uu=c(2)/(13*c(1))+uo;
   vv=c(3)/(13*c(1))+vo;
   cond=((c(1)+16)^3)/116^3;
   if cond>0.008856
      y=b(2)*cond;
   else
      y=b(2)*c(1)/903.3;
   end
   x=y*9*uu/(4*vv);
   z=(9*y-15*y*vv-x*vv)/(3*vv); 
   XYZ(i,:)=[x y z];
end
