% SCRIPT SESION 8: Constancia del Color en modelos no lineales bajo Cambio de Iluminante
%
%  * Repaso de la relacion entre la reflectancia, iluminante y valores triestimulo
%  * Presentacion de la base de reflectancias Munsell (recubrimiento uniforme
%    del espacio de descriptores perceptuales)
%  - loadrefl, loadrefm, defrefl
%  - loadillu, defillu  (con un azulete sale mejor)
%  - spec2tri
%  * �Los descriptores triest�mulo permanecen constantes bajo cambio de ilum.?
%
%  * Paso a representar el color en un modelo no-lineal (p.ej. CIELab)
%  * C�lculo de los descriptores perceptuales en CIELab (con los dos iluminantes) 
%

startcol

% Cargamos 20 reflectancias Munsell de value (claridad) constante
% (p.ej. V=5) recorriendo los 10 tonos fundamentales y considerando 2 
% cromas (2 y 6).

V=5;       % V puede tomar los valores [0:9]
C=[2 6];   % C puede tomar los valores [0,1,2:2:16]
H=2.50;    % H puede tomar los valores [1.25:1.25:10]
h=1:10;    % h puede tomar los valores [1:10]
descript_reflec=[H*ones(20,1) V*ones(20,1) [C(1)*ones(10,1);C(2)*ones(10,1)] [h';h']];

[reflec, vHVCh]=loadrefm(descript_reflec);

figure(1),plot(reflec(:,1),reflec(:,2:11)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(1))]),axis([350 750 0 0.5])
figure(2),plot(reflec(:,1),reflec(:,12:21)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(2))]),axis([350 750 0 0.5])

% Difusor perfecto para el fondo

ref_fondo=0.8*ones(length(reflec(:,1)),1);

ref=[reflec ref_fondo];

% Definimos o cargamos 2 iluminantes diferentes con la misma luminancia 
% (p.ej. 300 cd/m2)

esp1=defillu(300,1,10,T_l,Yw,3);title('Iluminante 1')
esp2=defillu(300,1,10,T_l,Yw,4);title('Iluminante 2')

% Colores con los iluminantes 1 y 2

[T1,RR1]=spec2tri(T_l,10,ref,esp1);
[T2,RR2]=spec2tri(T_l,10,ref,esp2);

% Representaci�n en el diagrama crom�tico

figure(5),colordgm(T1(1:10,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on,title('Colores iluminante 1 (negro) y 2 (rojo)')
          colordgm(T1([1 10],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on
          colordgm(T1(11:20,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on
          colordgm(T1([11 20],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on
          
figure(5),colordgm(T2(1:10,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2([1 10],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2(11:20,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2([11 20],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0])

figure(10),colorspc(T1([1 10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           colorspc(T1([1:10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           colorspc(T1([11:20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           colorspc(T1([11 20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',1,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           
figure(11),colorspc(T2([1 10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           colorspc(T2([1:10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           colorspc(T2([11:20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           colorspc(T2([11 20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',1,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           
           
% Descriptores triestimulo

tY1=tri2coor(T1,Yw);
tY2=tri2coor(T2,Yw);

lpY1=coor2lp(tY1,1,T_l,Yw);
lpY2=coor2lp(tY2,1,T_l,Yw);

[lpY1 lpY2]

% Descriptores CIELab

lab1=xyz2lab(T1,T1(end,:));
lab2=xyz2lab(T2,T2(end,:));

LhC1=lab2perc(lab1);
LhC2=lab2perc(lab2);

figure(100),plot(lab1(:,2),lab1(:,3),'ko',lab2(:,2),lab2(:,3),'ro'),xlabel('a*'),ylabel('b*')
figure(100),hold on,plot([-35 35],[0 0],'k-'),hold on,plot([0 0],[-40 50],'k-')

% Representacion de las im�genes

[n1,saturat1,Tn1]=tri2val(T1,Yw,tm,a,g,0);
[n2,saturat2,Tn2]=tri2val(T2,Yw,tm,a,g,0);

im=21*ones(5,10+9+2);
im(2,2:2:20)=1:10;
im(4,2:2:20)=11:20;

%figure(6),set(6,'Color',[0 0 0]),colormap([n1(1:end-1,:);0 0 0]),image(im),t=title('Colores Iluminante 1, fondo negro');
%set(t,'Color',[1 1 1])
figure(7),set(7,'Color',n1(end,:)),colormap([n1]),image(im),axis('off'),title('Colores Iluminante 1, fondo reflectante');

%figure(8),set(8,'Color',[0 0 0]),colormap([n2(1:end-1,:);0 0 0]),image(im),t=title('Colores Iluminante 2, fondo negro');
%set(t,'Color',[1 1 1])
figure(9),set(9,'Color',n2(end,:)),colormap([n2]),image(im),axis('off'),title('Colores Iluminante 2, fondo reflectante');


%
% COMPARACION DE LA CONSTANCIA DE TONO Y COLORIDO ANTE CAMBIO DE ILUMINANTE
% (Incluyendo el modelo de Ingling ademas de el de XYZ)
%

ATD1=xyz2atd(T1,5);
ATD2=xyz2atd(T2,5);

BHS1=ATD2PERC(ATD1,5);
BHS2=ATD2PERC(ATD2,5);

figure,plot(lpY1(:,1),lpY2(:,1),'bo',linspace(0,600,10),linspace(0,600,10),'r-'),xlabel('\lambda_d (ilum 1)'),ylabel('\lambda_d (ilum 2)'),title('Comp. Tonos en XYZ')
figure,plot(BHS1(:,2),BHS2(:,2),'bo',linspace(0,2*pi,10),linspace(0,2*pi,10),'r-'),xlabel('h (ilum 1)'),ylabel('h (ilum 2)'),title('Comp. Tonos en ATD')
figure,plot(LhC1(:,2),LhC2(:,2),'bo',linspace(0,2*pi,10),linspace(0,2*pi,10),'r-'),xlabel('h (ilum 1)'),ylabel('h (ilum 2)'),title('Comp. Tonos en Lab')

figure,plot(lpY1(:,2),lpY2(:,2),'bo',linspace(0,1,10),linspace(0,1,10),'r-'),xlabel('P (ilum 1)'),ylabel('P (ilum 2)'),title('Comp. Coloridos en XYZ')
figure,plot(BHS1(:,3),BHS2(:,3),'bo',linspace(0,0.7,10),linspace(0,0.7,10),'r-'),xlabel('C (ilum 1)'),ylabel('C (ilum 2)'),title('Comp. Coloridos en ATD')
figure,plot(LhC1(:,3),LhC2(:,3),'bo',linspace(0,50,10),linspace(0,50,10),'r-'),xlabel('C (ilum 1)'),ylabel('C (ilum 2)'),title('Comp. Coloridos en Lab')

%%% PARES CORRESPONDIENTES

lab1=xyz2lab(T1,T1(end,:));

T2_corresp=lab2xyz(lab1,T2(end,:));

[n2c,saturat2c,Tn2c]=tri2val(T2_corresp,Yw,tm,a,g,0);

figure(12),set(12,'Color',n2c(end,:)),colormap([n2c]),image(im),axis('off'),title('Pares correspondientes a los colores 1 iluminados con el iluminante 2');

figure(13),colordgm(T2(1:10,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2([1 10],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2(11:20,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2([11 20],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0])

hold on,colordgm(T2_corresp(1:10,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on
          colordgm(T2_corresp([1 10],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on
          colordgm(T2_corresp(11:20,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0]),hold on
          colordgm(T2_corresp([11 20],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0 0 0;0 0 0])
          title('Colores bajo cambio de iluminante (rojo) Pares correspondientes (negro)')