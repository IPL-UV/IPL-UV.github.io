function   [y,k] = funcion_chorra(a,b,c)

% FUNCION_CHORRA es una funcion muy util que sirve para sumar y restar los
% argumentos que se le pasan
%
% USO: [y1,y2] = funcion_chorra(x1,x2,x3);
% 
%   Entradas:
%
%      x1 = un escalar
%      x2 = un escalar
%      x3 = un escalar
%
%   Salidas
%
%      y1 = un escalar que contiene el resultado de sumar todas las
%           entradas, es decir y1=x1+x2+x3
%
%      y2 = un escalar que contiene el resultado de restar de la primera entrada
%           (x1) el resto de entradas (x2, x3), es decir y2=x1-x2-x3

y = a+b+c;
k = a-b-c;