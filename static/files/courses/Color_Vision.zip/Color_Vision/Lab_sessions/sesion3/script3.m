% SCRIPT SESION 3: Control y generaci�n de est�mulos
%
%   calibra
%   democal
%   startcol
%   tri2val
%   val2tri
%   true2pal
%   pal2true
%   colormap
%   image
%   tri2coor
%   coor2tri
%   lp2coor
%   coor2lp
%   colordgm
%   colorspc


A=[1 2 3;4 1 2];
P1=[0 0 1;0.7 0 0;1 0 1;0.7 0.7 0];
P2=[0 0 1;0.7 0 0;1 0 1;0.3 0.3 0];

figure(1),colormap(P1),image(A)
figure(2),colormap(P2),image(A)


I(:,:,1)=[0 0.7 1;0.7 0 0.7];
I(:,:,2)=[0 0 0;0 0 0];
I(:,:,3)=[1 0 1;0 1 0];

figure(1),colormap(P),image(A)
figure(2),image(I)


% Ejercicios previos:
%
%   1. Genera una imagen true color (en niveles digitales) como esta:
%
%                B R M
%                R B R
%
%      obten la paleta correspondiente de diferentes formas (cuantiz. paleta)
%      y representa las imagenes resultantes
%

im3(:,:,1)=[0.2 0.8  0.5;0.8 0.2 0.8];
im3(:,:,2)=[0   0.3  0  ;0.3 0   0.3];
im3(:,:,3)=[0.6 0    0.6;0   0.6 0  ];

% Todos los colores
[im,pal]=true2pal(im3);

figure,image(im3)
figure,colormap(pal),image(im)

% Limitando el numero de colores
[im2,pal2]=true2pal(im3,2);

figure,colormap(pal2),image(im2)

% Ejercicios previos:
%
%   2. Genera una imagen indexada (en niveles digitales) como esta:
%
%                G G G
%                G B G
%                G G G
%
%      obten la true color correspondiente
%

pal=[0.5 0.5 0.5;0 0.2 0.5];

im=[1 1 1;1 2 1;1 1 1];
figure,colormap(pal);image(im)

im3=pal2true(im,pal);

% EJERCICIO (sesion 3):
%
%   Genera una imagen que muestre 10 mezclas intermedias entre dos colores
%   complementarios C1 y C2 de cromaticidad fija, cuyas luminancias var�an 
%   uniformemente en los intervalos [0, Ymax] e [Ymax, 0] respectivamente. 
%
%   Representa (1) la imagen, y (2) los colores mezcla en el diagrama cromatico y
%   (3) en el espacio triestimulo (tanto los colores deseados como los que puede 
%   generar el monitor)
%
%   Analiza el significado de los descriptores perceptuales de la
%   colorimetr�a triestimulo (ld,P,Y) de los colores resultantes.
%
%   NOTAS:
%
%      - Trabaja en el espacio CIE XYZ
%      - Haz un script en el que se pueda jugar con las cromaticidades de
%        C1 y C2, y la luminancia Ymax
%

startcol

%[T_l,Yw,Msx]=loadsys;
%[tm,a,g]=loadmon(Msx);

% Colores que vamos a mezclar
k=1;
ld=400:20:600;
P=0.5;     % probar 0.3...
tipo_pur=1;
Ymax=90;

N=10;

for i=1:length(ld)

lpy1=[repmat([ld(i) P],N,1) linspace(0.1,Ymax,N)'];

cc1=lpy1(end,:);
tcc1=lp2coor(cc1,1,T_l,Yw);
Tcc1=coor2tri(tcc1,Yw);
Tcc2=4*(Tcc1*Yw')*[1 1 1]-Tcc1;
tcc2=tri2coor(Tcc2,Yw);
cc2=coor2lp(tcc2,1,T_l,Yw);

lpy2=[repmat([cc2(1) cc2(2)],N,1) linspace(Ymax,0.1,N)'];

ty1=lp2coor(lpy1,tipo_pur,T_l,Yw);
ty2=lp2coor(lpy2,tipo_pur,T_l,Yw);

T1=coor2tri(ty1,Yw);
T2=coor2tri(ty2,Yw);

% Mezcla
Tm=T1+T2;

tym=tri2coor(Tm,Yw);
lpym=coor2lp(tym,tipo_pur,T_l,Yw);

% Fondo
tf=[1/3 1/3 30];
Tf=coor2tri(tf,Yw);

% Imagen
%im=(N+1)*ones(3,N*2+1);
%im(2,2:2:N*2)=1:N;
im=(3*N+1)*ones(7,N*2+1);
im(2,2:2:N*2)=1:N;
im(4,2:2:N*2)=N+1:2*N;
im(6,2:2:N*2)=2*N+1:3*N;


% Paleta de niveles digitales
[nm,saturat,Tm_n]=tri2val([T1;T2;Tm;Tf],Yw,tm,a,g,8);

% Representacion de la imagen
figure(1),clg,colormap(nm),image(im)

% Representacion en el diagrama
figure(2),clg,colordgm(Tm,1,T_l,Yw,'symb','v','sizes(3)',3,'showtriang',{3,tm},'show_numb',1),hold on
      colordgm(Tm_n(21:30,:),1,T_l,Yw,'symb','+','sizes(3)',3,'showtriang',{3,tm},'show_numb',0)
      
k=k+2;      
      
% Representacion en el espacio
figure(3),clg,colorspc(Tm,1,T_l,Yw,'showvectors',1,'symb','v','sizes(3)',3,'showtriang',{3,tm},'show_box',0),hold on
      colorspc(Tm_n,1,T_l,Yw,'showvectors',1,'symb','+','sizes(3)',3,'showtriang',{3,tm},'show_box',2)

% Analisis de los descriptores
[lpym saturat(1:N)]

pause
end

