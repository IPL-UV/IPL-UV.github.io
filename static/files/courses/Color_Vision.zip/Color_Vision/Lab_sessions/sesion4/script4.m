% SCRIPT SESION 4: Cambio de Iluminante
%
%  * Repaso de la relacion entre la reflectancia, iluminante y valores triestimulo
%  * Presentacion de la base de reflectancias Munsell (recubrimiento uniforme
%    del espacio de descriptores perceptuales)
%  - loadrefl, loadrefm, defrefl
%  - loadillu, defillu  (con un azulete sale mejor)
%  - spec2tri
%  * �Los descriptores triest�mulo permanecen constantes bajo cambio de ilum.?
%  * �Se tiene la misma constancia con fondo reflectante que con fondo
%     negro?

startcol

% Cargamos 20 reflectancias Munsell de value (claridad) constante
% (p.ej. V=5) recorriendo los 10 tonos fundamentales y considerando 2 
% cromas (2 y 6).

V=5;       % V puede tomar los valores [0:9]
C=[2 4 6];   % C puede tomar los valores [0,1,2:2:16]
H=5;       % H puede tomar los valores [1.25:1.25:10]
h=1:10;    % h puede tomar los valores [1:10]
descript_reflec=[H*ones(20,1) V*ones(20,1) [C(1)*ones(10,1);C(3)*ones(10,1)] [h';h']];

[reflec, vHVCh]=loadrefm(descript_reflec);

figure(1),plot(reflec(:,1),reflec(:,2:11)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(1))]),axis([350 750 0 0.5])
figure(2),plot(reflec(:,1),reflec(:,12:21)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(2))]),axis([350 750 0 0.5])
%figure(3),plot(reflec(:,1),reflec(:,22:31)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(3))]),axis([350 750 0 0.5])

% Difusor perfecto para el fondo

ref_fondo=0.7*ones(length(reflec(:,1)),1);

ref=[reflec ref_fondo];

% Definimos o cargamos 2 iluminantes diferentes con la misma luminancia 
% (p.ej. 300 cd/m2)

esp1=defillu(300,1,10,T_l,Yw,3);title('Iluminante 1'),axis([380 800 0 11e-3])
%esp2=defillu(300,1,10,T_l,Yw,4);title('Iluminante 2')
esp2=loadillu(300,1,10,T_l,Yw);
figure(4),plot(esp2(:,1),esp2(:,2)),title('Iluminante 2'),axis([380 800 0 11e-3])

% Colores con los iluminantes 1 y 2

[T1,RR1]=spec2tri(T_l,10,ref,esp1);
[T2,RR2]=spec2tri(T_l,10,ref,esp2);

% figure(40),plot(RR1(:,1),RR1(:,9),'k-',RR2(:,1),RR2(:,3),'r-')
% figure(41),plot(RR1(:,1),RR1(:,7),'k-',RR2(:,1),RR2(:,4),'r-')
% 
% [tratra,RR_1_2]=spec2tri(T_l,10,[RR1(:,1) RR1(:,7) RR1(:,4)],T_l(:,[1 3]),300,Yw);
% 
% figure(42),plot(RR_1_2(:,1),RR_1_2(:,2),'k-',RR_1_2(:,1),RR_1_2(:,3),'r-')

% Representaci�n en el diagrama crom�tico

figure(5),colordgm(T1(1:10,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0.4 0 0.4;0 0 0]),hold on,title('Colores iluminante 1 (negro) y 2 (rojo)')
          colordgm(T1([1 10],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0.4 0 0.4;0 0 0]),hold on
          colordgm(T1(11:20,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0.4 0 0.4;0 0 0],'show_numb',1),hold on
          colordgm(T1([11 20],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[0.4 0 0.4;0 0 0]),hold on
          
figure(5),colordgm(T2(1:10,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2([1 10],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0]),hold on
          colordgm(T2(11:20,:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:8,:)',[1 0 0;1 0 0;1 0 0],'show_numb',1),hold on
          colordgm(T2([11 20],:),1,T_l,Yw,'symb','s','sizes(3)',3,'show_lin',1,'showtriang',{3,tm},'linecolors(6:7,:)',[1 0 0;1 0 0])

figure(10),colorspc(T1([1 10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           colorspc(T1([1:10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           colorspc(T1([11:20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           colorspc(T1([11 20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',1,'show_lin',1,'linecolors(6,:)',[0 0 0]),hold on
           
figure(11),colorspc(T2([1 10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           colorspc(T2([1:10],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           colorspc(T2([11:20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',0,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           colorspc(T2([11 20],:)/20,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',5,'showdiag',1,'showtriang',{3,tm},'lim_axis',[0 6 0 5 0 8],'show_box',1,'show_lin',1,'linecolors(6,:)',[1 0 0]),hold on
           
           
% Descriptores triestimulo

tY1=tri2coor(T1,Yw);
tY2=tri2coor(T2,Yw);

lpY1=coor2lp(tY1,1,T_l,Yw);
lpY2=coor2lp(tY2,1,T_l,Yw);

[lpY1 lpY2]

% Representacion de las im�genes

[n1,saturat1,Tn1]=tri2val(T1,Yw,tm,a,g,0);
[n2,saturat2,Tn2]=tri2val(T2,Yw,tm,a,g,0);

im=21*ones(5,10+9+2);
im(2,2:2:20)=1:10;
im(4,2:2:20)=11:20;

figure(6),set(6,'Color',[0 0 0]),colormap([n1(1:end-1,:);0 0 0]),image(im),t=title('Colores Iluminante 1, fondo negro');
set(t,'Color',[1 1 1])
figure(7),set(7,'Color',n1(end,:)),colormap([n1]),image(im),axis('off'),title('Colores Iluminante 1, fondo reflectante');

figure(8),set(8,'Color',[0 0 0]),colormap([n2(1:end-1,:);0 0 0]),image(im),t=title('Colores Iluminante 2, fondo negro');
set(t,'Color',[1 1 1])
figure(9),set(9,'Color',n2(end,:)),colormap([n2]),image(im),axis('off'),title('Colores Iluminante 2, fondo reflectante');

%%%%%%%%%%%%%%%%%%%%%%%% 

lab1=xyz2lab(T1,T1(21,:));
lab2=xyz2lab(T2,T2(21,:));

figure(12),plot(lab1(:,2),lab1(:,3),'ks-')
hold on,plot(lab2(:,2),lab2(:,3),'rs-')

VFF1=xyz2svf(T1,T1(21,:));
VFF2=xyz2svf(T2,T2(21,:));
figure(13),plot(VFF1(:,2),VFF1(:,3),'ks-')
hold on,plot(VFF2(:,2),VFF2(:,3),'rs-')

T2c=svf2xyz(VFF2,T1(21,:));
[n2c,saturat2c,Tn2c]=tri2val(T2c,Yw,tm,a,g,0);

figure(100),set(100,'Color',[0 0 0]),colormap([n2c(1:end-1,:);0 0 0]),image(im),t=title('Colores Iluminante 2 corr, fondo negro');
set(t,'Color',[1 1 1])
figure(101),set(101,'Color',n2c(end,:)),colormap([n2c]),image(im),axis('off'),title('Colores Iluminante 2 corr, fondo reflectante');
