

fs=8000; % la mayor frecuencia es menor de 4000 Hz

    N=200;
    T=N/fs;

% Un ejemplo de escalita de frecuencia sonora

frecs=[262 294 330 349 392 440 494 524]
%frecs=[262 294 330 349 392 440 494]

%for i=round(logspace(2.3,3.5,8)),

for i=[frecs 2*frecs 4*frecs],

    y=sonido(1,i,0.1,fs);
    %sound(y,fs);
    figure,plot(linspace(0,T,N),y(1:N)),xlabel('t (segundos)'),title(['Frecuencia ',num2str(i),' Hz'])
    wavplay(y,fs);
    i,
    pause(0.25),
end

% % Un ejemplo con frecuencias aleatorias
% for i=1:30
%     fre=round(interp1(1:8,logspace(2.3,3.5,8),ceil(8*rand)));
%     wavplay(sonido(rand,fre,rand,fs),fs);
%     i
%     pause(0.3)
% end

startcol

% Cargamos una imagen
im=double(imread('I12.bmp'));

[X,map]=true2pal(im,256);
T=val2tri(map/255,Yw,tm,a,g);
t=tri2coor(T,Yw);
lpY=coor2lp(t,1,T_l,Yw);

% Y si lo pongo en descriptores perceptuales CIELAB...

LAB=xyz2lab(T,[max(T(:,2)) max(T(:,2)) max(T(:,2))]);
LhC=lab2perc(LAB);

figure(1),colormap(map/255),image(X),axis off
figure(2),colormap(map/255),image(X(1:3:end,1:3:end)),axis off


lambda_dominante_color=linspace(380,770,8);


% Relacion tono - frecuencia

angulo_tono_color=linspace(0,2*pi,8);
frecuencia_sonora=logspace(2.3,3.5,8);

alfa=1;
frecuencia_sonora = 200 + ((3162-200)/((2*pi)^alfa))*(angulo_tono_color.^alfa);
plot(angulo_tono_color,frecuencia_sonora,'bo-')

% SONIDOS DE LA PALETA DE COLOR

for i=1:length(lpY(:,1))
    
    fre=round(interp1(lambda_dominante_color(end:-1:1),frecuencia_sonora,abs(lpY(i,1)))); % Frecuencia dependiente del tono
    
    amplit=sqrt(lpY(i,3)/max(lpY(:,3)));  % Amplitud dependiente de la luminancia
    amplit=sqrt(lpY(i,2));                % Amplitud dependiente de la pureza
    duracion=lpY(i,2)*0.6;                % Duracion dependiente de la pureza 

    abs([lpY(i,:)])
    [fre amplit duracion]
    
    lala=sonido(amplit,fre,duracion,fs);
    %sound(lala,fs);
    wavplay(lala,fs);    
    figure(2),colormap(map(i,:)/255),image(1),axis off
    pause(lpY(i,2)*0.7)
    %pause(1)
    %pause
end


% SONIDOS DE LA IMAGEN ESCANEADA LEXICOGRAFICA

IM=X(1:3:end,1:3:end);
[filas,cols]=size(IM);

figure(2),figure(3)

for i=1:8:filas
    for j=1:8:cols
    
    color=IM(i,j);    
        
    fre=round(interp1(lambda_dominante_color(end:-1:1),frecuencia_sonora,abs(lpY(color,1)))); % Frecuencia dependiente del tono
    fre=round(interp1(angulo_tono_color(1:end),frecuencia_sonora,abs(LhC(color,2)))); % Frecuencia dependiente del tono    
    amplit=sqrt(lpY(color,3)/max(lpY(:,3)));  % Amplitud dependiente de la luminancia
    amplit=sqrt(lpY(color,2));                % Amplitud dependiente de la pureza
    duracion=lpY(color,2)*0.6;                % Duracion dependiente de la pureza 
    duracion=0.05;

    %abs([lpY(color,:)])
    %[fre amplit duracion]
    
    lala=sonido(amplit,fre,duracion,fs);
    %sound(lala,fs);
    wavplay(lala,fs);    
    figure(2),clf,colormap(map/255),image(IM),axis off
    hold on,plot(j,i,'sk','markersize',10)
    figure(3),colormap(map(color,:)/255),image(1),axis off
    pause(0.01)
    %pause(lpY(i,2)*0.7)
    %pause(1)
    %pause
    end
end

%
% Vamos a por un arcoiris...
%

% LhC1=[60*ones(20,1) linspace(0,2*pi,20)' 20*ones(20,1)];

LhC1=[];
for luminosidad=[20 30 40 50 60]
    for saturacion=linspace(2,15,4)
        for tono=linspace(0,2*pi,20)
            LhC1=[LhC1;luminosidad tono saturacion];
        end
    end
end

LAB1=perc2lab(LhC1);
T1=lab2xyz(LAB1,[100 100 100]);

figure,colordgm(T1,1,T_l,Yw,'symb','s','sizes(3)',4,'showtriang',{3,tm})

figure,colorspc(T1,1,T_l,Yw,'show_numb',1,'symb','s','sizes(3)',3,'showtriang',{3,tm})

[nn,saturat,Tn]=tri2val(T1,Yw,tm,a,g,8);

im=1:400;
im=reshape(im,20,20);
imm=im';
% MAMON!! si el colormap es mayor que 256 hay que pasar a true color!!
% figure,colormap(nn),image(imm(:,:))

im_true=pal2true(imm,nn);
figure,image(im_true)

for i=1:20
    for j=1:20
    
    color=imm(i,j);    
        
    % Frecuencia dependiente del tono
    fre=round(interp1(angulo_tono_color(1:end),frecuencia_sonora,abs(LhC1(color,2))));
    
    % Amplitud dependiente de la saturacion
    amplit=0.5*LhC1(color,3)/max(LhC1(:,3));           

    % Duracion dependiente de la luminosidad
    duracion=(LhC1(color,1)/max(LhC1(:,1)))*0.3;   % Duracion dependiente de la luminancia 
    % amplitud=1;
    % duracion=0.1;

    %abs([lpY(color,:)])
    %[fre amplit duracion]
    figure(2),clf,image(im_true),axis off
    hold on,plot(j,i,'sk','markersize',10,'color',[1 1 1])
    figure(3),colormap(nn(color,:)),image(1),axis off
    
    lala=sonido(amplit,fre,duracion,fs);
    %sound(lala,fs);
    wavplay(lala,fs);
    pause(0.1)
    %pause(lpY(i,2)*0.7)
    %pause(1)
    %pause
    end
end

%
% Y AHORA PICANDO EN LA IMAGEN...
%

% Necesita
%
%   imm = imagen indexada
%   nn = paleta
%   im_true = imagen true color
%   angulo_tono_color
%   frecuencia_sonora
%   LhC1

% Cargamos una imagen
im=double(imread('arco_iris.bmp'));
[imm,map]=true2pal(im,400);
nn=map/255;
T=val2tri(nn,Yw,tm,a,g);
t=tri2coor(T,Yw);
lpY=coor2lp(t,1,T_l,Yw);
% Y si lo pongo en descriptores perceptuales CIELAB...
LAB=xyz2lab(T,[max(T(:,2)) max(T(:,2)) max(T(:,2))]);
LhC1=lab2perc(LAB);
im_true=pal2true(imm,nn);


figure(2),image(im_true),axis square,axis off

x=1;y=1;
[filas,columnas]=size(imm);
while ((x>=1)&(x<=columnas)) & ((y>=1)&(y<=filas))
    figure(2),[x,y]=ginput(1);
    if ((x>=1)&(x<=columnas)) & ((y>=1)&(y<=filas))
    fila=round(y);
    col=round(x);
    color=imm(fila,col);
    
    % Frecuencia dependiente del tono
    fre=round(interp1(angulo_tono_color(1:end),frecuencia_sonora,abs(LhC1(color,2))));
    
    % Amplitud dependiente de la saturacion
    amplit=0.5*LhC1(color,3)/max(LhC1(:,3));           

    % Duracion dependiente de la luminosidad
    duracion=(LhC1(color,1)/max(LhC1(:,1)))*0.3;   % Duracion dependiente de la luminancia 
    % amplitud=1;
    % duracion=0.1;

    %abs([lpY(color,:)])
    %[fre amplit duracion]
    figure(2),clf,image(im_true),axis square,axis off
    hold on,plot(col,fila,'sk','markersize',10,'color',[1 1 1])
    figure(3),colormap(nn(color,:)),image(1),axis off
    
    lala=sonido(amplit,fre,duracion,fs);
    %sound(lala,fs);
    wavplay(lala,fs);
    pause(0.1)
    end
end
