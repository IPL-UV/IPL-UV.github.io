function y=sonido(a,f,t,fs);

% SONIDO genera una onda de amplitud a, frecuencia f, y duracion t.
%
% y=sonido(a,f,t,fs)

tt=linspace(0,t,t*fs);
y = a*sin(2*pi*f*tt);