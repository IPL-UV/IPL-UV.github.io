% SCRIPT SESION 5: Cambio de base
%
%   * Presentar las ecs. grales de cambio de base
%     - Matriz de cambio de base en funcion de datos de los nuevos
%       primarios  (defsys, chngmtx)
%     - Cambio de base de colores (newbasis)
%     - Nuevas T_l (newconst)
%     - Nuevas Yw (newconst)
%     - Nueva Msx (newconst)
%   * Aplicacion 1: cambio Mxyzlms
%     - Partimos de una matriz de cambio
%     - Calcula las cromaticidades de los nuevos primarios
%     - Calcula las nuevas funciones de igualacion del color
%   * Aplicacion 2: 
%     - genera test dicromatas (iso-luminantes elegir cromaticidades de confusion)
%        - defcolor


startcol

%%%% APLICACION 1

for modelo=5:5;   % Buenos: 1 (V_l a partir de curvas), � 6 (canales oponentes facilmente obtenibles a partir de curvas)
    
TPx=con2xyz([1 0 0;0 1 0;0 0 1],modelo);

Mxyz_lms=inv(TPx');

inv(Mxyz_lms)

tPx=tri2coor(TPx,Yw);
T_l_lms=(Mxyz_lms*(T_l(:,2:4)'))';
T_l_lms=[T_l(:,1) T_l_lms];

figure(1),plot(T_l(:,1),T_l(:,2:4)),title('Func XYZ')
figure(2),plot(T_l_lms(:,1),T_l_lms(:,2:4)),title(['Func LMS, Modelo ',num2str(modelo)])
figure(3),colordgm(TPx,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1),title(['Primarios LMS, Modelo ',num2str(modelo)])

pause
end

colorspc(TPx,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'showvectors',1,'showdiag',1),title(['Primarios LMS, Modelo ',num2str(modelo)])



%%%% APLICACION 2

% Protaaaaan!

    % Pica un punto cualquiera para generar colores indistinguibles a el en
    % LMS
    % 
    % 

    figure(400)
    t=defcolor(T_l,Yw,tm);
    T=coor2tri(t,Yw);
    T_lms=(Mxyz_lms*T')';
    
    porcentaje=50;
    T_lms_confusion=[linspace(T_lms(1)-porcentaje*T_lms(1)/100,T_lms(1)+porcentaje*T_lms(1)/100,10)' T_lms(2)*ones(10,1) T_lms(3)*ones(10,1)];
 
    T_confusion=(inv(Mxyz_lms)*T_lms_confusion')';
    
    figure(5),colordgm(T_confusion,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1),title(['Confusion Protan'])
    
    % Selecciona a pi�on
    
    generables_fondo=input([' Elige las cromaticidades del fondo: '])
    generables_test=input([' Elige las cromaticidades del test: '])    
        
    T_conf_fondo=T_confusion(generables_fondo,:);
    T_conf_test=T_confusion(generables_test,:);    
    
    Ymedia=mean([T_conf_fondo(:,2);T_conf_test(:,2)]);
    Ymin=min([T_conf_fondo(:,2);T_conf_test(:,2)]);
    Ymax=max([T_conf_fondo(:,2);T_conf_test(:,2)]);
    
    factor=0;
    Y_aleat=Ymedia+factor*(Ymax-Ymin)*(rand(10,10)-0.5);
    
      
    t_conf_fondo=tri2coor(T_conf_fondo,Yw);
    t_conf_test=tri2coor(T_conf_test,Yw);
    
    im_total=ones(10,10,3);
    
    im_total(:,:,3)=Y_aleat;
    im_fondo=im_total;
    im_test=im_total;    
    
    for i=1:10
        i
        for j=1:10
            col=ceil(length(generables_fondo)*rand);
            im_fondo(i,j,1)=t_conf_fondo(col,1);
            im_fondo(i,j,2)=t_conf_fondo(col,2);    

            col=ceil(length(generables_test)*rand);            
            im_test(i,j,1)=t_conf_test(col,1);
            im_test(i,j,2)=t_conf_test(col,2);    
            
        end
    end    
    
    mask_test=zeros(10,10,3);
    mask_test(3:4,3:8,1)=ones(2,6);
    mask_test(3:4,3:8,2)=ones(2,6);
    
    mask_test(7:8,3:8,1)=ones(2,6);
    mask_test(7:8,3:8,2)=ones(2,6);

    mask_test(5:6,3:4,1)=ones(2,2);
    mask_test(5:6,3:4,2)=ones(2,2);
    
    mask_fondo=(mask_test==0);
    
    im=mask_test.*im_test+mask_fondo.*im_fondo;
    im(:,:,3)=Y_aleat;
    
    [im_ind,palt]=true2pal(im);
    
    palT=coor2tri(palt,Yw);
    [n,saturat,Tn]=tri2val(palT,Yw,tm,a,g,8);palP=palT;
    
    figure(6),colormap(n),image(im_ind),title('Protan, lo ves?')
    figure(5),hold on
              colordgm(T_conf_fondo,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'linecolors(7,:)',[1 0 0]),hold on
              colordgm(T_conf_test,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'linecolors(7,:)',[0 0 1])

% Deutaaaaan!

    % Pica un punto cualquiera para generar colores indistinguibles a el en
    % LMS
    % 
    % 

    figure(400)
    t=defcolor(T_l,Yw,tm);
    T=coor2tri(t,Yw);
    T_lms=(Mxyz_lms*T')';
    
    porcentaje=50;
    T_lms_confusion=[T_lms(1)*ones(10,1) linspace(T_lms(2)-porcentaje*T_lms(2)/100,T_lms(2)+porcentaje*T_lms(2)/100,10)'  T_lms(3)*ones(10,1)];
 
    T_confusion=(inv(Mxyz_lms)*T_lms_confusion')';
    
    figure(7),colordgm(T_confusion,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1),title(['Confusion Deutan'])
    
    % Selecciona a pi�on
    
    generables_fondo=input([' Elige las cromaticidades del fondo: '])
    generables_test=input([' Elige las cromaticidades del test: '])    
        
    T_conf_fondo=T_confusion(generables_fondo,:);
    T_conf_test=T_confusion(generables_test,:);    
    
    Ymedia=mean([T_conf_fondo(:,2);T_conf_test(:,2)]);
    Ymin=min([T_conf_fondo(:,2);T_conf_test(:,2)]);
    Ymax=max([T_conf_fondo(:,2);T_conf_test(:,2)]);
    
    factor=0;
    Y_aleat=Ymedia+factor*(Ymax-Ymin)*(rand(10,10)-0.5);
    
      
    t_conf_fondo=tri2coor(T_conf_fondo,Yw);
    t_conf_test=tri2coor(T_conf_test,Yw);
    
    im_total=ones(10,10,3);
    
    im_total(:,:,3)=Y_aleat;
    im_fondo=im_total;
    im_test=im_total;    
    
    for i=1:10
        i
        for j=1:10
            col=ceil(length(generables_fondo)*rand);
            im_fondo(i,j,1)=t_conf_fondo(col,1);
            im_fondo(i,j,2)=t_conf_fondo(col,2);    

            col=ceil(length(generables_test)*rand);            
            im_test(i,j,1)=t_conf_test(col,1);
            im_test(i,j,2)=t_conf_test(col,2);    
            
        end
    end    
    
    mask_test=zeros(10,10,3);
    mask_test(3:4,3:8,1)=ones(2,6);
    mask_test(3:4,3:8,2)=ones(2,6);
    
    mask_test(7:8,3:8,1)=ones(2,6);
    mask_test(7:8,3:8,2)=ones(2,6);

    mask_test(5:6,3:4,1)=ones(2,2);
    mask_test(5:6,3:4,2)=ones(2,2);
    
    mask_fondo=(mask_test==0);
    
    im=mask_test.*im_test+mask_fondo.*im_fondo;
    im(:,:,3)=Y_aleat;
    
    [im_ind,palt]=true2pal(im);
    
    palT=coor2tri(palt,Yw);
    [n,saturat,Tn]=tri2val(palT,Yw,tm,a,g,8);palD=palT;
    
    figure(8),colormap(n),image(im_ind),title('Deutan, lo ves?')
    figure(7),hold on
              colordgm(T_conf_fondo,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'linecolors(7,:)',[1 0 0]),hold on
              colordgm(T_conf_test,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'linecolors(7,:)',[0 0 1])

% Tritaaaaan!

    % Pica un punto cualquiera para generar colores indistinguibles a el en
    % LMS
    % 
    % 

    figure(400)
    t=defcolor(T_l,Yw,tm);
    T=coor2tri(t,Yw);
    T_lms=(Mxyz_lms*T')';
   
    
    porcentaje=80;
    T_lms_confusion=[T_lms(1)*ones(10,1) T_lms(2)*ones(10,1) linspace(T_lms(3)-porcentaje*T_lms(3)/100,T_lms(3)+porcentaje*T_lms(3)/100,10)'];
 
    T_confusion=(inv(Mxyz_lms)*T_lms_confusion')';
    
    figure(9),colordgm(T_confusion,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1),title(['Confusion Tritanope'])
    
    % Selecciona a pi�on
    
    generables_fondo=input([' Elige las cromaticidades del fondo: '])
    generables_test=input([' Elige las cromaticidades del test: '])    
        
    T_conf_fondo=T_confusion(generables_fondo,:);
    T_conf_test=T_confusion(generables_test,:);    
    
    Ymedia=mean([T_conf_fondo(:,2);T_conf_test(:,2)]);
    Ymin=min([T_conf_fondo(:,2);T_conf_test(:,2)]);
    Ymax=max([T_conf_fondo(:,2);T_conf_test(:,2)]);
    
    factor=0;
    Y_aleat=Ymedia+factor*(Ymax-Ymin)*(rand(10,10)-0.5);
    
      
    t_conf_fondo=tri2coor(T_conf_fondo,Yw);
    t_conf_test=tri2coor(T_conf_test,Yw);
    
    im_total=ones(10,10,3);
    
    im_total(:,:,3)=Y_aleat;
    im_fondo=im_total;
    im_test=im_total;    
    
    for i=1:10
        i
        for j=1:10
            col=ceil(length(generables_fondo)*rand);
            im_fondo(i,j,1)=t_conf_fondo(col,1);
            im_fondo(i,j,2)=t_conf_fondo(col,2);    

            col=ceil(length(generables_test)*rand);            
            im_test(i,j,1)=t_conf_test(col,1);
            im_test(i,j,2)=t_conf_test(col,2);    
            
        end
    end    
    
    mask_test=zeros(10,10,3);
    mask_test(3:4,3:8,1)=ones(2,6);
    mask_test(3:4,3:8,2)=ones(2,6);
    
    mask_test(7:8,3:8,1)=ones(2,6);
    mask_test(7:8,3:8,2)=ones(2,6);

    mask_test(5:6,3:4,1)=ones(2,2);
    mask_test(5:6,3:4,2)=ones(2,2);
    
    mask_fondo=(mask_test==0);
    
    im=mask_test.*im_test+mask_fondo.*im_fondo;
    im(:,:,3)=Y_aleat;
    
    [im_ind,palt]=true2pal(im);
    
    palT=coor2tri(palt,Yw);
    [n,saturat,Tn]=tri2val(palT,Yw,tm,a,g,8);
    
    figure(10),colormap(n),image(im_ind),title('Tritan, lo ves?')
    figure(9),hold on
              colordgm(T_conf_fondo,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'linecolors(7,:)',[1 0 0]),hold on
              colordgm(T_conf_test,1,T_l,Yw,'symb','s','sizes(3)',8,'showtriang',{3,tm},'show_numb',1,'linecolors(7,:)',[0 0 1])
                                
    