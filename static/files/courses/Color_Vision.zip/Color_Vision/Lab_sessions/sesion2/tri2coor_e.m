function tY=tri2coor_e(T,Yw);


% Descripcion
% -----------
%
% TRI2COOR_E es una funcion erronea que pasa de triest�mulos a coord crom y
% luminancia.
%
%
% Entradas
% --------
%
% Para hacer este c�lculo son necesarios:
%  
%    * Los N vectores triestimulo que queremos transformar 
%      (matriz N*3 -un color en cada fila-).
%
%    * Las unidades tricrom�ticas del sistema de primarios que estemos
%      usando (para el c�lculo de la lumiancia).
%      (matriz 1*3)
%
% Salidas
% -------
%
% El resultado se dar� en una matriz N*3 donde en cada fila haya un color, y las dos primeras columnas
% contengan las coordenadas cromaticas y la �ltima tenga la luminancia.
%
% Sintaxis
% --------
%
% USO: tY=tri2coor_e(T,Yw)

tam=size(T);

N=tam(1);

tY=zeros(N,3);

for i=1:N
    To=T(i,:);
    to=To/sum(To);
    Yo=To*Yw';
    tY(i,:)=[to(1:2) Yo];
end    
