% SCRIPT SESION 2: Propiedades de valores triest�mulo y coord crom�ticas
% (sin colorlab)
%
% Problema:
%
%     Asumiendo que estamos en el espacio CIE XYZ, considera los colores:
%
%          C1, T(C1)=[5 20 15];
%
%          C2, t(C2)=[0.4 0.3]  Y(C2)=30cd/m2
%
%     Halla (valores triestiumulo, coordenadas cromaticas y luminancia) de:
%
%       (1) La superposicion de C1 y C2
%
%       (2) La superposicion de C1 con C3, donde C3 es C2 con el doble de
%           luminancia
%
%       (3) La superposicion de C1 con C4, donde C4 es C2 con la mitad de
%           luminancia
%
%     Representa los resultados en el espacio triestimulo (plot3) y en el
%     diagrama cromatico (plot)
%



Yw=[0 1 0];

T1=input(' Valores triestimulo del color C1 ');
tY1=tri2coor_e(T1,Yw);

tY2=input(' Coordenadas crom�ticas y luminancia del color C2 ');
T2=coor2tri_e(tY2,Yw);

% Como el color T3 ...
T3=2*T2;

% Obtengo las coordenadas aplicando la funcion ...
tY3=tri2coor_e(T3,Yw);

% 
T4=coor2tri_e([tY2(1:2) 0.5*tY2(3)],Yw);

% 
tY4=tri2coor_e(T4,Yw);

Tsuma1=T1+T2;
tYsuma1=tri2coor_e(Tsuma1,Yw);

Tsuma2=T1+T3;
tYsuma2=tri2coor_e(Tsuma2,Yw);

Tsuma3=T1+T4;
tYsuma3=tri2coor_e(Tsuma3,Yw);


plot3([0 T1(1)],[0 T1(2)],[0 T1(3)],'k-*'),axis([0 100 0 100 0 100])
hold on
plot3([0 T3(1)],[0 T3(2)],[0 T3(3)],'g-*')
plot3([0 Tsuma1(1)],[0 Tsuma1(2)],[0 Tsuma1(3)],'r-s')
plot3([0 Tsuma2(1)],[0 Tsuma2(2)],[0 Tsuma2(3)],'g-s')
plot3([0 Tsuma3(1)],[0 Tsuma3(2)],[0 Tsuma3(3)],'b-s')
plot3([0 T2(1)],[0 T2(2)],[0 T2(3)],'r-o'),
plot3([0 T4(1)],[0 T4(2)],[0 T4(3)],'b-v'),
text(T1(1)+1,T1(2)+1,T1(3)+1,'C_1')
text(T2(1)+1,T2(2)+1,T2(3)+1,'C_2')
text(T3(1)+1,T3(2)+1,T3(3)+1,'C_3')
text(T4(1)+1,T4(2)+1,T4(3)+1,'C_4')
text(Tsuma1(1)+1,Tsuma1(2)+1,Tsuma1(3)+1,'C_1+C_2')
text(Tsuma2(1)+1,Tsuma2(2)+1,Tsuma2(3)+1,'C_1+C_3')
text(Tsuma3(1)+1,Tsuma3(2)+1,Tsuma3(3)+1,'C_1+C_4')

xlabel('X'),ylabel('Y'),zlabel('Z')
title('Vectores Triestimulo')

figure,
plot(tY1(1),tY1(2),'k*'),axis([0 0.7 0 0.7])
hold on
plot(tY2(1),tY2(2),'ro')
plot(tY3(1),tY3(2),'g*')
plot(tY4(1),tY4(2),'bv')

plot(tYsuma1(1),tYsuma1(2),'rs')
plot(tYsuma3(1),tYsuma3(2),'bs')
plot(tYsuma2(1),tYsuma2(2),'gs'),axis square,xlabel('x'),ylabel('y'),title('Coordenadas Crom�ticas')
text(tYsuma1(1)+0.002,tYsuma1(2)+0.002,'C_1+C_2')
text(tYsuma2(1)+0.002,tYsuma2(2)+0.002,'C_1+C_3')
text(tYsuma3(1)+0.002,tYsuma3(2)+0.002,'C_1+C_4')



