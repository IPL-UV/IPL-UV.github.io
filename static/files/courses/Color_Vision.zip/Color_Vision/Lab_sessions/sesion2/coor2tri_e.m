function T=coor2tri_e(tY,Yw);

% Descripcion
% -----------
%
% COOR2TRI_E es una funcion erronea que pasa de coord crom y
% luminancia a triestimulos
%
%
% Entradas
% --------
%
% Para hacer este c�lculo son necesarios:
%  
%    * Las N ternas de (t,Y) que queremos transformar 
%      (matriz N*3 -un color en cada fila-).
%
%    * Las unidades tricrom�ticas del sistema de primarios que estemos
%      usando (para el c�lculo de la lumiancia).
%      (matriz 1*3)
%
% Salidas
% -------
%
% El resultado se dar� en una matriz N*3 donde en cada fila haya un color.
%
% Sintaxis
% --------
%
% USO: T=coor2tri_e(tY,Yw)
%

tam=size(tY);

N=tam(1);

T=zeros(N,3);

for i=1:N
    tYo=tY(i,:);

    to=[tYo(1:2) 1-sum(tYo(1:2))];
    Yo=tYo(3);
   
    To=(to/(to*Yw'))*Yo;
    
    T(i,:)=To;
end 