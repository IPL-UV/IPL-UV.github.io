
%
% Este es un SCRIPT en el que voy a usar la FUNCION_CHORRA para resolver un
% problema.
%
% Problema:
%
%    A Pepito, Juanito e Isabelin les dieron 3 caramelos de menta a cada
%    uno. �cuantos caramelos tenian despues de tal concesi�n?

caramelos_pepe=103;
caramelos_juan=3;
caramelos_isa=300;

[caramelos_totales,lala]=funcion_chorra(caramelos_pepe,caramelos_juan,caramelos_isa);

% Solucion

caramelos_totales