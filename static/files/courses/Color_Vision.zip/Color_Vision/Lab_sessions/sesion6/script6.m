% SCRIPT SESION 6: Edicion de los atributos perceptuales triest�mulo de los colores de una imagen
%
%  Atributos perceptuales triestimulo
%     - Luminosidad  ----- Luminancia
%     - Colorido     ----- Pureza
%     - Tono         ----- lambda dominante
%                          (esto no va a funcionar bien por la restricci�n de 
%                           los extremos del espectro -purpuras- y habra que usar 
%                           rotaciones en coordenadas cromaticas).
%
%
%  imread 
%  imwrite
%  cart2pol
%  pol2cart

startcol

% Imagen original 

im=imread('foto2.tif');

% Imagen original (con un numero reducido de colores)
N=20;
[im_i,n]=true2pal(im,N);

% Colores originales
figure(1),colormap(n),image(im_i),title(['Imagen Original (',num2str(N),' colores)'])

T=val2tri(n,Yw,tm,a,g);

figure(2),colordgm(T,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm});title('Colores de la Imagen Original')
div=1;
figure(3),colorspc(T/div,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',3,'showtriang',{3,tm},'lim_axis',[0 128 0 128 0 128]/div,'showdiag',1);title('Colores de la Imagen Original')

% % TOQUETEO DE LA FOTO 
% 
% im=imread('foto.tif');
%
% Imagen original (con un numero reducido de colores)
% N=256;
% [im_i,n]=true2pal(im,N);
% T2=0.6*T;
% t2=tri2coor(T2,Yw);
% lpy2=coor2lp(t2,1,T_l,Yw);
% 
% lpy2(:,2)=0.6*lpy2(:,2);
% t2=lp2coor(lpy2,1,T_l,Yw);
% T2=coor2tri(t2,Yw);
% [n2,saturat,Tn]=tri2val(T2,Yw,tm,a,g,8);
% 
% figure(4),colormap(n2),image(im_i),title(['Imagen 2 Original (',num2str(N),' colores)'])
% figure(5),colordgm(T2,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm});title('Colores 2 de la Imagen Original')
% figure(6),colorspc(T2,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',3,'showtriang',{3,tm});title('Colores 2 de la Imagen Original')
% 
% im2=pal2true(im_i,n2);
% 
% imwrite(im2,'c:\disco_portable\mundo_irreal\jesus\CLASES\colorim\colorimetria_2008\sesion6\foto2.tif');
% imwrite(im_i,n2,'c:\disco_portable\mundo_irreal\jesus\CLASES\colorim\colorimetria_2008\sesion6\foto2.tif');

%
%  EDICION DE LA LUMINOSIDAD
%
%    Sube y baja la luminosidad
%

fact=[0.4 0.6 0.8 1.2 1.4 1.6];

for i=1:length(fact)
    
    T2=fact(i)*T;
    [n2,saturat,Tn]=tri2val(T2,Yw,tm,a,g,8);
    
    figure,colormap(n2),image(im_i),title(['Factor ',num2str(fact(i)),' sobre Y'])
    figure,colordgm(T2,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm});,title(['Factor ',num2str(fact(i)),' sobre Y'])
    figure,colorspc(T2,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',3,'showtriang',{3,tm},'lim_axis',[0 128 0 128 0 128]);,title(['Factor ',num2str(fact(i)),' sobre Y'])
    
end    

pause

%
%  EDICION DEL COLORIDO
%
%    Sube y baja la pureza
%

fact=[0.1 0.2 0.4 0.8 1.2 1.4 1.6];

for i=1:length(fact)
    
    t=tri2coor(T,Yw);
    lpy=coor2lp(t,1,T_l,Yw);
    lpy2=lpy;
    lpy2(:,2)=fact(i)*lpy(:,2);
    t2=lp2coor(lpy2,1,T_l,Yw);
    T2=coor2tri(t2,Yw);
   
    [n2,saturat,Tn]=tri2val(T2,Yw,tm,a,g,8);
    
    figure,colormap(n2),image(im_i),title(['Factor ',num2str(fact(i)),' sobre P_{exc}'])
    figure,colordgm(T2,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm});,title(['Factor ',num2str(fact(i)),' sobre P_{exc}'])
    figure,colorspc(T2,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',3,'showtriang',{3,tm},'lim_axis',[0 128 0 128 0 128]);,title(['Factor ',num2str(fact(i)),' sobre P_{exc}'])
    
end

pause

%
%  EDICION DEL TONO
%
%   Opcion 1
%     Suba y baje la longitud de onda dominante
%
%   Opcion 2
%     Rote las coordenadas cromaticas entorno al blanco, oiga
%

% Opcion 1: Sumemos o restemos nm

suma_nanos=0.5*[-90 -60 -30 30 60 90];

for i=1:length(fact)
    
    t=tri2coor(T,Yw);
    lpy=coor2lp(t,1,T_l,Yw);
    lpy2=lpy;
    lpy2(:,1)=lpy(:,1)+suma_nanos(i);
    t2=lp2coor(lpy2,1,T_l,Yw);
    T2=coor2tri(t2,Yw);
   
    [n2,saturat,Tn]=tri2val(T2,Yw,tm,a,g,8);
    
    figure,colormap(n2),image(im_i),title(['Suma ',num2str(suma_nanos(i)),' nm a \lambda_{d}'])
    figure,colordgm(T2,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm});,title(['Suma ',num2str(suma_nanos(i)),' nm a \lambda_{d}'])
    figure,colorspc(T2,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',3,'showtriang',{3,tm},'lim_axis',[0 128 0 128 0 128]);,title(['Suma ',num2str(suma_nanos(i)),' nm a \lambda_{d}'])
    
end

pause

% Opcion 2: rotacion

num_pasos=20;
suma_angulos=linspace(0,2*pi,num_pasos+2);
suma_angulos=suma_angulos(2:num_pasos+1);

for i=1:length(suma_angulos)
    
    t=tri2coor(T,Yw);
    
    t2=t;
    t2w=t2(:,1:2)-ones(length(t2(:,1)),1)*[1/3 1/3];
    [t2wp_the,t2wp_r]=cart2pol(t2w(:,1),t2w(:,2));
    t2wp_the2=t2wp_the+suma_angulos(i);
    [t2w(:,1),t2w(:,2)]=pol2cart(t2wp_the2,t2wp_r);
    
    t2(:,1:2)=t2w+ones(length(t2(:,1)),1)*[1/3 1/3];
    
    T2=coor2tri(t2,Yw);
   
    [n2,saturat,Tn]=tri2val(T2,Yw,tm,a,g,8);
    
    figure,colormap(n2),image(im_i),title(['Suma ',num2str(suma_angulos(i)),' nm a \lambda_{d}'])
    figure,colordgm(T2,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm});,title(['Suma ',num2str(suma_angulos(i)),' nm a \lambda_{d}'])
    %figure,colorspc(T2,1,T_l,Yw,'showvectors',1,'symb','<','sizes(3)',3,'showtriang',{3,tm},'lim_axis',[0 128 0 128 0 128]);,title(['Suma ',num2str(suma_angulos(i)),' nm a \lambda_{d}'])
    
end