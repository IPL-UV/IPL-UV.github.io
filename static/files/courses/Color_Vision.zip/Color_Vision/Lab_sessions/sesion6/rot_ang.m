function rot_ang(lim_l,lim_purp,lim_p,fact,Nrot,N)

% Un ejemplo de procesado de la apariencia de una foto:
%
% No me gusta el color de las flores: lo voy a cambiar!
%
% Lo voy a hacer segmentando las flores por color y aplicando una rotacion
% (en torno al blanco) a las coordenadas cromaticas de los colores de las flores.

tam_pant=get(0,'ScreenSize');
ancho_pant=tam_pant(3);
alto_pant=tam_pant(4)-40;

startcol

% Cargo la foto de las flores:

%[im3,map] = imread('c:\documents and settings\jesus\mis documentos\mis imagenes\colorimetria\flores.jpg');
%[im3,map] = imread('c:\documents and settings\jesus\mis documentos\mis imagenes\colorimetria\foto_color_1_red.jpg');

%[im3,map] = imread('C:\Documents and Settings\jesus\Mis documentos\im_ag\colorimetria0304\flores.jpg');
[im3,map] = imread('colorim_09.jpg');

% Reduzco el numero de colores para que se vea con claridad lo que hago

[im,map]=true2pal(im3,N);
%im=double(im)+1;
im=im;

% Paso a T, (t,Y), y (l,P,Y)

T=val2tri(map,Yw,tm,a,g);
t=tri2coor(T,Yw);
lp=coor2lp(t,1,T_l,Yw);

Tx=(Msx*T')';
LAB=xyz2lab(Tx,[100 100 100]);
lhC=lab2perc(LAB);

% Reduzco un poco la pureza para no salirme del locus al aplicar la rotacion

lp(:,2)=0.7*lp(:,2);
lp(:,3)=1*lp(:,3);

t=lp2coor(lp,1,T_l,Yw);
T=coor2tri(t,Yw);

% Segmento las flores (selecciono 'los rojos saturados')

col_flores1=[(lp(:,1)>=lim_l(1)) & (lp(:,1)<=lim_l(2))];
col_flores2=[(lp(:,1)>=lim_purp(1)) & (lp(:,1)<=lim_purp(2))];
%.* [(lp(:,2)>=lim_p(1)) & (lp(:,2)<=lim_p(1))];
col_flores=col_flores1.*[  (lp(:,2)>=lim_p(1)) & (lp(:,2)<=lim_p(2))]+col_flores2.*[  (lp(:,2)>=lim_p(1)) & (lp(:,2)<=lim_p(2))];

if sum(col_flores)>0

n_flors=ones(length(t(:,1)),3).*[col_flores col_flores col_flores];
%figure(1),colormap(map),image(im)
%figure(2),colormap(n_flors),image(im)

ind=find(n_flors(:,1)==1);

% Defino los angulos de rotacion y aplico la rotacion en un bucle sobre los
% colores seleccionados

alfa=linspace(0,2*pi-2*pi/Nrot,Nrot);
tw=ones(length(ind),1)*[0.333 0.333];  % Coordenadas del blanco para aplicar la rotacion

k=1;
figura=1;
for i=1:length(alfa)
    v=t(ind,1:2)-tw;
    
    % ROTACION TRADICIONAL
    R=[cos(-alfa(i)) sin(-alfa(i));-sin(-alfa(i)) cos(-alfa(i))];
    vv=R*v';
    tt=vv'+tw;
    
       %  ROTACION USANDO OTRAS FUNCIONES
       %[tecta,radio]=cart2pol(v(:,1),v(:,2));
       %tecta_n=tecta+alfa(i);
       %[vx,vy]=pol2cart(tecta_n,radio);
       %vv=[vx vy];
       % tt=vv+tw;
    
    tt=[tt t(ind,3)];
    
    lhC2=lhC;
    
    %size(lhC)
    %size(tt)
    
    lhC2(ind,:)=[lhC(ind,1) lhC(ind,2)+alfa(i) lhC(ind,3)];
    lab2=perc2lab(lhC2);
    T2=lab2xyz(lab2,[100 100 100]);
    T2=(inv(Msx)*T2')';
    
    % Ahora incremento la luminancia de los colores de las flores resultantes 
    % en funcion de la V_l para obtener un 'arcoiris' mas natural...
    
    lp=coor2lp(tt,1,T_l,Yw);
    for j=1:length(lp(:,1))
        if lp(j,1)>0   % Solo lo aplico a los no-purpuras (para los purpuras no tengo V_l)
           [m,pos]=min(abs(lp(j,1)-T_l(:,1)));
           V_lpos=Yw(1)*T_l(pos,2)+Yw(2)*T_l(pos,3)+Yw(3)*T_l(pos,4);
           tt(j,3)=tt(j,3)+fact*V_lpos*tt(j,3);
        end   
    end    
    
    
    %mean(tt(:,3))
    
    % Y ahora calculo la paleta en valores digitales
    
    TT=coor2tri(tt,Yw);
    [n,saturat,Tn]=tri2val(TT,Yw,tm,a,g,0);
    [n2,saturat2,Tn2]=tri2val(T2(ind,:),Yw,tm,a,g,0);
    TTT=T;
    TTT(ind,:)=TT;
    figure(k),colordgm(TTT,1,T_l,Yw);hold on;colordgm(TTT(ind,:),1,T_l,Yw,'linecolors(7,:)',[1 0 0]);
   % figure(k+1),colordgm(T2,1,T_l,Yw);hold on;colordgm(T2(ind,:),1,T_l,Yw,'linecolors(7,:)',[1 0 0]);    
    set(k,'Position',[(figura-1)*ancho_pant/Nrot 40 ancho_pant/Nrot 0.9*alto_pant/2])
   % set(k+1,'Position',[(figura-1)*ancho_pant/Nrot 40 ancho_pant/Nrot 0.9*alto_pant/2])    
    map_modif=map;
    map_modif(ind,:)=n;
    map_modif2=map;
    map_modif2(ind,:)=n2;
    
    %[mini(im) maxi(im) length(map_modif(:,1))]
    %[mini(map_modif) maxi(map_modif) ]
    im33=pal2true(im,map_modif);
    im332=pal2true(im,map_modif2);    
    %figure(k+1),colormap(map_modif),image(im)
    figure(k+2),imshow(im33,'notruesize')
   % figure(k+3),imshow(im332,'notruesize')    
    set(k+2,'Position',[(figura-1)*ancho_pant/Nrot alto_pant/2 ancho_pant/Nrot 0.9*alto_pant/2])
   % set(k+3,'Position',[(figura-1)*ancho_pant/Nrot alto_pant/2 ancho_pant/Nrot 0.9*alto_pant/2])
    k=k+4;
    figura=figura+1;
end    

else
  
    disp('Has puesto una condiciones muy restrictivas!')
    
end    
