%
% EDICION DEL TONO EN COLORIMETRIA TRIESTIMULO
%

N_rot=6;
N_colores=200;

% % Cambio flores
% lim_l=[590 770];
% lim_purp=[-505 -480];
% lim_p=[0.1 1];
% fact_Vl=1;

% Cambio Taponcillo verde
lim_l=[508 550];
lim_purp=[0 0];
lim_p=[0.1 1];
fact_Vl=1;

% Cambio coronita azul
lim_l=[400 490];
lim_purp=[0 0];
lim_p=[0.1 1];
fact_Vl=1;

% Cambio carita roja
lim_l=[600 770];
lim_purp=[0 0];
lim_p=[0.1 1];
fact_Vl=1;



%% Cambio fondo
%lim_l=[380 508];
%lim_purp=[-565 -535];
%lim_p=[0.1 1];
%fact_Vl=1;


rot_ang(lim_l,lim_purp,lim_p,fact_Vl,N_rot,N_colores);

