%
% Comparaciones Boynton (fisiol) e Ingling (psicof)
%


startcol

%
% funciones de igualacion Ingling(5) y Boynton(6)
%


T_esp=T_l(:,2:4);
ATD_ingling=xyz2atd(T_esp,5);
ATD_boynton=xyz2atd(T_esp,6);
figure(1),plot(T_l(:,1),ATD_ingling(:,1),'k',T_l(:,1),ATD_ingling(:,2),'r',T_l(:,1),ATD_ingling(:,3),'b'),title('Ingling')
figure(2),plot(T_l(:,1),ATD_boynton(:,1),'k',T_l(:,1),ATD_boynton(:,2),'r',T_l(:,1),ATD_boynton(:,3),'b'),title('Boynton')

%
% Locus de igual colorido
%

figure
t1=defcolor(T_l,Yw,tm);
t2=[t1(1:2) 2*t1(3)];

ATD_ing_C1=xyz2atd(coor2tri(t1,Yw),5);
ATD_ing_C2=xyz2atd(coor2tri(t2,Yw),5);

ATD_boin_C1=xyz2atd(coor2tri(t1,Yw),6);
ATD_boin_C2=xyz2atd(coor2tri(t2,Yw),6);

P_ing_1=atd2perc(ATD_ing_C1,5);
P_ing_2=atd2perc(ATD_ing_C2,5);

P_boin_1=atd2perc(ATD_boin_C1,6);
P_boin_2=atd2perc(ATD_boin_C2,6);

%%%% S=M/Q  ->  M=S*Q
N=15;
set_boin_1=[P_boin_1(1)*ones(N,1) linspace(0,2*pi,N)' P_boin_1(3)*ones(N,1)];
set_boin_2=[P_boin_2(1)*ones(N,1) linspace(0,2*pi,N)' P_boin_2(3)*ones(N,1)];

set_ing_1=[P_ing_1(1)*ones(N,1) linspace(0,2*pi,N)' P_ing_1(3)*ones(N,1)];
set_ing_2=[P_ing_2(1)*ones(N,1) linspace(0,2*pi,N)' P_ing_2(3)*ones(N,1)];

set_ATD_ing_1=perc2atd(set_ing_1,5);
set_ATD_ing_2=perc2atd(set_ing_2,5);

set_ATD_boin_1=perc2atd(set_boin_1,6);
set_ATD_boin_2=perc2atd(set_boin_2,6);

set_XYZ_ing_1=atd2xyz(set_ATD_ing_1,1,5);
set_XYZ_ing_2=atd2xyz(set_ATD_ing_2,1,5);
set_XYZ_boin_1=atd2xyz(set_ATD_boin_1,1,6);
set_XYZ_boin_2=atd2xyz(set_ATD_boin_2,1,6);

blanco_boin=atd2xyz([1 0 0],1,6);
blanco_boin=100*blanco_boin/blanco_boin(2);
blanco_ing=atd2xyz([1 0 0],1,5);
blanco_ing=100*blanco_ing/blanco_ing(2);

blanco_ing_atd=perc2atd([ATD_ing_C1(1) ATD_ing_C1(2) 0],5);
blanco_ing_xyz=atd2xyz(blanco_ing_atd,1,5);
blanco_ing_xyz=100*blanco_ing_xyz/blanco_ing_xyz(2);

figure(3),colordgm([set_XYZ_ing_1;blanco_ing],1,T_l,Yw,'symb','s','sizes(3)',5,'showtriang',{3,tm},'linecolors(7,:)',[0.5 0 0])
          hold on,colordgm(set_XYZ_ing_2,1,T_l,Yw,'symb','s','sizes(3)',5,'showtriang',{3,tm},'linecolors(7,:)',[1 0 0]),title('Ingling')

figure(4),colordgm([set_XYZ_boin_1;blanco_boin],1,T_l,Yw,'symb','s','sizes(3)',5,'showtriang',{3,tm},'linecolors(7,:)',[0.5 0 0])
          hold on,colordgm(set_XYZ_boin_2,1,T_l,Yw,'symb','s','sizes(3)',5,'showtriang',{3,tm},'linecolors(7,:)',[1 0 0]),title('Boynton')

[n_ing,saturat,Tn_ing]=tri2val([set_XYZ_ing_1;blanco_ing],Yw,tm,a,g,8);
[n_boin,saturat,Tn_boin]=tri2val([set_XYZ_boin_1;blanco_boin],Yw,tm,a,g,8);
          
im=(N+1)*ones(3,N+N+1);
im(2,2:2:end)=1:N;

figure(5),set(5,'Color',n_ing(end,:)),colormap([n_ing]),image(im),title('Ingling')
figure(6),set(6,'Color',n_boin(end,:)),colormap([n_boin]),image(im),title('Boynton')

% Comprobacion elipses
%%%%%%%%%%%%%%%%%%%%%%%

Tmac=loadcol(T_l,Yw,Msx,1,'macadam.mat');

figure(3),hold on,colordgm(Tmac,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm},'linecolors(7,:)',[0 0 0])
figure(4),hold on,colordgm(Tmac,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm},'linecolors(7,:)',[0 0 0])

% Comprobacion munsell
%%%%%%%%%%%%%%%%%%%%%%

   % Elige iluminantes objetivo y calculo el iluminante mas parecido a
   % los blancos que tengo
       reflec_munsell=loadrefl;
       ILLing=tri2spec(blanco_ing,reflec_munsell,[reflec_munsell(:,1) ones(length(reflec_munsell(:,1)),1)],200,T_l,Yw);
       figure,plot(ILLing(:,1),ILLing(:,2));title('Iluminante para Ingling')

       ILLboin=tri2spec(blanco_boin,reflec_munsell,[reflec_munsell(:,1) ones(length(reflec_munsell(:,1)),1)],200,T_l,Yw);
       figure,plot(ILLboin(:,1),ILLboin(:,2));title('Iluminante para Boynton')
       
       
       
   % Cargo muestras munsell de bajo croma
V=5;       % V puede tomar los valores [0:9]
C=1;   % C puede tomar los valores [0,1,2:2:16]
H=5;       % H puede tomar los valores [1.25:1.25:10]
h=1:10;    % h puede tomar los valores [1:10]
descript_reflec=[H*ones(10,1) V*ones(10,1) [C(1)*ones(10,1)] [h']];

[reflec, vHVCh]=loadrefm(descript_reflec);

ref_fondo=0.7*ones(length(reflec(:,1)),1);
ref=[reflec ref_fondo];

[Tmun_ing,RR1]=spec2tri(T_l,10,ref,ILLing,200,Yw);
[Tmun_boin,RR2]=spec2tri(T_l,10,ref,ILLboin,200,Yw);


figure(3),hold on,colordgm(Tmun_ing,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm},'linecolors(7,:)',[0 0 1])
figure(4),hold on,colordgm(Tmun_boin,1,T_l,Yw,'symb','s','sizes(3)',3,'showtriang',{3,tm},'linecolors(7,:)',[0 0 1])
