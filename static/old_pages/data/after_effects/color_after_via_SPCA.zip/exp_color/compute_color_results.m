%
% COMPUTE COLOR RESULTS
%
% This function computes the axes shown in Figure 9 and the results shown 
% in Figure 10. These figures can be reproduced using:
% ./data/natural_data_color/show_color_data_2.m
% ./exp_color/show_color_results.m
%
% 

clear all

%% ADDING PATHS
colorlab_folder = genpath('./general_purpose_code/colorlab/');

% SPCA toolbox
spca_folder = genpath('./general_purpose_code/SPCA_toolbox_web_2/');

addpath(colorlab_folder,spca_folder)


%% IN/OUT FOLDERS
out_fold = './exp_color/color_results/';
in_fold =  './data/natural_data_color/';

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%   NORMAL OBJECTS
    % This part computes the results for the normal objects data. 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% LOADING DATA
load([in_fold 'dat_color_normal_objects_data'],'datDred')


TD_atd_all = datDred';
TD_atd_all = TD_atd_all(find(TD_atd_all(:,1)<100),:);
TD_atd_all = TD_atd_all';
clear datDred

%% TEST POINTS DEFINITION

N_samples = 21;

dat_test_T(1,:) = 5*ones(N_samples,1);
dat_test_T(2,:) = linspace(-1,2,N_samples);
dat_test_T(3,:) = zeros(21,1);

    
dat_test_D(1,:) = 5*ones(N_samples,1);
dat_test_D(2,:) = zeros(21,1);
dat_test_D(3,:) = linspace(-1.9,1.9,N_samples);

filename = ['RES_exp_color_SPCA_D65_normal_objects_data_test_points'];
save([out_fold filename],'dat_test_T','dat_test_D')

%% SPCA parameters

% Tau
tau = 15;
% k
muelle = 0.06;
% Criteria
CRIT = 2;
% Num bits
Btotal = 9;
% Distance to assume being outside the manifold
dist_fuera = 2;
% Reference matrix
Aref = eye(3);
% Tolerance
tol=0.1;


for iteration = 22:25
    
    rand('seed',iteration)
    iii = randperm(size(TD_atd_all,2));
    dat = TD_atd_all(:,iii(1:80000));
    
    %% SPCA INICIALIZATION
    
    % Origin
    rolancha2 = dat(:,find(dat(1,:)<2.5&dat(1,:)>1.5));
    pto = mean(rolancha2')';
    
    % Parameters
    
    % Number of training samples
    N_datos = length(dat(1,:));        
    % Number of neighbors (percentage of the training samples, e.g 4%)
    Nv = [round(0.2*N_datos)];
    
    tic
    [init_param] = initialize_SPCA_2(dat,pto,Nv,tau,muelle,CRIT,Btotal,0,dist_fuera,Aref);
    [iteration toc 1]
    
    %%   TRANSFORM OF TEST DATA AXIS T
    
    % R_T2          = SPCA transform of test data
    % pto_proximo = Inverse SPCA from R_T2 (useful to assess the inversion error)
    
    
    for nn=1:N_samples
        tic
        [pto_proximo_T2(:,nn) R_T2(:,nn) pto_proximo_T(:,nn) R_T(:,nn)]= spca_2(dat,dat_test_T(:,nn),init_param,tol) ;
        [iteration nn toc 1]
    end
    
    
    filenameT = ['RES_exp_color_SPCA_D65_axis_T_crit_' num2str(CRIT) '_it_' num2str(iteration) '_normal_objects_data'];
    save([out_fold filenameT],'dat_test_T','R_T2')
    
    %%   TRANSFORM OF TEST DATA AXIS D
    
    for nn=1:N_samples
        tic
        [pto_proximo_D2(:,nn) R_D2(:,nn) pto_proximo_D(:,nn) R_D(:,nn)] = spca_2(dat,dat_test_D(:,nn),init_param,tol);
        [iteration nn toc 2]
    end
    
    filenameD = ['RES_exp_color_SPCA_D65_axis_D_crit_' num2str(CRIT) '_it_' num2str(iteration) '_normal_objects_data'];
    save([out_fold filenameD],'dat_test_D','R_D2')
    
end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%   RED OBJECTS
    % This part computes the results for the red objects data. 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% LOADING DATA
load([in_fold 'dat_color_red_objects_data'],'datDred')

TD_atd_all = datDred';
TD_atd_all = TD_atd_all(find(TD_atd_all(:,1)<100),:);
TD_atd_all = TD_atd_all';
clear datDred

%% TEST POINTS DEFINITION

N_samples = 21;

dat_test_T(1,:) = 5*ones(N_samples,1);
dat_test_T(2,:) = linspace(-1,2,N_samples);
dat_test_T(3,:) = 0.42*ones(N_samples,1);  

dat_test_D(1,:) = 5*ones(N_samples,1);
dat_test_D(2,:) = 2.28*ones(N_samples,1);
dat_test_D(3,:) = linspace(-1.9,1.9,N_samples);

filename = ['RES_exp_color_SPCA_D65_red_objects_data_test_points'];
save([out_fold filename],'dat_test_T','dat_test_D')


for iteration = 1:20
    
    rand('seed',iteration)
    iii = randperm(size(TD_atd_all,2));
    TD_atd_all_red = TD_atd_all(:,iii(1:80000));
    
    %% SPCA INICIALIZATION
    
    % Data
    dat = TD_atd_all_red;
    
    % Origin
    rolancha2 = dat(:,find(dat(1,:)<2.5&dat(1,:)>1.5));
    pto = mean(rolancha2')';
    
    % Parameters
    
    % Number of training samples
    N_datos = length(dat(1,:));         
    % Number of neighbors (percentage of the training samples, e.g 4%)
    Nv = [round(0.2*N_datos)];
    
    tic
    [init_param] = initialize_SPCA_2(dat,pto,Nv,tau,muelle,CRIT,Btotal,0,dist_fuera,Aref);
    [iteration toc 1]
    
    %%   TRANSFORM OF TEST DATA AXIS T
    
    % R_T2          = SPCA transform of test data
    % pto_proximo = Inverse SPCA from R_T2 (useful to assess the inversion error)
    
    for nn=1:N_samples
        tic
        [pto_proximo_T2(:,nn) R_T2(:,nn) pto_proximo_T(:,nn) R_T(:,nn)]= spca_2(dat,dat_test_T(:,nn),init_param,tol) ;
        [iteration nn toc 1]
    end
    
    filenameT = ['RES_exp_color_SPCA_D65_axis_T_crit_' num2str(CRIT) '_it_' num2str(iteration) '_red_objects_data'];
    save([out_fold filenameT],'R_T2')
    
    %%   TRANSFORM OF TEST DATA AXIS D
    

    for nn=1:N_samples
        tic
        [pto_proximo_D2(:,nn) R_D2(:,nn) pto_proximo_D(:,nn) R_D(:,nn)] = spca_2(dat,dat_test_D(:,nn),init_param,tol);
        [iteration nn toc 2]
    end

    
    filenameD = ['RES_exp_color_SPCA_D65_axis_D_crit_' num2str(CRIT) '_it_' num2str(iteration) '_red_objects_data'];
    save([out_fold filenameD],'R_D2')
end






