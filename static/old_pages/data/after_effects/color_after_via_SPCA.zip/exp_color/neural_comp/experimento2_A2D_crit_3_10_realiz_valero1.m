clear all

restoredefaultpath

P1 = genpath('/home/vista/Papers/IEEE_Signal_Processing_2010/colorlab_mj_limpio');
P2 = genpath('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2');
P3 = genpath('/home/vistazos/Databases/color_constancy/Valensia_ieeee');
P4 = genpath('/home/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments');
%P5 = genpath('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCToolbox_mod_sub_2');

addpath(P1,P2,P3,P4)

%
% CARGO COLORES PROBLEMA
%

origen =  '/home/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_results/';

load([origen 'dat_1_2_3_100000.mat'])

% ind = find(datDred(1,:)<40 & datAred(1,:)<40);
datAred2 = datAred;
datDred2 = datDred;

load([origen 'luo_xyz.mat'])


for iteration =1:10
    ind = find(datDred2(1,:)<30 & datAred2(1,:)<30);

    iii = randperm(size(ind,2));

    datAred = datAred2(:,iii(1:80000));
    datDred = datDred2(:,iii(1:80000));

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% ARAÑA
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    CRIT = 3;

    tol = 0.01;
    N_datos = length(datAred(1,:));         % Number of training samples
    dist_fuera = 2;                 % Euclidean distance for the stopping criterion

    tau = 15;
    Nv = round(0.2*N_datos);
    muelle =0.06;


    fac_luo = 0.66;


    % fprintf('\n\n PARAM Ind Luo: %d, \n', ind_luo);


    filename = ['exp2_A2D_crit_3_valero1_it_' num2str(iteration)];

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   INIZIALIZING SPIDER ILU A
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    rolancha2 = datAred(:,find(datAred(1,:)<5.5 & datAred(1,:)>4.5));
    pto = mean(rolancha2')';
    % pto = mean(luoA_atd)';

    Btotal = 9;
    Aref = eye(3);
    tic
    [init_paramA] = initialize_SPCA_2(datAred,pto,Nv,tau,muelle,CRIT,Btotal,0,dist_fuera,Aref);
    fprintf('INICIALIZA DIRECTA, t: %d,  \n', round(toc));

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   TRANSFORM OF TEST DATA
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % R1          = PCU transform of test data
    % pto_proximo = Inverse PCU from R1 (useful to assess the inversion error)


    dat_test = fac_luo*luoA_atd';

    fprintf('DIRECTA: \n')
    for nn = 1:size(dat_test,2)
        tic
        [pto_proximo2(:,nn) R2(:,nn) pto_proximo1(:,nn) R1(:,nn)] = spca_2(datAred,dat_test(:,nn),init_paramA,tol) ;
        save(['/home/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien/' filename])
        fprintf('d: %d, t: %d,  ', nn, round(toc));
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   INIZILIZING ILU D
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    rolancha2 = datDred(:,find(datDred(1,:)<5.5 & datDred(1,:)>4.5));
    pto = mean(rolancha2')';
    %pto = mean(luoD_atd)';

    tic
    [init_paramD] = initialize_SPCA_2(datDred,pto,Nv,tau,muelle,CRIT,Btotal,init_paramA.Nbins,dist_fuera,init_paramA.Aref);
    fprintf('INICIALIZA DIRECTA, t: %d,  \n', round(toc));


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   INVERTING TEST DATA
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    fprintf('INVERSA: \n')
    for nn=1:size(R1,2)
        tic
        [inv_respuesta_D(:,nn)] = inv_SPCA_2(datDred,R2(:,nn),init_paramD);

        save(['/home/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien/' filename])
        fprintf('d: %d, t: %d,  ', nn, round(toc));
    end


end

luo_est_xyz = atd2xyz(inv_respuesta_D',1,5);
figure
telaranya(luo_est_xyz)