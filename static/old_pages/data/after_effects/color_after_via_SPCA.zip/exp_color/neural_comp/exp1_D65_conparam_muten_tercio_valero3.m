clear all

P1 = genpath('/media/disk/hal/vista/Papers/IEEE_Signal_Processing_2010/colorlab_mj_limpio');
P2 = genpath('/media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2');
P3 = genpath('/media/disk/hal/vistazos/Databases/color_constancy/Valensia_ieeee');
P4 = genpath('/media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments');

addpath(P1,P2,P3,P4)

%%% CARGO LOS COLORES:

%destino = '/media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp1/second_sub_exp1_bien';
destino = '/media/disk/users/sandra/exp1/';


%origen = '/media/disk/hal/vistazos/Databases/color_constancy/Valensia_ieeee/imagenes_plantas_corregidas/';
%load([origen 'colores_atd_all_D_plantas_corregidas'],'TD_atd_all')

origen =  '/media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_results/';

%load([origen 'dat_1_2_3_100000.mat'])
load([origen 'dat_D_1_2_3_1000000.mat'])

    TD_atd_all = datDred';
    TD_atd_all = TD_atd_all(find(TD_atd_all(:,1)<100),:);
    TD_atd_all = TD_atd_all';
    clear datDred

    ejeA = [0 0 0;
        80 0 0];
    ejeT = [0 -10 0;
        0 10 0];
    ejeD = [0 0 -20;
        0 0 20];


for iteration = 1:15

    iii = randperm(size(TD_atd_all,2));
    TD_atd_all_red = TD_atd_all(:,iii(1:240000));

   % figure
   % plot3(TD_atd_all_red(:,1),TD_atd_all_red(:,2),TD_atd_all_red(:,3),'m.','markersize',0.1)
   % hold on
   % plot3(ejeA(:,1),ejeA(:,2),ejeA(:,3),'k-','linewidth',3)
   % plot3(ejeT(:,1),ejeT(:,2),ejeT(:,3),'r-','linewidth',3)
   % plot3(ejeD(:,1),ejeD(:,2),ejeD(:,3),'b-','linewidth',3)
   % axis equal

   %%%%%%%%%%%%%%%%%%
   %  INICIALIZACION
   %%%%%%%%%%%%%%%%%%

       % Datos
            dat=TD_atd_all_red;
            
       % Punto origen
            rolancha2 = dat(:,find(dat(1,:)<2.5&dat(1,:)>1.5));
            pto = mean(rolancha2')';
       
       % Parametros
       
           % Num vecinos
               N_datos = length(dat(1,:));         % Number of training samples
               % Number of neighbors (percentage of the training samples, e.g 4%)
               Nv = [round(0.2*N_datos)];
           % Tau
               tau = 15;
           % Muelle
               muelle = 0.06;
           % Criterio
               CRIT = 3;
           % Num bits
               Btotal = 9;
           % Distancia fuera manifold
               dist_fuera = 2;
           % Matriz referencia
               Aref = eye(3);
           % Tolerancia en la inversa
               tol=0.1;  
      
       [init_param] = initialize_SPCA_2(dat,pto,Nv,tau,muelle,CRIT,Btotal,0,dist_fuera,Aref);

    filenameA = ['exp1_bien_ilu_D65_crit_',num2str(CRIT),'_A_valero3_it_',num2str(iteration)];
    filenameT = ['exp1_bien_ilu_D65_crit_',num2str(CRIT),'_T_valero3_it_',num2str(iteration)];
    filenameD = ['exp1_bien_ilu_D65_crit_',num2str(CRIT),'_D_valero3_it_',num2str(iteration)];

       
%    
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %%% INICIALIZACION ANTIGUA
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     global dat            % Training data in the input space
%     global tau            % Step size
%     global criterio       % Metric criterion
%     global eje_principal  % Principal axis
%     global dist_fuera     % Stopping criterion (computed from the maximum of the "minimum distance in neighborhoods")
% 
%     % DATA (noisy spiral with increasing noise along the way)
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     dat = TD_atd_all_red';
% 
%     N_datos = length(dat(1,:));         % Number of training samples
% 
%     % PARAMETERS OF PCU
%     %%%%%%%%%%%%%%%%%%%
% 
%     dist_fuera = 2;                 % Euclidean distance for the stopping criterion
% 
%     % Number of neighbors (percentage of the training samples, e.g 4%)
%     Nvss = [round(0.2*N_datos)];
% 
%     % Step size
%     tauss = 15;         % Euclidean step size
% 
%     % Initial point (a sensible chioce is the most dense point,
%     % here it is set at the different points of the true principal curve)
%     rolancha2 = dat(:,find(dat(1,:)<2.5&dat(1,:)>1.5));
%     ptoss = mean(rolancha2')';
%     %ptoss = [5 0 0]';
% 
% 
%     %criterioss = 2;                  % Criterion to set the local metric
%     %    criterio=1 ... Euclidean Metric
%     %    criterio=2 ... Metric according to the PDF (better for ICA)
%     %    criterio=3 ... Metric according to the PDF^(1/3) (better for VQ)
% 
%     tol = 0.1;                             % Tolerance. Maximum allowed departure from a sample and its inverse
%     % after PCU. It is measured in Euclidean units in the input space
%     % Here set to 0.1 since the data are in the range [-10, 10]
% 
%     % PARAMETERS FOR THE NL-ICA AND VQ APPLICATIONS
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     TAU=1  %1:5
%     tau = tauss(TAU);
%     vecinos  =1    %1:3
%     origen   =1    %1:3
%     criterion=1    %1:3
% 
%     Nv=Nvss(vecinos);
%     pto=ptoss(:,origen);
%     %criterio=criterioss(criterion);
%     muelle = 0.06;
%     CRIT = 2;
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %%
%     %%   INITIALIZATION (on training data):
%     %%
%     %%   it takes about 50 secs (in a Dell PowerEdge2900 processor with 2GB RAM) for the parameters used here
%     %%
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     Btotal = 8;
%     criterio = 1;
%     
%     
%     [Aref, dist_fuera, Nbins, eje_principal, eje_principal_sin_mod] = inicializa_RN_3(pto,Nv,dist_fuera,Btotal,0,muelle);
% 
%     figure,plot3(dat(1,:),dat(2,:),dat(3,:),'m.','markersize',0.1), axis square, axis equal
%     plotea_eje(eje_principal_sin_mod(1,1).eje,'ko-')
%     plotea_eje(eje_principal_sin_mod(1,2).eje,'ro-')
%     plotea_eje(eje_principal_sin_mod(1,3).eje,'bo-')
%     axis equal
% 
%     figure,plot3(dat(1,:),dat(2,:),dat(3,:),'m.','markersize',0.1), axis square, axis equal
%     plotea_eje(eje_principal,'ko-')
%     axis equal
% 
%     % criterio = 2;
%     % eje_principal_2 = modifica_eje(eje_principal_sin_mod(1,1).eje,pto,dat,100,Aref,1,Nv);
%     %
%     % figure,plot3(dat(1,:),dat(2,:),dat(3,:),'m.','markersize',0.1), axis square, axis equal
%     % plotea_eje(eje_principal_2,'ko-')

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   TRANSFORM OF TEST DATA AXIS A
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % R1          = PCU transform of test data
    % pto_proximo = Inverse PCU from R1 (useful to assess the inversion error)

    puntos_eje_A = zeros(20,3);
    puntos_eje_A(:,1) = linspace(0,75,20);
    dat_test = puntos_eje_A';
    N_samples = length(dat_test(1,:));         % Number of training samples

%     figure
%     plot3(TD_atd_all_red(:,1),TD_atd_all_red(:,2),TD_atd_all_red(:,3),'m.','markersize',0.1)
%     hold on
%     plot3(puntos_eje_A(:,1),puntos_eje_A(:,2),puntos_eje_A(:,3),'k.','markersize',10)
%     axis equal
% 
%     criterio = CRIT;
%     eje_CRIT = modifica_eje(eje_principal,pto,dat,Nbins(1),Aref,1,Nv);
% 
%     pto_proximo_principal_CRIT = zeros(size(dat));
%     resp_principal_CRIT = zeros(1,size(dat,2));
% 
%     for n=1:size(dat,2)
%         [pto_proximo_principal_CRIT(:,n),resp_principal_CRIT(:,n)] = punto_en_eje_NLPCA(dat(:,n),eje_CRIT);
%     end
% 
% 
%     for nn=1:N_samples
%         tic
%         [pto_proximo2(:,nn) R2(:,nn) pto_proximo1(:,nn) R1(:,nn)] = respuesta_it_RN_nueva_3(dat_test(:,nn),pto,Nbins,Aref,Nv,tol,eje_CRIT,pto_proximo_principal_CRIT,resp_principal_CRIT,CRIT,muelle);
% 
%         [nn toc]
%     end

    
    for nn=1:N_samples
        tic
        [pto_proximo2(:,nn) R2(:,nn) pto_proximo1(:,nn) R1(:,nn)] = spca_2(dat,dat_test(:,nn),init_param,tol) ;        
        [nn toc]
    end
    
    for i=1:N_samples;
        RR(i) = sqrt(R2(1,i)^2+R2(2,i)^2+R2(3,i)^2);
    end
    incR=R2(:,2:end)-R2(:,1:end-1);
    mod_incR=sqrt(sum(incR.^2));
    resp=cumsum(mod_incR);

    %figure,plot(dat_test(1,1:end),R2(1,1:end),'ko-')
    %hold on,plot(dat_test(1,1:end),R2(2,1:end),'ro-')
    %hold on,plot(dat_test(1,1:end),R2(3,1:end),'bo-')

    %figure,plot(dat_test(1,1:end),RR,'ko-')
    %figure,plot(dat_test(1,1:end),abs(R2(1,1:end)-R2(1,1)),'ko-')
    %figure,plot(dat_test(1,1:end-1),resp,'ko-')

    save([destino filenameA]) %/media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp1_results/resultado_eje_A_D65_param_tercio

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   TRANSFORM OF TEST DATA AXIS T
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % R1          = PCU transform of test data
    % pto_proximo = Inverse PCU from R1 (useful to assess the inversion error)

    puntos_eje_T(:,1) = 5*ones(21,1);
    puntos_eje_T(:,2) = linspace(-1,2,21);
    puntos_eje_T(:,3) = zeros(21,1);

    dat_test = puntos_eje_T';
    N_samples = length(dat_test(1,:));         % Number of training samples

    for nn=1:N_samples
        tic
        [pto_proximo_T2(:,nn) R_T2(:,nn) pto_proximo_T(:,nn) R_T(:,nn)]= spca_2(dat,dat_test(:,nn),init_param,tol) ;
        [nn toc]
    end


    RR = sqrt(sum(R_T2.^2));

    incR=R_T2(:,2:end)-R_T2(:,1:end-1);
    mod_incR=sqrt(sum(incR.^2));
    resp=cumsum(mod_incR);

    %figure,plot(dat_test(2,1:size(R_T2,2)),R_T2(1,1:end),'ko-')
    %hold on,plot(dat_test(2,1:size(R_T2,2)),R_T2(2,1:end),'ro-')
    %hold on,plot(dat_test(2,1:size(R_T2,2)),R_T2(3,1:end),'bo-')

    %figure,plot(dat_test(2,1:size(R_T2,2)),RR,'ko-')
    %figure,plot(dat_test(2,1:size(R_T2,2)),R_T2(2,1:end),'ko-')
    %figure,plot(dat_test(2,1:size(R_T2,2)-1),resp,'ko-')

    % save /media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp1_results/resultado_eje_T_D65_param_tercio
    save([destino filenameT]) 

%     figure,plot3(dat(1,:),dat(2,:),dat(3,:),'m.','markersize',0.1), axis square, axis equal
%     hold on,plot3(dat_test(1,:),dat_test(2,:),dat_test(3,:),'ko','linewidth',5), axis square, axis equal
%     hold on,plot3(pto(1,:),pto(2,:),pto(3,:),'ro','linewidth',5), axis square, axis equal
%     plotea_eje(eje_CRIT,'ko-')
%     hold on,plot3(pto_proximo_T2(1,:),pto_proximo_T2(2,:),pto_proximo_T2(3,:),'go','linewidth',5), axis square, axis equal

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   TRANSFORM OF TEST DATA AXIS D
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % R1          = PCU transform of test data
    % pto_proximo = Inverse PCU from R1 (useful to assess the inversion error)

    puntos_eje_D(:,1) = 5*ones(21,1);
    puntos_eje_D(:,2) = zeros(21,1);
    puntos_eje_D(:,3) = linspace(-1.9,1.9,21);

    dat_test = puntos_eje_D';
    N_samples = length(dat_test(1,:));         % Number of training samples

    %for nn=1:N_samples
    %    tic
    %    [pto_proximo_D2(:,nn) R_D2(:,nn) pto_proximo_D(:,nn) R_D(:,nn)] =
    %    respuesta_it_RN_nueva_3(dat_test(:,nn),pto,Nbins,Aref,Nv,tol,eje_CRIT,pto_proximo_principal_CRIT,resp_principal_CRIT,CRIT,muelle);%
    %
    %    [nn toc]
    %end

    for nn=1:N_samples
        tic
        [pto_proximo_D2(:,nn) R_D2(:,nn) pto_proximo_D(:,nn) R_D(:,nn)] = spca_2(dat,dat_test(:,nn),init_param,tol);

        [nn toc]
    end
    
    RR = sqrt(sum(R_D2.^2));

    incR=R_D2(:,2:end)-R_D2(:,1:end-1);
    mod_incR=sqrt(sum(incR.^2));
    resp=cumsum(mod_incR);

    %figure,plot(dat_test(3,1:size(R_D2,2)),R_D2(1,1:end),'ko-')
    %hold on,plot(dat_test(3,1:size(R_D2,2)),R_D2(2,1:end),'ro-')
    %hold on,plot(dat_test(3,1:size(R_D2,2)),R_D2(3,1:end),'bo-')

    %figure,plot(dat_test(3,1:size(R_D2,2)),RR,'ko-')
    %figure,plot(dat_test(3,1:size(R_D2,2)),R_T(2,1:end),'ko-')
    %figure,plot(dat_test(3,1:size(R_D2,2)-1),resp,'ko-')

    save([destino filenameD]) 

end

% figure,plot3(dat(1,:),dat(2,:),dat(3,:),'m.','markersize',0.1), axis square, axis equal
% hold on,plot3(dat_test(1,:),dat_test(2,:),dat_test(3,:),'ko','linewidth',5), axis square, axis equal
% hold on,plot3(pto(1,:),pto(2,:),pto(3,:),'ro','linewidth',5), axis square, axis equal
% plotea_eje(eje_CRIT,'ko-')
% hold
% on,plot3(pto_proximo_D2(1,:),pto_proximo_D2(2,:),pto_proximo_D2(3,:),'go','linewidth',5), axis square, axis equal
