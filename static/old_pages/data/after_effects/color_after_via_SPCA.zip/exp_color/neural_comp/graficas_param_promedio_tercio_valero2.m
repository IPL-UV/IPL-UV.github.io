% Este script carga y representa los resultados del experimento 1 
% (Generalized weber law) con exponente 1, usando los mismos datos que en el experimento 2
% y parametros preliminares (mientras acaba de pulirlos Valero para el exp 2)

%ori = '/media/disk/hal/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/';
%ori = '/home/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/';
ori = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/';

FS=21;

% USANDO la respuesta de cada r_i independiente
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DATOS de criterio = 3


    
    % En este caso tenemos distintas iteraciones, hacemos un promedio y
    % sacamos las barras de error:
    
    num_it = [1:25];
    
    
    R2_total = [];
    DA1_total = [];
    
    R_T2_total = [];
    DT1_total = [];
    RA_T2_total = [];
    DT1_A_total = [];

    R_D2_total = [];
    DD1_total = [];
    
    
    for it=num_it;
        
        it
        
        % Resultado eje A, iluminante D65:
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
        load ([ori 'exp1_bien_ilu_D65/exp1_bien_ilu_D65_crit_3_valero2/exp1_bien_ilu_D65_crit_3_A_valero2_it_',num2str(it)])
        
        %%% Respuesta

        min_r1=R2(1,1);
               
        R2(1,:)=abs(R2(1,1:end)-min_r1);
        R2_total = [R2_total; R2(1,1:end)];
        
        dat_testA=dat_test(1,:);
        %%% Umbral Incremental de A (1) definido a partir de la derivada de la respuesta de r1 (magnitud de la vartiacion de la respuesta r1)

        incR_A = gradient(R2(1,:));
        incA_A = dat_test(1,2:end)-dat_test(1,1:end-1);

        dRdA1 = incR_A./incA_A(1);
        DA1=1./dRdA1;
        DA1_total = [DA1_total; DA1];

       
        % Resultado eje T, iluminante D65:
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        load ([ori 'exp1_bien_ilu_D65/exp1_bien_ilu_D65_crit_3_valero2/exp1_bien_ilu_D65_crit_3_T_valero2_it_',num2str(it)])
        
        dat_testT=dat_test(2,:);       
        %%% Respuesta

        R_T2(1,:)=abs(R_T2(1,:)-min_r1);
        
               
        R_T2_total = [R_T2_total; R_T2(2,1:end)];


        %%% Umbral Incremental de T (1) definido a partir de la derivada de la respuesta de r2 (magnitud de la vartiacion de la respuesta r2)

        incR_T = gradient(R_T2(2,:));
        incT = dat_test(2,2:end)-dat_test(2,1:end-1);

        dRdT1 = incR_T./incT(1);
        DT1=1./dRdT1;
        
        DT1_total = [DT1_total; DT1];

       
        % Resultado eje T, iluminante A:
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        load ([ori 'exp1_bien_ilu_A/exp1_bien_ilu_A_crit_3_valero2/exp1_bien_ilu_A_crit_3_T_valero2_it_',num2str(it)])
        %load ([ori 'exp1_bien_ilu_A/exp1_bien_ilu_A_crit_3_valero2/exp1_bien_ilu_A_crit_3_T_valero2_it_1'])
        
       
        dat_testTA=dat_test(2,:);        
        %%% Respuesta

        R_T2(2,1:end) = R_T2(2,1:end);
        RA_T2_total = [RA_T2_total; R_T2(2,1:end)];

        %%% Umbral Incremental de T (1) definido a partir de la derivada de la respuesta de r2 (magnitud de la vartiacion de la respuesta r2)

        incR_T = gradient(R_T2(2,:));
        incT = dat_test(2,2:end)-dat_test(2,1:end-1);

        dRdT1 = incR_T./incT(1);
        DT1=1./dRdT1;

              
        DT1_A_total = [DT1_A_total; DT1];
    
      
        % Resultado eje D, iluminante D65:
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        load ([ori 'exp1_bien_ilu_D65/exp1_bien_ilu_D65_crit_3_valero2/exp1_bien_ilu_D65_crit_3_D_valero2_it_',num2str(it)])
          
        dat_testD=dat_test(3,:);        
        %%% Respuesta

        R_D2(1,:)=abs(R_D2(1,:)-min_r1);
        
            
        R_D2_total = [R_D2_total; R_D2(3,:)];


        %%% Umbral Incremental de D (1) definido a partir de la derivada de la respuesta de r3 (magnitud de la vartiacion de la respuesta r3)

        incR_D = gradient(smooth(R_D2(3,:),5));
        incD = dat_test(3,2:end)-dat_test(3,1:end-1);

        dRdD1 = incR_D./incD(1);
        DD1=1./dRdD1;
        
               
        DD1_total = [DD1_total; DD1'];
        
       % pause
     
    end
    
    
    R2 = mean(R2_total);
    R2_std = std(R2_total);
    
    figure(1),errorbar(dat_testA(1:end),R2,R2_std,'ko-','linewidth',2),
        xlabel('A','FontSize',18),ylabel('r_1(A)','FontSize',FS)
        %axis([0 80 0 210])    
        
    DA1 = mean(DA1_total);
    DA1_std = std(DA1_total);
    
    figure(2),errorbar(dat_testA(1,1:end),DA1,DA1_std,'ko-','linewidth',2),
        xlabel('A','FontSize',FS),ylabel('\Delta A_t(A) = (d r_1(A) / dA)^{-1} ','FontSize',FS)
        %axis([0 80 0 4.3])
        
    R_T2 = mean(R_T2_total);
    R_T2_std = std(R_T2_total); 
    
    figure(3),errorbar(dat_testT(1,1:end),R_T2,R_T2_std,'o-','color',[0 0.7 0],'linewidth',2)
        hold on,plot([-2 4.5],[0 0],'k-')
        hold on,plot([0 0],[-8 8],'k-')    
        %axis([-0.5 2.5 -8 8])
        xlabel('T','FontSize',FS),ylabel('r_2(T)','FontSize',FS)
       
    DT1 = mean(DT1_total);
    DT1_std = std(DT1_total);
    
    figure(4),errorbar(dat_testT(1,1:end),DT1,DT1_std,'o-','color',[0 0.7 0],'linewidth',2),
        xlabel('T','FontSize',FS),ylabel('\Delta T_t(T) = (d r_2(T) / dT)^{-1} ','FontSize',FS)
        hold on,plot([-1 2.5],[0 0],'k-')
        hold on,plot([0 0],[-0.05 1],'k-')
        %axis([-0.3 2.5 -0.05 0.8])
        %axis([-0.5 2.5 0 1])
    
    RA_T2 = mean(RA_T2_total);
    RA_T2_std = std(RA_T2_total);         
        
    figure(3),hold on,errorbar(dat_testTA(1,1:end),RA_T2,RA_T2_std,'ro-','linewidth',2)
    
    DT1_A = mean(DT1_A_total);
    DT1_A_std = std(DT1_A_total);

    figure(4),hold on,errorbar(dat_testTA(1,1:end),DT1_A,DT1_A_std,'ro-','linewidth',2)
    %axis([-0.5 2.5 0 1])
   
    R_D2 = mean(R_D2_total);
    R_D2_std = std(R_D2_total); 
    
    figure(5),errorbar(dat_testD(1,1:end),smooth(R_D2,5),smooth(R_D2_std,5),'bo-','linewidth',2)
        xlabel('D','FontSize',FS),ylabel('r_3(D)','FontSize',FS)    
        hold on,plot([-2 2],[0 0],'k-')
        hold on,plot([0 0],[-15 15],'k-')    
        %axis([-1.5 1.9 -14 14])
        
    DD1 = mean(DD1_total);
    DD1_std = std(DD1_total);
    
    figure(6),errorbar(dat_testD(1,1:end),DD1,DD1_std,'bo-','linewidth',2),
        xlabel('D','FontSize',FS),ylabel('\Delta D_t(D) = (d r_3(D) / dD)^{-1} ','FontSize',FS)
        hold on,plot([-2 2],[0 0],'k-')
        hold on,plot([0 0],[-0.1 1.5],'k-')
        %axis([-1.5 1.9 0 1.1])
