%
% Este script reproduce las graficas correspondientes a los experimentos 1
% y 2, para los distintos criterios y distintos tipos de realizaciones
%

%
% EXPERIMENTO 2
%

% Monguer

% Usando 2.7e4 puntos, 25 realiz (valero0, ambos criterios):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien')
muestra_results_exp_2_valero0

% Usando 8e4 puntos, 24 (de la 2 a la 25) realizaciones (valero2, ambos criterios):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien')
muestra_results_exp_2_valero2

% Usando 24e4 puntos, 17 realiz (valero3, ambos criterios):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien')
muestra_results_exp_2_valero3

% Bien

% Usando 8e4 puntos, 25 realizaciones (valero2_dispares, ambos criterios):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien')
muestra_results_exp_2_valero2_dispares

% Usando 24e4 puntos, calculandose en mutenroshi iteraciones = 1:15, hay que modificar num_it en el script segun las iteraciones calculada y pasar los datos de mutenroshi
%                     al directorio especificado abajo (estan en /media/disk/users/sandra/exp2/):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien')
muestra_results_exp_2_valero3_dispares

% No correspondientes

% Usando 8e4 puntos, 25 real (jesus 2): Se estan calculando en el directorio correspondiente, solo hay que modificar el bucle segun los resultados que se hayan calculado:

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien')
muestra_results_exp_2_jesus2_dispares


%
% EXPERIMENTO 1
%

% Bien (conjuntos correspondientes)

% Usando 2.7e4 puntos, 25 realiz (valero0):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/')
graficas_param_promedio_valero0
graficas_param_promedio_tercio_valero0

% Usando 8e4 puntos, 25 (valero 2):

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/')
graficas_param_promedio_valero2
graficas_param_promedio_tercio_valero2

% Usando 24e4 puntos, calculandose en mutenroshi iteraciones = 1:15 y 16:25 en hal, hay que modificar num_it en el script segun las iteraciones calculadas,
%                     los datos calculados en mutenroshi, hay que pasarlos al directorio especificado abajo (estan en /media/disk/users/sandra/exp1/)::

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/')
graficas_param_promedio_valero3
graficas_param_promedio_tercio_valero3

% Conjuntos no correspondientes

cd('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/')
graficas_param_promedio_jesus2
graficas_param_promedio_tercio_jesus2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% EXPERIMENTOS A LA VALERO (utilizando conjuntos correspondientes)

% Experimentos Monguer -como los habiamos hecho- (utilizando las mismas muestras random bajo A y D65)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Experimento 1 (no se hizo, es decir, siempre se han tomado muestras random distintas bajo A y D65)

% Experimento 2:

% Usando 2.7e4 puntos, 25 realiz (valero0, ambos criterios):

% Ejercutar el script:
%                               - muestra_results_exp_2_valero0.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien


% Usando 8e4 puntos, 24 (de la 2 a la 25) realizaciones (valero2, ambos criterios):

% Ejercutar el script:
%                               - muestra_results_exp_2_valero2.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien


% Usando 24e4 puntos, 17 realiz (valero3, ambos criterios):

% Ejercutar el script:
%                               - muestra_results_exp_2_valero3.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien


% Experimentos sugeridos por el referee (interpretacion ESO-minimo esfuerzo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Experimento 1 (se hizo asi -bien de entrada- porque los exp bajo iluminantes A y D estaban en programas distiontos y se ejecutaba el random independientemente)

% Usando 2.7e4 puntos, 25 realiz (valero0):

% Ejercutar el script:
%                               - graficas_param_promedio_tercio_valero0.m
%                               - graficas_param_promedio_valero0.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/


% Usando 8e4 puntos, 25 (valero 2):

% Ejercutar el script:
%                               - graficas_param_promedio_tercio_valero2.m
%                               - graficas_param_promedio_valero2.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/

% Usando 24e4 puntos, calculandose en mutenroshi iteraciones = 1:15 y 16:25 en hal, hay que modificar num_it en el script segun las iteraciones calculadas,
%                     los datos calculados en mutenroshi, hay que pasarlos al directorio especificado abajo (estan en /media/disk/users/sandra/exp1/)::

% Ejercutar el script:
%                               - graficas_param_promedio_tercio_valero3.m
%                               - graficas_param_promedio_valero3.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/

% Experimento 2:

% Usando 8e4 puntos, 25 realizaciones (valero2_dispares, ambos criterios):

% Ejercutar el script:
%                               - muestra_results_exp_2_valero2_dispares.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien

% Usando 24e4 puntos, calculandose en mutenroshi iteraciones = 1:15, hay que modificar num_it en el script segun las iteraciones calculada y pasar los datos de mutenroshi
%                     al directorio especificado abajo (estan en /media/disk/users/sandra/exp2/):

% Ejercutar el script:
%                               - muestra_results_exp_2_valero3_dispares.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien


% Experimentos a la jesus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Experimento 1

% Usando 8e4 puntos, 25 real (jesus 2): Se estan calculando en el directorio correspondiente, solo hay que modificar el bucle segun los resultados que se hayan calculado:

% Ejercutar el script:
%                               - graficas_param_promedio_tercio_jesus2.m
%                               - graficas_param_promedio_jesus2.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/

% Experimento 2:

% Usando 8e4 puntos, 25 real (jesus 2): Se estan calculando en el directorio correspondiente, solo hay que modificar el bucle segun los resultados que se hayan calculado:

% Ejercutar el script:
%                               - muestra_results_exp_2_jesus2_dispares.m
% Situado en el directorio:
%                               - /media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/exp2_reproducible_results/second_submision_bien



