
clear all
close all


ori = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/second_sub_exp_1/second_sub_exp1_bien/';

FS=21;

% USANDO la respuesta de cada r_i independiente
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DATOS de criterio = 3

% En este caso tenemos distintas iteraciones, hacemos un promedio y
% sacamos las barras de error:

R_T2_total = [];
R_D2_total = [];

for it=1:25
    
    it
    
    % Resultado eje T, iluminante D65:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    load ([ori 'exp1_bien_ilu_D65_crit_2_T_jesus2_new3_it_',num2str(it)])
    
    dat_testT = dat_test(2,:);
    %%% Respuesta

    R_T2_total = [R_T2_total; R_T2(2,1:end)];
          
    % Resultado eje D, iluminante D65:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    load ([ori 'exp1_bien_ilu_D65_crit_2_D_jesus2_new3_it_',num2str(it)])
    
    dat_testD = dat_test(3,:);
    %%% Respuesta
  
    R_D2_total = [R_D2_total; R_D2(3,:)];
    
end


R_T2 = mean(R_T2_total);
R_T2_std = std(R_T2_total);

figure(3),errorbar(dat_testT(1,1:end),smooth(R_T2,5),smooth(R_T2_std,5),'o-','color',[0 0.7 0],'linewidth',2)
hold on,plot([-2 4.5],[0 0],'k-')
hold on,plot([0 0],[-8 8],'k-')

xlabel('T','FontSize',FS),ylabel('r_2(T)','FontSize',FS)


R_D2 = mean(R_D2_total);
R_D2_std = std(R_D2_total);

figure(5),errorbar(dat_testD(1,1:end),smooth(R_D2,5),smooth(R_D2_std,5),'bo-','linewidth',2)
xlabel('D','FontSize',FS),ylabel('r_3(D)','FontSize',FS)
hold on,plot([-2 2],[0 0],'k-')
hold on,plot([0 0],[-15 15],'k-')


%%% FIGURAS VALERO:

RA_T2_total = [];
R_D2_total = [];

for it=1:25
    
    it

    % Resultado eje T, iluminante D65:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    load([ori 'exp1_bien_ilu_D65/exp1_bien_ilu_D65_crit_2_valero2/exp1_bien_ilu_D65_crit_2_T_valero2_it_',num2str(it)])
    
    dat_testT=dat_test(2,:);
    %%% Respuesta
    
    R_T2_total = [R_T2_total; R_T2(2,1:end)];
    
    % Resultado eje D, iluminante D65:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    load ([ori 'exp1_bien_ilu_D65/exp1_bien_ilu_D65_crit_2_valero2/exp1_bien_ilu_D65_crit_2_D_valero2_it_',num2str(it)])
    
    dat_testD=dat_test(3,:);
    %%% Respuesta
    
    R_D2_total = [R_D2_total; R_D2(3,:)];
    
end

R_T2 = mean(R_T2_total);
R_T2_std = std(R_T2_total);

figure(3),hold on,errorbar(dat_testT(1,1:end),smooth(R_T2,5),smooth(R_T2_std,5),'o-','color',[0.5 0.5 0.5],'linewidth',2)
hold on,plot([-2 4.5],[0 0],'k-')
hold on,plot([0 0],[-8 8],'k-')
%axis([-0.5 2.5 -8 8])
xlabel('T','FontSize',FS),ylabel('r_2(T)','FontSize',FS)

R_D2 = mean(R_D2_total);
R_D2_std = std(R_D2_total);

figure(5),errorbar(dat_testD(1,1:end),smooth(R_D2,5),smooth(R_D2_std,5),'o-','color',[0.5 0.5 0.5],'linewidth',2)
xlabel('D','FontSize',FS),ylabel('r_3(D)','FontSize',FS)
hold on,plot([-2 2],[0 0],'k-')
hold on,plot([0 0],[-15 15],'k-')
%axis([-1.5 1.9 -14 14])



