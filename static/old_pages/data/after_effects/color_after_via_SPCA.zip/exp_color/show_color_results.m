%
% SHOW COLOR RESULTS
%
% This funtion simulates the shift of the responses of the RG and YB mechanisms
% when the environment changes from a diverse one to a hue restricted (reddish) one 
% This corresponds to the results shown in Figure 10 of the paper.
% These results can be computed using using:
% ./exp_color/compute_color_results.m
%
% 

clear all
close all


in_fold =  './data/natural_data_color/';
in_fold_res =  './exp_color/color_results/';

colorlab_folder = './general_purpose_code/colorlab/';

% Colorlab inizialization
[T_l,Yw,Mbx] = loadsysm([colorlab_folder 'colordat/systems/ciexyz.mat']);
[tm,a,g] = loadmonm([colorlab_folder 'colordat/monitor/std_crt.mat'],Mbx);
FS = 21;

load([in_fold 'data_flowers'],'M_xyz2atd','M_xyz2lms')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


filename = ['RES_exp_color_SPCA_D65_normal_objects_data_test_points'];
load([in_fold_res filename],'dat_test_T','dat_test_D')

dat_test_T_normal_objects = dat_test_T;
dat_test_D_normal_objects = dat_test_D;

filename = ['RES_exp_color_SPCA_D65_red_objects_data_test_points'];
load([in_fold_res filename],'dat_test_T','dat_test_D')

dat_test_T_red_objects = dat_test_T;
dat_test_D_red_objects = dat_test_D;



%% Load stored results

R_T2_total_normal = [];
R_D2_total_normal = [];

R_T2_total_red = [];
R_D2_total_red = [];

CRIT = 2;

for iteration = 1:20
    
    % Normal Objects, T axis
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    filename = ['RES_exp_color_SPCA_D65_axis_T_crit_' num2str(CRIT) '_it_' num2str(iteration) '_normal_objects_data'];
    load ([in_fold_res filename])
    
    R_T2_total_normal = [R_T2_total_normal; R_T2(2,1:end)];
          
    % Normal Objects, D axis
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    filename = ['RES_exp_color_SPCA_D65_axis_D_crit_' num2str(CRIT) '_it_' num2str(iteration) '_normal_objects_data'];
    load ([in_fold_res filename])
  
    R_D2_total_normal = [R_D2_total_normal; R_D2(3,:)];
    
    
    % Red Objects, T axis
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    filename = ['RES_exp_color_SPCA_D65_axis_T_crit_' num2str(CRIT) '_it_' num2str(iteration) '_red_objects_data'];
    load ([in_fold_res filename])
    
    R_T2_total_red = [R_T2_total_red; R_T2(2,1:end)];
          
    % Red Objects, D axis
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    filename = ['RES_exp_color_SPCA_D65_axis_D_crit_' num2str(CRIT) '_it_' num2str(iteration) '_red_objects_data'];
    load ([in_fold_res filename])
  
    R_D2_total_red = [R_D2_total_red; R_D2(3,:)];
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% RESULTS FIGURES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% SHOW RESULTS T axis 
R_T2 = mean(R_T2_total_normal);
R_T2_std = std(R_T2_total_normal);

R_T2_red = mean(R_T2_total_red);
R_T2_std_red = std(R_T2_total_red);


figure
errorbar(dat_test_T_normal_objects(2,1:end),smooth(R_T2,5),smooth(R_T2_std,5),'o-','color',[0.5 0.5 0.5],'linewidth',2)
hold on
errorbar(dat_test_T_red_objects(2,1:end),smooth(R_T2_red,5),smooth(R_T2_std_red,5),'o-','color',[0 0.7 0],'linewidth',2)


xlabel('T','FontSize',FS),ylabel('r_2(T)','FontSize',FS)

mm_x = min(dat_test_T_red_objects(2,1:end))*1.1;
MM_x = max(dat_test_T_red_objects(2,1:end))*1.1;

mm_y = min(R_T2_red)*1.7;
MM_y = max(R_T2_red)*1.7;

axis([mm_x MM_x mm_y MM_y])

hold on,plot([mm_x MM_x],[0 0],'k-')
hold on,plot([0 0],[mm_y MM_y],'k-')

%% SHOW RESULTS D axis
R_D2 = mean(R_D2_total_normal);
R_D2_std = std(R_D2_total_normal);

R_D2_red = mean(R_D2_total_red);
R_D2_std_red = std(R_D2_total_red);

figure
errorbar(dat_test_D_normal_objects(3,1:end),smooth(R_D2,5),smooth(R_D2_std,5),'o-','color',[0.5 0.5 0.5],'linewidth',2)
hold on
errorbar(dat_test_D_red_objects(3,1:end),smooth(R_D2_red,5),smooth(R_D2_std_red,5),'bo-','linewidth',2)
xlabel('D','FontSize',FS),ylabel('r_3(D)','FontSize',FS)

mm_x = min(dat_test_D_red_objects(3,1:end))*1.1;
MM_x = max(dat_test_D_red_objects(3,1:end))*1.1;

mm_y = min(R_D2_red)*1.7;
MM_y = max(R_D2_red)*1.7;

axis([mm_x MM_x mm_y MM_y])

hold on,plot([mm_x MM_x],[0 0],'k-')
hold on,plot([0 0],[mm_y MM_y],'k-')
