%
% Analysis of the responses of horizontal sensor and diagonal sensor
% (computed by texture_masking_experiment.m)
%
%

close all
clc

% CLOSE
[C,Rhc,sRhc]=graph_motion_resp('respuestas_fh_cerca',[-0.01 0.3 -5 100],'C_{low freq. horiz.}','Resp. (low freq. horiz. mask)',3,23,200)
figure(gcf),title('HORIZ. SENSOR (\gamma=1)')
[C,Rhc3,sRhc3]=graph_motion_resp('respuestas_fh3_cerca',[-0.01 0.3 -5 80],'C_{low freq. horiz.}','Resp. (low freq. horiz. mask)',3,23,300)
figure(gcf),title('HORIZ. SENSOR (\gamma=1/3)')

[C,Rdc,sRdc]=graph_motion_resp('respuestas_fd_cerca',[-0.01 0.3 -5 100],'C_{low freq. diag.}','Resp. (low freq. diag. mask)',3,23,400)
figure(gcf),title('DIAGONAL SENSOR (\gamma=1)')
[C,Rdc3,sRdc3]=graph_motion_resp('respuestas_fd3_cerca',[-0.01 0.3 -5 80],'C_{low freq. diag.}','Resp. (low freq. diag. mask)',3,23,500)
figure(gcf),title('DIAGONAL SENSOR (\gamma=1/3)')

% FAR IN FREQ
[C,Rhl,sRhl]=graph_motion_resp('respuestas_fh_lej',[-0.01 0.3 -5 100],'C_{low freq. horiz.}','Resp. (high freq. horiz. mask)',3,23,600)
[C,Rhl3,sRhl3]=graph_motion_resp('respuestas_fh3_lej',[-0.01 0.3 -5 80],'C_{low freq. horiz.}','Resp. (high freq. horiz. mask)',3,23,700)

[C,Rdl,sRdl]=graph_motion_resp('respuestas_fd_lej',[-0.01 0.3 -5 100],'C_{low freq. diag.}','Resp. (high freq. diag. mask)',3,23,800)
[C,Rdl3,sRdl3]=graph_motion_resp('respuestas_fd3_lej',[-0.01 0.3 -5 80],'C_{low freq. diag.}','Resp. (high freq. diag. mask)',3,23,900)

% FAR IN FREQ AND ORIENT
[C,Rhll,sRhll]=graph_motion_resp('respuestas_fo3_lej',[-0.01 0.3 -5 100],'C_{low freq. horiz.}','Resp. (high freq. diag. mask)',3,23,1000)
[C,Rhll3,sRhll3]=graph_motion_resp('respuestas_fo33_lej',[-0.01 0.3 -5 80],'C_{low freq. horiz.}','Resp. (high freq. diag. mask)',3,23,1100)

[C,Rdll,sRdll]=graph_motion_resp('respuestas_fo4_lej',[-0.01 0.3 -5 100],'C_{low freq. diag.}','Resp. (high freq. vert. mask)',3,23,1200)
[C,Rdll3,sRdll3]=graph_motion_resp('respuestas_fo43_lej',[-0.01 0.3 -5 80],'C_{low freq. diag.}','Resp. (high freq. vert. mask)',3,23,1300)

% [C,R1n,sR1n]=graph_motion_resp('respuestas_fo4_lej',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,100)

LW = 3,
FS = 23
ejes =[-0.01 0.3 -5/100 1.05];

% CLOSE H

textox = 'C_{test}   (Low freq. Horiz.)';
textoy = ['Response (Mask Low freq. Horiz.)'];

R = Rhc;
MM = max(R(1,:));
R = R/MM;
sR = sRhc/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

% CLOSE H errormin
        
textox = 'C_{test}   (Low freq. Horiz.)';
textoy = ['Response (Mask Low freq. Horiz.)'];

R = Rhc3;
MM = max(R(1,:));
R = R/MM;
sR = sRhc3/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

% CLOSE D

textox = 'C_{test}   (Low freq. Diag.)';
textoy = ['Response (Mask Low freq. Diag.)'];

R = Rdc;
MM = max(R(1,:));
R = R/MM;
sR = sRdc/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
% CLOSE D errormin

textox = 'C_{test}   (Low freq. Diag.)';
textoy = ['Response (Mask Low freq. Diag.)'];

R = Rdc3;
MM = max(R(1,:));
R = R/MM;
sR = sRdc3/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% FAR H

textox = 'C_{test}   (Low freq. Horiz.)';
textoy = ['Response (Mask High freq. Horiz.)'];

R = Rhl;
MM = max(R(1,:));
R = R/MM;
sR = sRhl/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

% FAR H errormin
        
textox = 'C_{test}   (Low freq. Horiz.)';
textoy = ['Response (Mask High freq. Horiz.)'];

R = Rhl3;
MM = max(R(1,:));
R = R/MM;
sR = sRhl3/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

% FAR D

textox = 'C_{test}   (Low freq. Diag.)';
textoy = ['Response (Mask High freq. Diag.)'];

R = Rdl;
MM = max(R(1,:));
R = R/MM;
sR = sRdl/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
% FAR D errormin

textox = 'C_{test}   (Low freq. Diag.)';
textoy = ['Response (Mask High freq. Diag.)'];

R = Rdl3;
MM = max(R(1,:));
R = R/MM;
sR = sRdl3/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% FAR-FAR H

textox = 'C_{test}   (Low freq. Horiz.)';
textoy = ['Response (Mask High freq. Diag.)'];

R = Rhll;
MM = max(R(1,:));
R = R/MM;
sR = sRhll/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

% FAR-FAR H errormin
        
textox = 'C_{test}   (Low freq. Horiz.)';
textoy = ['Response (Mask High freq. Diag.)'];

R = Rhll3;
MM = max(R(1,:));
R = R/MM;
sR = sRhll3/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

% FAR-FAR D

textox = 'C_{test}   (Low freq. Diag.)';
textoy = ['Response (Mask High freq. Vert.)'];

R = Rdll;
MM = max(R(1,:));
R = R/MM;
sR = sRdll/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
% FAR-FAR D errormin

textox = 'C_{test}   (Low freq. Diag.)';
textoy = ['Response (Mask High freq. Vert.)'];

R = Rdll3;
MM = max(R(1,:));
R = R/MM;
sR = sRdll3/MM;

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
        
        
out_fold = '/media/disk/vista/Papers/after_effects/paper/Frontiers LaTeX (Science, Medicine and Engineering) V2.3 - with Supplementary material/images/'; 
print('-deps2c','-f1',[out_fold 'resp_h_cerca.eps'])
print('-deps2c','-f2',[out_fold 'resp_h3_cerca.eps'])
print('-deps2c','-f3',[out_fold 'resp_d_cerca.eps'])
print('-deps2c','-f4',[out_fold 'resp_d3_cerca.eps'])

print('-deps2c','-f5',[out_fold 'resp_h_lejos.eps'])
print('-deps2c','-f6',[out_fold 'resp_h3_lejos.eps'])
print('-deps2c','-f7',[out_fold 'resp_d_lejos.eps'])
print('-deps2c','-f8',[out_fold 'resp_d3_lejos.eps'])

print('-deps2c','-f9',[out_fold 'resp_ho_lejos.eps'])
print('-deps2c','-f10',[out_fold 'resp_ho3_lejos.eps'])
print('-deps2c','-f11',[out_fold 'resp_do_lejos.eps'])
print('-deps2c','-f12',[out_fold 'resp_do3_lejos.eps'])

% print(203,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h_cerca.eps'])
% print(603,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h_lejos.eps'])
% print(1003,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_ho_lejos.eps'])
% print(303,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h3_cerca.eps'])
% print(703,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h3_lejos.eps'])
% print(1103,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_ho3_lejos.eps'])
% 
% print(403,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d_cerca.eps'])
% print(803,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d_lejos.eps'])
% print(1203,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_do_lejos.eps'])
% print(503,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d3_cerca.eps'])
% print(903,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d3_lejos.eps'])
% print(1303,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_do3_lejos.eps'])

tile