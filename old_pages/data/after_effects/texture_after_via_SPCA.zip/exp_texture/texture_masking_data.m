%
% En este script voy a calcular las respuestas SPCA a contrastes de
% funciones PCA de patches 15x15 de imágenes naturales.
% En lugar de lanzar SPCA sobre las 225 dimensiones, tomaré la componente
% de continua (para que la primera curva principal salga bien ;-) y luego,
% en cada caso, tomaré la rolancha correspondiente entorno a las
% dimensiones que esté considerando, de forma que restringiré el problema
% para que sea 3D.
%
% Los datos y PCA preliminar se calcularon en 
%      /media/raid5/vista/Software/RBIG_extras/metrica_usando_rbig/metrica_contraste/funciones
%      generacion_datos.m
%      gaussianiza_McGill.m
% El resultado del PCA está en:
%      /media/raid5/vista/Software/RBIG_extras/metrica_usando_rbig/metrica_contraste/imagenes15x15_1
%                                                                                    pca_images15x15_1
%
% Los conjuntos de puntos (imagenes) en diferentes planos de componentes PCA 
% en el punto de luminancia media serán:
%
% INTERACCION HORIZONTAL-VERTICAL A DISTINTAS FRECUENCIAS
%
% * caso 1: componentes 13 y 15 del PCA (bajas frecuencias vertical y 
%           horizontal).
%
% * caso 2: componentes 43 y 45 del PCA (medias frecuencias vertical y 
%           horizontal).
%
% * caso 3: componentes 87 y 85 del PCA (altas frecuencias vertical y 
%           horizontal).
%
% INTERACCION FRECUENCIAL PARA ORIENTACION CONSTANTE
%
% * caso 4: componentes 13 y 43 del PCA (vertical baja y media frecuencia).
% * caso 4bis: componentes 15 y 45 del PCA (horiz baja y media frecuencia).
%
% * caso 5: componentes 13 y 87 del PCA (vertical baja y alta frecuencia).
% * caso 5bis: componentes 15 y 85 del PCA (horiz baja y alta frecuencia).
%


destination_folder = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/data/natural_data_texture';

% Load raw data

% load('pca_images15x15_1','B','L','m','imagenes15x15_1_pca')
load('pca_images15x15_1','B','L','m')

% Recordemos lo que significan las dimensiones en el espacio original

figure(1),colormap gray,imm=disp_patches(B,15);
immm=imm(145:end,:);
figure(1),colormap gray,imagesc(fliplr(flipud(immm))),axis off,axis equal
% %%print -f1 -deps2c /media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/func_base.eps


% Extraigamos las funciones base consideradas

       % horizontales

             ph=[10 15 21 28 37 45 85];
             
       % verticales
       
             pv=[9 13 19 26 34 43 87];
             
       % diagonales
       
             pd=[11 16 22 29 36 44 88];

p=ph;             
for i=1:length(p)
    im=reshape(B(:,end-p(i)+1),15,15);
    tf_im=abs(fftshift(fft2(im)));
    figure(20),colormap gray,imagesc(im),axis square,axis off
    figure(21),colormap gray,imagesc(tf_im),axis square,axis off
    %%print(20,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/func_base_',num2str(p(i)),'.eps'])
    %%print(21,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/tf_func_base_',num2str(p(i)),'.eps'])
    figure(2),subplot(2,length(p),i);colormap gray,imagesc(im),title(num2str(p(i))),axis off,axis square
    figure(2),subplot(2,length(p),length(p)+i);colormap gray,imagesc(tf_im),axis off,axis square    
end

p=pv;             
for i=1:length(p)
    im=reshape(B(:,end-p(i)+1),15,15);
    tf_im=abs(fftshift(fft2(im)));
    figure(20),colormap gray,imagesc(im),axis square,axis off
    figure(21),colormap gray,imagesc(tf_im),axis square,axis off
    %%print(20,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/func_base_',num2str(p(i)),'.eps'])
    %%print(21,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/tf_func_base_',num2str(p(i)),'.eps'])

    figure(3),subplot(2,length(p),i);colormap gray,imagesc(im),title(num2str(p(i))),axis off,axis square
    figure(3),subplot(2,length(p),length(p)+i);colormap gray,imagesc(tf_im),axis off,axis square    
end

p=pd;             
for i=1:length(p)
    im=reshape(B(:,end-p(i)+1),15,15);
    tf_im=abs(fftshift(fft2(im)));
    figure(20),colormap gray,imagesc(im),axis square,axis off
    figure(21),colormap gray,imagesc(tf_im),axis square,axis off
    %%print(20,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/func_base_',num2str(p(i)),'.eps'])
    %%print(21,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/tf_func_base_',num2str(p(i)),'.eps'])
    figure(4),subplot(2,length(p),i);colormap gray,imagesc(im),title(num2str(p(i))),axis off,axis square
    figure(4),subplot(2,length(p),length(p)+i);colormap gray,imagesc(tf_im),axis off,axis square    
end

% Vale, estan bien

% Desviacion (amplitudes o contrastes) de los coeficientes en cada funcion base

desv=diag(L).^(1/2);

d=length(diag(L));

norm=mean(m)*(sqrt(d));  %

norm=40/0.05;            % Normalizacion empirica: comprobe que el contraste de michaelson de una delta con amplitud 40 era 0.05
k=5;norm=40/(k*0.05);       % Esto significa aumentar (arificialmente) el contraste por un factor k

figure,semilogy(1:d,desv/norm)
       hold on,semilogy(d-ph+1,desv(d-ph+1)/norm,'bo')
       hold on,semilogy(d-pv+1,desv(d-pv+1)/norm,'ro')
       hold on,semilogy(d-pd+1,desv(d-pd+1)/norm,'go')

% % DISTINTAS PROYECCIONES DE LOS DATOS
% 
% for ii=2:7
%     dim=[1 pv(1) pv(ii)];
%     pos=225-dim+1;
%     no_pos=find(([1:d]~=pos(1))&([1:d]~=pos(2))&([1:d]~=pos(3)));
%     
%     umbral_contraste=k*0.05;
%     
%     rolancha = ones(1,length(imagenes15x15_1_pca(1,:)));
%     
%     for i=1:length(no_pos)
%         %i
%         condi = abs(imagenes15x15_1_pca(no_pos(i),:)/norm)<umbral_contraste;
%         rolancha=rolancha.*condi;
%     end
%     ptos=find(rolancha>0);
%     
%     dat = imagenes15x15_1_pca(pos,ptos)/norm;
%     figure,plot3(dat(1,1:5:end),dat(2,1:5:end),dat(3,1:5:end),'b.'),axis equal
%     
%     umbral1=k*0.5;
%     puntis=find((dat(1,:)>-umbral1)&(dat(1,:)<umbral1));
%     dat=dat(:,puntis);
%     size(puntis)
%     figure,plot3(dat(1,:),dat(2,:),dat(3,:),'b.'),axis equal
% end


% DISTINTAS PROYECCIONES DE LOS DATOS BLANQUEADOS

     % datw=diag(1./desv)*imagenes15x15_1_pca;

load('imagenes15x15_1.mat')

imagenes15x15_1_pca=B'*imagenes15x15_1;
clear imagenes15x15_1

datw=diag(1./desv)*imagenes15x15_1_pca;

clear imagenes15x15_1_pca


FS=21;

% Horizontal proxima y horizontal lejana
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
titulo=['Horizontal close';'Horizontal far  '];
lala=1;

for ii=[2 7]
    
    dim=[1 ph(1) ph(ii)];
    %dim=[1 ph(2) ph(ii)];
    
    pos=225-dim+1;
    no_pos=find(([1:d]~=pos(1))&([1:d]~=pos(2))&([1:d]~=pos(3)));
    
    umbral_contraste=0.45;
    
    rolancha = ones(1,length(datw(1,:)));
    
    for i=1:length(no_pos)
        %i
        condi = abs(datw(no_pos(i),:))<umbral_contraste;
        rolancha=rolancha.*condi;
    end
    ptos=find(rolancha>0);
    size(ptos)
    
    dat = datw(pos,ptos);
    figure,plot3(dat(1,1:5:end),dat(2,1:5:end),dat(3,1:5:end),'b.'),axis equal
    
    umbral1=0.5;
    puntis=find((dat(1,:)>-umbral1)&(dat(1,:)<umbral1));
    dat=dat(:,puntis);
    size(puntis)
    figure(100),clf,plot(dat(2,:),dat(3,:),'b.'),
    minimo=-0.12;
    maximo=0.12;
    %axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{',num2str(ph(1)),'}']),ylabel(['C_{',num2str(ph(ii)),'}'])
    if ii==2
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. horiz.)'],'fontsize',FS),ylabel(['C_{mask} (low freq. horiz.)'],'fontsize',FS)
    else
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. horiz.)'],'fontsize',FS),ylabel(['C_{mask} (high freq. horiz.)'],'fontsize',FS)
    end
        hold on,plot([0 0],[minimo maximo],'g-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',3)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',3)   
    set(get(gcf,'Children'),'FontSize',FS)
    if ii==2
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_h_close.eps'])
    else
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_h_far.eps']) 
    end
    %title(titulo(lala,:))
    if lala==1
       dat_fh_proxim=dat; 
    else
       dat_fh_lej=dat; 
    end

    lala=lala+1;
end

% Diagonal proxima y diagonal lejana
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
titulo=['Diagonal close';'Diagonal far  '];
lala=1;
for ii=[3 7]
    dim=[1 pd(2) pd(ii)];
    %dim=[1 ph(2) ph(ii)];
    
    pos=225-dim+1;
    no_pos=find(([1:d]~=pos(1))&([1:d]~=pos(2))&([1:d]~=pos(3)));
    
    umbral_contraste=0.45;
    
    rolancha = ones(1,length(datw(1,:)));
    
    for i=1:length(no_pos)
        %i
        condi = abs(datw(no_pos(i),:))<umbral_contraste;
        rolancha=rolancha.*condi;
    end
    ptos=find(rolancha>0);
    size(ptos)
    
    dat = datw(pos,ptos);
    figure,plot3(dat(1,1:5:end),dat(2,1:5:end),dat(3,1:5:end),'b.'),axis equal
    
    umbral1=0.5;
    puntis=find((dat(1,:)>-umbral1)&(dat(1,:)<umbral1));
    dat=dat(:,puntis);
    size(puntis)
    figure(100),clf,plot(dat(2,:),dat(3,:),'b.'),
    minimo=-0.12;
    maximo=0.12;
    %axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{',num2str(pd(2)),'}']),ylabel(['C_{',num2str(pd(ii)),'}'])
    if ii==3
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. diag.)'],'fontsize',FS),ylabel(['C_{mask} (low freq. diag.)'],'fontsize',FS)
    else
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. diag.)'],'fontsize',FS),ylabel(['C_{mask} (high freq. diag.)'],'fontsize',FS)
    end
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',3)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',3)   
    set(get(gcf,'Children'),'FontSize',FS)
    if ii==3
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_d_close.eps'])
    else
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_d_far.eps']) 
    end    
    %title(titulo(lala,:))
    if lala==1
       dat_fd_proxim=dat; 
    else
       dat_fd_lej=dat; 
    end
    
    lala=lala+1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Frec/Orient proximas y lejanas 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
titulo=['Frec/Orient cercanas 3';'Frec/Orient lejanas  3'];
lala=1;
for ii=1:2
    
    if ii==1
       dim=[1 ph(1) ph(2)];
    else
       dim=[1 ph(1) pd(7)]; 
    end
    %dim=[1 ph(2) ph(ii)];
    
    pos=225-dim+1;
    no_pos=find(([1:d]~=pos(1))&([1:d]~=pos(2))&([1:d]~=pos(3)));
    
    umbral_contraste=0.45;
    
    rolancha = ones(1,length(datw(1,:)));
    
    for i=1:length(no_pos)
        %i
        condi = abs(datw(no_pos(i),:))<umbral_contraste;
        rolancha=rolancha.*condi;
    end
    ptos=find(rolancha>0);
    size(ptos)
    
    dat = datw(pos,ptos);
    figure,plot3(dat(1,1:5:end),dat(2,1:5:end),dat(3,1:5:end),'b.'),axis equal
    
    umbral1=0.5;
    puntis=find((dat(1,:)>-umbral1)&(dat(1,:)<umbral1));
    dat=dat(:,puntis);
    size(puntis)
    figure(100),clf,plot(dat(2,:),dat(3,:),'b.'),
    minimo=-0.12;
    maximo=0.12;
    %axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{',num2str(pd(2)),'}']),ylabel(['C_{',num2str(pd(ii)),'}'])
    if ii==1
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. horiz.)'],'fontsize',FS),ylabel(['C_{mask} (low freq. horiz.)'],'fontsize',FS)
    else
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. horiz.)'],'fontsize',FS),ylabel(['C_{mask} (high freq. diag.)'],'fontsize',FS)
    end
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',3)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',3)   
    set(get(gcf,'Children'),'FontSize',FS)
    if ii==1
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_fo3_close.eps'])
    else
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_fo3_far.eps']) 
    end    
    if lala==1
       dat_fo3_proxim=dat; 
    else
       dat_fo3_lej=dat; 
    end    
    lala=lala+1;
end

% Frec/Orient proximas y lejanas 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
titulo=['Frec/Orient cercanas 4';'Frec/Orient lejanas  4'];
lala=1;
for ii=1:2
    
    if ii==1
       dim=[1 pd(1) pd(2)];
    else
       dim=[1 pd(1) pv(7)]; 
    end
    %dim=[1 ph(2) ph(ii)];
    
    pos=225-dim+1;
    no_pos=find(([1:d]~=pos(1))&([1:d]~=pos(2))&([1:d]~=pos(3)));
    
    umbral_contraste=0.45;
    
    rolancha = ones(1,length(datw(1,:)));
    
    for i=1:length(no_pos)
        %i
        condi = abs(datw(no_pos(i),:))<umbral_contraste;
        rolancha=rolancha.*condi;
    end
    ptos=find(rolancha>0);
    size(ptos)
    
    dat = datw(pos,ptos);
    figure,plot3(dat(1,1:5:end),dat(2,1:5:end),dat(3,1:5:end),'b.'),axis equal
    
    umbral1=0.5;
    puntis=find((dat(1,:)>-umbral1)&(dat(1,:)<umbral1));
    dat=dat(:,puntis);
    size(puntis)
    figure(100),clf,plot(dat(2,:),dat(3,:),'b.'),
    minimo=-0.12;
    maximo=0.12;
    %axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{',num2str(pd(2)),'}']),ylabel(['C_{',num2str(pd(ii)),'}'])
    if ii==1
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. diag.)'],'fontsize',FS),ylabel(['C_{mask} (low freq. diag.)'],'fontsize',FS)
    else
        axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (low freq. diag.)'],'fontsize',FS),ylabel(['C_{mask} (high freq. vert.)'],'fontsize',FS)
    end
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',3)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',3)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',3) 
    set(get(gcf,'Children'),'FontSize',FS)
    if ii==1
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_fo4_close.eps'])
    else
       %%print(100,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/scatter_fo4_far.eps']) 
    end    

    if lala==1
       dat_fo4_proxim=dat; 
    else
       dat_fo4_lej=dat; 
    end      
    lala=lala+1;
end

% CONCLUSIONES DE LA INSPECCION DE LAS PROYECCIONES
%
%   - Parece que la dependenceia con la frecuencia SI va a salir porque
%     cuando la diferencia de frecuencia es grande, el scatter plot es mas
%     uniforme en la dirección vertical, i.e. la componente enmascaradora
%     NO influye!
%
%   - Tomando frecuencia Y orientacion proximas y lejanas tambien sale
%

save([destination_folder,'same_orientation_data'],'dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
save([destination_folder,'different_orientation_data'],'dat_fo3_lej','dat_fo3_proxim','dat_fo4_lej','dat_fo4_proxim')    

