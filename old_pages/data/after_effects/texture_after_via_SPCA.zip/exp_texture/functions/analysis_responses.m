%
% Analysis of the responses of horizontal sensor and diagonal sensor
% (computed by texture_masking_experiment.m)
%
%

close all
clc

graficas_respuestas('respuestas_fh_cerca',[-0.01 0.3 -5 100],'C_{low freq. horiz.}','Resp. (low freq. horiz. mask)',3,23,200)
figure(gcf),title('HORIZ. SENSOR (\gamma=1)')
graficas_respuestas('respuestas_fh3_cerca',[-0.01 0.3 -5 80],'C_{low freq. horiz.}','Resp. (low freq. horiz. mask)',3,23,300)
figure(gcf),title('HORIZ. SENSOR (\gamma=1/3)')

graficas_respuestas('respuestas_fd_cerca',[-0.01 0.3 -5 100],'C_{low freq. diag.}','Resp. (low freq. diag. mask)',3,23,400)
figure(gcf),title('DIAGONAL SENSOR (\gamma=1)')
graficas_respuestas('respuestas_fd3_cerca',[-0.01 0.3 -5 80],'C_{low freq. diag.}','Resp. (low freq. diag. mask)',3,23,500)
figure(gcf),title('DIAGONAL SENSOR (\gamma=1/3)')

graficas_respuestas('respuestas_fh_lej',[-0.01 0.3 -5 100],'C_{low freq. horiz.}','Resp. (high freq. horiz. mask)',3,23,600)
graficas_respuestas('respuestas_fh3_lej',[-0.01 0.3 -5 80],'C_{low freq. horiz.}','Resp. (high freq. horiz. mask)',3,23,700)

graficas_respuestas('respuestas_fd_lej',[-0.01 0.3 -5 100],'C_{low freq. diag.}','Resp. (high freq. diag. mask)',3,23,800)
graficas_respuestas('respuestas_fd3_lej',[-0.01 0.3 -5 80],'C_{low freq. diag.}','Resp. (high freq. diag. mask)',3,23,900)

graficas_respuestas('respuestas_fo3_lej',[-0.01 0.3 -5 100],'C_{low freq. horiz.}','Resp. (high freq. diag. mask)',3,23,1000)
graficas_respuestas('respuestas_fo33_lej',[-0.01 0.3 -5 80],'C_{low freq. horiz.}','Resp. (high freq. diag. mask)',3,23,1100)

graficas_respuestas('respuestas_fo4_lej',[-0.01 0.3 -5 100],'C_{low freq. diag.}','Resp. (high freq. vert. mask)',3,23,1200)
graficas_respuestas('respuestas_fo43_lej',[-0.01 0.3 -5 80],'C_{low freq. diag.}','Resp. (high freq. vert. mask)',3,23,1300)

% [C,R1n,sR1n]=graph_motion_resp('respuestas_fo4_lej',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,100)

% print(203,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h_cerca.eps'])
% print(603,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h_lejos.eps'])
% print(1003,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_ho_lejos.eps'])
% print(303,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h3_cerca.eps'])
% print(703,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_h3_lejos.eps'])
% print(1103,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_ho3_lejos.eps'])
% 
% print(403,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d_cerca.eps'])
% print(803,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d_lejos.eps'])
% print(1203,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_do_lejos.eps'])
% print(503,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d3_cerca.eps'])
% print(903,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_d3_lejos.eps'])
% print(1303,'-deps2c',['/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment/resp_do3_lejos.eps'])

tile