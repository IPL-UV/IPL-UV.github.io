%
% In this script I load the linear image texture data of selected coefficients
% (see texture_image_data.m) and compute the Mutual Information
%

source_folder = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/data/natural_data_texture/'

load([source_folder,'same_orientation_data'],'dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
load([source_folder,'different_orientation_data'],'dat_fo3_lej','dat_fo3_proxim','dat_fo4_lej','dat_fo4_proxim')    

mutuals = [];

dat = dat_fh_proxim;
MI = mutual_information_4(dat(2,:),dat(3,:),round(sqrt(length(dat(1,:)))));
mutuals = [mutuals MI];

dat = dat_fh_lej;
MI = mutual_information_4(dat(2,:),dat(3,:),round(sqrt(length(dat(1,:)))));
mutuals = [mutuals MI];

dat = dat_fo3_lej;
MI = mutual_information_4(dat(2,:),dat(3,:),round(sqrt(length(dat(1,:)))));
mutuals_h = [mutuals MI];


mutuals = [];

dat = dat_fd_proxim;
MI = mutual_information_4(dat(2,:),dat(3,:),round(sqrt(length(dat(1,:)))));
mutuals = [mutuals MI];

dat = dat_fd_lej;
MI = mutual_information_4(dat(2,:),dat(3,:),round(sqrt(length(dat(1,:)))));
mutuals = [mutuals MI];

dat = dat_fo4_lej;
MI = mutual_information_4(dat(2,:),dat(3,:),round(sqrt(length(dat(1,:)))));
mutuals_d = [mutuals MI];

mutuals_h
mutuals_d