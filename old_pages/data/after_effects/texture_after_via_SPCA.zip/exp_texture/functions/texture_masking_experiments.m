% --------------------------------------------
% SPCA DERIVATION OF CONTRAST MASKING (GENERAL DESCRIPTION)
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% In this experiment we computed the non-linear response of SPCA sensors to
% periodic patterns as in the masking experiments of the vision science 
% literature [Foley94, Watson97]. Different SPCA optimization criteria were
% used to (1) check the kind of nonlinearities that emerge from data in those
% cases and (2) to test different statistical explanations (organization principles) 
% that may be behind the psychophysical behavior of texture sensors in the
% brain.
%
% To this end, we considered test patterns of low frequency -horizontal and diagonal- 
% shown on top of different masking patterns. See show_texture_data_masking.m
% for examples of such patterns. The whole dataset for the masking experiment 
% is prepared in the script texture_masking_data.m
% 
% For each test pattern we computed the response in three scenarios: 
%   (1) test shown on top of a mask of similar frequency and orientation,
%   (2) test shown on top of a mask of different frequency but similar orientation, 
%   (3) test shown on top of a mask of different frequency and different orientation. 
% In each case, we considered the no-masking situation, in which the test 
% was shown on top of no mask (zero contrats mask), and different, 
% progressively stronger, masking situations, in which the test was show on 
% top of mask with progressively higher contrast.
%
% The software to perform these simulations (reproducing the results in the paper) 
% is organized as follows:
%
%    1- Data for the experiment:  
%
%       *  pre_processing.m        
%
%               This script extracts 15x15 patches from the McGill database 
%               and computes PCA on these patches.
%
%       *  texture_masking_data.m  
%
%               This scripts extracts samples nearby 3d subspaces in the 
%               selected PCA directions. It generates two files:
%                     1.1 same_orientation_data.mat
%                              dat_fd_lej    ->  Test low-freq. diag & Mask high-freq. diag 
%                              dat_fd_proxim ->  Test low-freq. diag & Mask low-freq. diag 
%                              dat_fh_lej    ->  Test low-freq. horiz & Mask high-freq. horiz 
%                              dat_fh_proxim ->  Test low-freq. horiz & Mask low-freq. horiz 
%                     1.2 different_orientation_data.mat
%                              dat_fo3_lej ->  Test low-freq. horiz & Mask low-freq. diagonal 
%                              dat_fo4_lej ->  Test low-freq. diag & Mask high-freq. vertical 
%
%    2- Computation of the responses from the texture data: 
%
%           texture_masking_experiment_X.m  (where X=1,...,6)
%                     experimento_masking_texturas.m
%
%                     We splitted the processing of the above data files in
%                     six parts to make the computations in parallel
%
%    3- Show results (responses):
%
%           analysis_responses.m
%                     graficas_respuestas.m
%
% Consideration of 2 sensors (2 stimulation directions), 3 masking stimuli, 
% and 2 criteria, gives rise to 12 files with results:
%
% INFOMAX CRITERION:
%
%  * Test (optimal sensor): low-freq. horiz 
%         . Mask 1: low-freq. horiz     -> output file: respuestas_fh_cerca   
%         . Mask 2: high-freq. horiz    -> output file: respuestas_fh_lej   
%         . Mask 3: high-freq. diagonal -> output file: respuestas_fo3_lej   
%
%  * Test (optimal sensor): low-freq. diagonal 
%         . Mask 1: low-freq. diagonal  -> output file: respuestas_fd_cerca   
%         . Mask 2: high-freq. diagonal -> output file: respuestas_fd_lej  
%         . Mask 3: high-freq. vertical -> output file: respuestas_fo4_lej   
%
% ERROR MINIMIZATION CRITERION:
%
%  * Test (optimal sensor): low-freq. horiz 
%         . Mask 1: low-freq. horiz     -> output file: respuestas_fh3_cerca   
%         . Mask 2: high-freq. horiz    -> output file: respuestas_fh3_lej   
%         . Mask 3: high-freq. diagonal -> output file: respuestas_fo33_lej   
%
%  * Test (optimal sensor): low-freq. diagonal 
%         . Mask 1: low-freq. diagonal  -> output file: respuestas_fd3_cerca   
%         . Mask 2: high-freq. diagonal -> output file: respuestas_fd3_lej  
%         . Mask 3: high-freq. vertical -> output file: respuestas_fo43_lej   
%
% In each case 9 contrast (zero, four positive and four negative) in the 
% masking stimuli are considered, and 21 test points per masking contrast, 
% i.e. a total of 189 test points. 
% 
% In a Dell PowerEdge 2900 processor initialization takes 25 secs and 
% transforms take 28 secs/sample, i.e. a total of 1.5 hours per data file.
% 
% By splitting the experiment in 6 parts, if you have 6 processors the
% whole experiment will be done in 3 hours.
%
% If you find this slow, think about measuring this psychophysically or
% physiologically...
%

analysis_responses_2

% destination_folder = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/exp_neuroscience/';
% 
% % Exp. 1
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_lej,2,[destination_folder,'respuestas_fh_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_proxim,2,[destination_folder,'respuestas_fh_cerca']);
%
% % Exp. 2
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_lej,2,[destination_folder,'respuestas_fd_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_proxim,2,[destination_folder,'respuestas_fd_cerca']);
% 
% % Exp. 3
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_lej,3,[destination_folder,'respuestas_fh3_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_proxim,3,[destination_folder,'respuestas_fh3_cerca']);
% 
% % Exp. 4
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_lej,3,[destination_folder,'respuestas_fd3_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_proxim,3,[destination_folder,'respuestas_fd3_cerca']);
% 
% % Exp. 5
% load('different_orientation_data','dat_fo1_lej','dat_fo1_proxim','dat_fo2_lej','dat_fo2_proxim','dat_fo3_lej','dat_fo3_proxim','dat_fo4_lej','dat_fo4_proxim')    
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo3_lej,2,[destination_folder,'respuestas_fo3_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo4_lej,2,[destination_folder,'respuestas_fo4_lej']);
% 
% % Exp. 6
% load('different_orientation_data','dat_fo1_lej','dat_fo1_proxim','dat_fo2_lej','dat_fo2_proxim','dat_fo3_lej','dat_fo3_proxim','dat_fo4_lej','dat_fo4_proxim')    
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo3_lej,3,[destination_folder,'respuestas_fo33_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo4_lej,3,[destination_folder,'respuestas_fo43_lej']);