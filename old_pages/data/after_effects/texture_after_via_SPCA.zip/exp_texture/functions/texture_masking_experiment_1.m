% TEXTURE MASKING EXPERIMENT (part 1/6) 
%
% In these scripts we compute the response of the SPCA sensor tuned to selected 
% directions of the image texture space (low frequency horizontal and low
% frequency diagonal) in the no-masking condition (for zero contrast of the
% other components), and in progressively stronger masking conditions. And
% this is done for different masking stimuli and SPCA criteria:
%
% Consideration of 2 sensors (2 stimulation directions), 3 masking stimuli, 
% and 2 criteria, give rise to 12 files with results:
%
% INFOMAX CRITERION:
%
%  * Test (optimal sensor): low-freq. horiz 
%         . Mask 1: low-freq. horiz     -> output file: respuestas_fh_cerca   
%         . Mask 2: high-freq. horiz    -> output file: respuestas_fh_lej   
%         . Mask 3: high-freq. diagonal -> output file: respuestas_fo3_lej   
%
%  * Test (optimal sensor): low-freq. diagonal 
%         . Mask 1: low-freq. diagonal  -> output file: respuestas_fd_cerca   
%         . Mask 2: high-freq. diagonal -> output file: respuestas_fd_lej  
%         . Mask 3: high-freq. vertical -> output file: respuestas_fo4_lej   
%
% ERROR MINIMIZATION CRITERION:
%
%  * Test (optimal sensor): low-freq. horiz 
%         . Mask 1: low-freq. horiz     -> output file: respuestas_fh3_cerca   
%         . Mask 2: high-freq. horiz    -> output file: respuestas_fh3_lej   
%         . Mask 3: high-freq. diagonal -> output file: respuestas_fo33_lej   
%
%  * Test (optimal sensor): low-freq. diagonal 
%         . Mask 1: low-freq. diagonal  -> output file: respuestas_fd3_cerca   
%         . Mask 2: high-freq. diagonal -> output file: respuestas_fd3_lej  
%         . Mask 3: high-freq. vertical -> output file: respuestas_fo43_lej   
%
% In each case 9 contrast (zero, four positive and four negative) in the 
% masking stimuli are considered, and 21 test points per contrast, 
% i.e. a total of 189 test points. 
% 
% In a Dell PowerEdge 2900 processor initialization takes 25 secs and 
% transforms take 28 secs/sample, i.e. a total of 1.5 hours.
% If you think this is slow, think about measuring this psychophysically or
% physiologically.
% 
% By splitting the experiment in 6 parts, if you have 6 processors the
% whole experiment will be done in 3 hours.
%

destination_folder = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/exp_neuroscience/';

% Exp. 1
load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_lej,2,[destination_folder,'respuestas_fh_lej']);
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_proxim,2,[destination_folder,'respuestas_fh_cerca']);

% % Exp. 2
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_lej,2,[destination_folder,'respuestas_fd_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_proxim,2,[destination_folder,'respuestas_fd_cerca']);
% 
% % Exp. 3
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_lej,3,[destination_folder,'respuestas_fh3_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fh_proxim,3,[destination_folder,'respuestas_fh3_cerca']);
% 
% % Exp. 4
% load('same_orientation_data','dat_fd_lej','dat_fd_proxim','dat_fh_lej','dat_fh_proxim')
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_lej,3,[destination_folder,'respuestas_fd3_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fd_proxim,3,[destination_folder,'respuestas_fd3_cerca']);
% 
% % Exp. 5
% load('different_orientation_data','dat_fo1_lej','dat_fo1_proxim','dat_fo2_lej','dat_fo2_proxim','dat_fo3_lej','dat_fo3_proxim','dat_fo4_lej','dat_fo4_proxim')    
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo3_lej,2,[destination_folder,'respuestas_fo3_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo4_lej,2,[destination_folder,'respuestas_fo4_lej']);
% 
% % Exp. 6
% load('different_orientation_data','dat_fo1_lej','dat_fo1_proxim','dat_fo2_lej','dat_fo2_proxim','dat_fo3_lej','dat_fo3_proxim','dat_fo4_lej','dat_fo4_proxim')    
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo3_lej,3,[destination_folder,'respuestas_fo33_lej']);
% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_fo4_lej,3,[destination_folder,'respuestas_fo43_lej']);