% ------------------------------------
% DEMO on VISUAL AFTEREFFECTS
%
% V. Laparra & J. Malo 
% Universitat de Valencia 2014
% ------------------------------------
%
% In this script we explore motion, color, and contrast aftereffects.
% This script calls:
%      motion_aftereffects.m
%      color_aftereffects.m
%      contrast_aftereffects.m
% 
% Please look at these scripts helps for a more detailed description.
% Note that this demo requires the installation of:
%    BasicVideoTools  (http://isp.uv.es/Basic_Video.html)
%    ColorLab         (http://isp.uv.es/colorlab.html)
%

      motion_aftereffects
      color_aftereffects
      contrast_aftereffects
