function [gs,gc]=sens_gabor2d_spac(x,y,xo,yo,fx,fy,delta_x,delta_y)

% SENS_GABOR2D_SPAC genera el campo receptivo (fila del kernel de
% convolucion) de un sensor de Gabor 2D definido por sus parametros en el
% dominio espacial (posicion, anchura espacial, y frecuencia espacial).
%
% La envolvente gaussiana esta orientada segun los ejes cartesianos
%
% El programa devuelve la parte par (cos) y la parte impar (sin)
%
% Las expresiones utilizadas son:
%
%   gs(x)=B*exp(-(x-x0)'*A^-1*(x-x0)).*sin(2*pi*fx*(x-x0))
%   gc(x)=B*exp(-(x-x0)'*A^-1*(x-x0)).*cos(2*pi*fx*(x-x0))
%
% donde la matriz A es diagonal y contiene las anchuras en las direcciones x1 y x2
%
%           / Delta_x1^2      0     \
%       A = |                        |
%           \    0       Delta_x2^2 /
%
% Hay que pasarle un dominio bidimensional (generado por ejemplo con
% meshgrid)
%
% El parametro B es un factor de normalizacion para que la energia 
% (sum(g.^2)) sea unidad
%
% USO: [gs,gc]=sens_gabor2d_spac(x1,x2,xo1,xo2,fx1,fx2,delta_x1,delta_x2)
%

gs=exp(-(x-xo).^2/delta_x^2-(y-yo).^2/delta_y^2).*sin(2*pi*(fx*(x-xo)+fy*(y-yo)));
gc=exp(-(x-xo).^2/delta_x^2-(y-yo).^2/delta_y^2).*cos(2*pi*(fx*(x-xo)+fy*(y-yo)));

gs=gs./sqrt(sum(sum(gs.^2)));
gc=gc./sqrt(sum(sum(gc.^2)));