% VISUAL ILLUSIONS IN YOUTUBE:
%
%   MOTION:
%
%      Horizontal Motion Aftereffect (noise)
%                  http://youtu.be/ToXalRJiq8E
% 
%      Horizontal Motion Aftereffect (natural)
%                  http://youtu.be/LLtaVCUmltE
%
%      Vertical Motion Aftereffect (natural)
%                 http://youtu.be/2fLoWxVeN-g
%
%      Vertical Motion Aftereffect (noise)
%                 http://youtu.be/0G0rXqvwR0Q
%
%  COLOR:
%
%     Simple configuration (Albers-like painting)
%                  http://youtu.be/WBCzhokJfyA
%
%     Diverse reflectance configuration
%                  http://youtu.be/GeylNFVX66Y 
%
%     Natural image
%                  http://youtu.be/E5040GE6Wig
%
% CONTRAST (Gabors)
%     
%     MASK: high freq. diag. TEST: low freq. diag.
%                   http://youtu.be/XkTWnJxIlxY
%
%     MASK: high freq diag TEST: low freq horiz
%                   http://youtu.be/h4yDSrxo3Gk
%
%     MASK: high freq horiz TEST: low freq horiz
%                   http://youtu.be/MJkYUA-55TI
%
%     MASK: high freq vert TEST low freq diag
%                   http://youtu.be/JeHp0z4Q6YY
%
%     MASK: low freq diag TEST low freq diag
%                   http://youtu.be/GeA2Pyi6Ed4
%
%     MASK: low freq horiz TEST low freq horiz
%                   http://youtu.be/fHRBGlN9B00
%
% CONTRAST (PCA basis functions)
%     
%     MASK: high freq. diag. TEST: low freq. diag.
%                    http://youtu.be/oETMQtBUzuE
%
%     MASK: high freq diag TEST: low freq horiz
%                    http://youtu.be/fTbmvfUqCGI
%
%     MASK: high freq horiz TEST: low freq horiz
%                    http://youtu.be/Df1aSgwPQ_w
%
%     MASK: high freq vert TEST low freq diag
%                    http://youtu.be/UnEXEwJQJs0
%
%     MASK: low freq diag TEST low freq diag
%                    http://youtu.be/2VJLL6J4ons
%
%     MASK: low freq horiz TEST low freq horiz
%                    http://youtu.be/f04qjmeH-74
%
