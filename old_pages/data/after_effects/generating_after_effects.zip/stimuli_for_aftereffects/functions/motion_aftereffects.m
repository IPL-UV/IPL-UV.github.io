% ------------------------------------
% DEMO on MOTION AFTEREFFECTS
%
% V. Laparra & J. Malo 
% Universitat de Valencia 2014
% ------------------------------------
%
% In this script we generate stimuli to illustrate the Static Motion Aftereffect
%
% We build sequences with vertical or horizontal motion (both using noise
% or natural images).
%
% In every case, half of the sequence moves slowly (0.2 deg/sec) while the
% other half moves substantially faster (2.5 deg/sec). 
% 
% Look at the fixation point and wait for the sequence to stop.
% What do you see?
%
% NOTE: You have the option of printing representative images and generating 
% *.avi files with the illusions by choosing print_figures = 1. 
% (see the first line of the code)
% In this case you have to specify the path where you want the files stored.
% If you choose print_figures = 0 the program just shows the movies but
% prints nothing.
% 
% NOTE: see the help of moise_sequence.m and image_sequence.m of the 
% BasicVideoTools (http://isp.uv.es/Basic_Video.html) for the meaning of the 
% control parameters
%

print_figures = 0;
%    output_folder = 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\code\stimuli_after\motion\';
    output_folder = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/stimuli_after/motion/';
    
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
%%  
%%  Static Motion After-effect (Waterfall effect)
%%  
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%

% Domain parameters
ne=40;
nt=200;
fse=40;
fst=20;

% Noise parameters
fm=0;
fM=fse/5;
anch_ang=179.9;
orient=0;
v=[-0.2 0;-2.5 0];

% Sequence using a natural image

load Y_3
Y = sqrt(Y);
Y = 64*Y/max(Y(:));
im= [Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end);Y(1:4:end,1:4:end)];
im= [im;im;im;im];

% Generate two sequences with different speed and merge them

for vv =1:2

    Lm=128;
    C=1;

    % Ruido
    [s,v_real] = noise_sequence(ne,nt,fse,fst,fm,fM,anch_ang,orient,v(vv,:),1);
    S=Lm*(1+2*C*(s-0.5));
    [s3, v_true ] = image_sequence( im , [40 70] , ne , nt , fse , fst, -v(vv,:), 1);
    
    cond=ones(40,40);
    cond(18:22,20)=zeros(5,1);
    cond(20,18:22)=zeros(1,5);

    S = S/4;
    for i=1:nt
        fotog=sacafot(S,ne,ne,i);
        fotog=fotog.*cond;
        S=metefot(S,fotog,i,1);

        fotog=sacafot(s3,ne,ne,i);
        fotog=fotog.*cond;
        s3=metefot(s3,fotog,i,1);
    end

    eval(['S',num2str(vv),'=S;'])
    eval(['S3',num2str(vv),'=s3;'])

end

S2 = S;
Sn = S;
Sn2 = S;
for i=1:nt
    fotog1=sacafot(S1,ne,ne,i);
    fotog2=sacafot(S2,ne,ne,i);
    fotog = [fotog1(:,1:ne/2) fotog2(:,ne/2+1:end)];
    S=metefot(S,fotog,i,1);
    S2=metefot(S2,fotog',i,1);    

    fotog1=sacafot(S31,ne,ne,i);
    fotog2=sacafot(S32,ne,ne,i);
    fotogn = [fotog1(:,1:ne/2) fotog2(:,ne/2+1:end)];
    Sn=metefot(Sn,fotogn,i,1);
    Sn2=metefot(Sn2,fotogn',i,1);    

end

SS = [S repmat(fotog,1,80)];
SS2 = [S2 repmat(fotog',1,80)];

SSn = [Sn repmat(fotogn,1,80)];
SSn2 = [Sn2 repmat(fotogn',1,80)];

% Build the movie from SS
P = build_achrom_movie(SS,0,(2*Lm)/4,ne,1);
P2 = build_achrom_movie(SS2,0,(2*Lm)/4,ne,1);

Pn = build_achrom_movie(SSn,0,64,ne,1);
Pn2 = build_achrom_movie(SSn2,0,64,ne,1);

% Movies in avi format

if print_figures ==1
    movie2avi(P,[output_folder 'motion_vert.avi'],'FPS',fst,'COMPRESSION','None')
    movie2avi(P2,[output_folder 'motion_horiz.avi'],'FPS',fst,'COMPRESSION','None')
    movie2avi(Pn,[output_folder 'motion_natural_vert.avi'],'FPS',fst,'COMPRESSION','None')
    movie2avi(Pn2,[output_folder 'motion_natural_horiz.avi'],'FPS',fst,'COMPRESSION','None')
end

%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%   SHOW REPRESENTATIVE FRAMES WITH ARROWS INDICATING SPEED
%%%%%%%%%%%%%%%%

if print_figures == 1
    
    ss = then2now(SS,40);
    ss = ss/max(ss(:));
    
    Im_1 = mean(ss(:,:,1:3),3);
    Im_1 = repmat(Im_1,[1 1 3]);
    Im_2 = ss(:,:,end);
    Im_2 = repmat(Im_2,[1 1 3]);
    
    frame = Im_1;
    
    fm = 14;
    fM = 26;
    cm = 9;
    cM = 11;
    
    direc_arrow = ones(size(frame,1),size(frame,2),3);
    direc_arrow(fm:fM,cm:cM,[1 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[1 3]) = zeros;
    end
    
    fm = 8;
    fM = 32;
    cm = 30;
    cM = 32;
    
    direc_arrow(fm:fM,cm:cM,[1 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[1 3]) = zeros;
    end
    
    
    Im_1 = Im_1.*(direc_arrow);
    Im_1 = Im_1.*((Im_1>=0) & (Im_1<=1)) + double(Im_1>1);
    
    figure(1)
    imagesc(Im_1,[0 1])
    axis square
    axis off
    
    frame = Im_1;
    
    fm = 14;
    fM = 26;
    cm = 9;
    cM = 11;
    
    direc_arrow = ones(size(frame,1),size(frame,2),3);
    direc_arrow(fm:fM,cm:cM,[2 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[2 3]) = zeros;
    end
    
    fm = 19;
    fM = 21;
    cm = 30;
    cM = 32;
    
    direc_arrow(fm:fM,cm:cM,[2 3]) = zeros;
    
    Im_2 = Im_2.*(direc_arrow(end:-1:1,:,:));
    Im_2 = Im_2.*((Im_2>=0) & (Im_2<=1)) + double(Im_2>1);
    
    figure(2)
    imagesc(Im_2,[0 1])
    colormap gray
    axis square
    axis off
    
    print(1,'-deps2c',[output_folder 'fig_1_video_1'])
    print(2,'-deps2c',[output_folder 'fig_1_video_2'])
    
    %%%%%%%%%%%%%%
    %%%%%%%%%%%%%%
    
    ss = then2now(SS2,40);
    ss = ss/max(ss(:));
    
    Im_1 = mean(ss(:,:,1:3),3);
    Im_1 = repmat(Im_1,[1 1 3]);
    Im_2 = ss(:,:,end);
    Im_2 = repmat(Im_2,[1 1 3]);
    
    frame = Im_1;
    
    fm = 14;
    fM = 26;
    cm = 9;
    cM = 11;
    
    direc_arrow = ones(size(frame,1),size(frame,2),3);
    direc_arrow(fm:fM,cm:cM,[1 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[1 3]) = zeros;
    end
    
    fm = 8;
    fM = 32;
    cm = 30;
    cM = 32;
    
    direc_arrow(fm:fM,cm:cM,[1 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[1 3]) = zeros;
    end
    
    for ii=1:3
        direc_arrow(:,:,ii) = direc_arrow(:,:,ii)';
    end
    
    Im_1 = Im_1.*(direc_arrow);
    Im_1 = Im_1.*((Im_1>=0) & (Im_1<=1)) + double(Im_1>1);
    
    figure(3)
    imagesc(Im_1,[0 1])
    axis square
    axis off
    %print('-deps2c',[output_folder 'fig_1_video_1'])
    
    frame = Im_1;
    
    fm = 14;
    fM = 26;
    cm = 9;
    cM = 11;
    
    direc_arrow = ones(size(frame,1),size(frame,2),3);
    direc_arrow(fm:fM,cm:cM,[2 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[2 3]) = zeros;
    end
    
    fm = 19;
    fM = 21;
    cm = 30;
    cM = 32;
    
    direc_arrow(fm:fM,cm:cM,[2 3]) = zeros;
    
    for ii=1:3
        direc_arrow(:,:,ii) = direc_arrow(:,:,ii)';
    end
    
    Im_2 = Im_2.*(direc_arrow(:,end:-1:1,:));
    Im_2 = Im_2.*((Im_2>=0) & (Im_2<=1)) + double(Im_2>1);
    
    figure(4)
    imagesc(Im_2,[0 1])
    colormap gray
    axis square
    axis off
    
    print(3,'-deps2c',[output_folder 'fig_1_video_3'])
    print(4,'-deps2c',[output_folder 'fig_1_video_4'])
    
    %%%%%%%%%%%%%%
    %%%%%%%%%%%%%%
    
    ss = then2now(SSn2,40);
    ss = ss/max(ss(:));
    
    Im_1 = mean(ss(:,:,1:3),3);
    Im_1 = repmat(Im_1,[1 1 3]);
    Im_2 = ss(:,:,end);
    Im_2 = repmat(Im_2,[1 1 3]);
    
    frame = Im_1;
    
    fm = 14;
    fM = 26;
    cm = 9;
    cM = 11;
    
    direc_arrow = ones(size(frame,1),size(frame,2),3);
    direc_arrow(fm:fM,cm:cM,[1 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[1 3]) = zeros;
    end
    
    fm = 8;
    fM = 32;
    cm = 30;
    cM = 32;
    
    direc_arrow(fm:fM,cm:cM,[1 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[1 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[1 3]) = zeros;
    end
    
    for ii=1:3
        direc_arrow(:,:,ii) = direc_arrow(:,:,ii)';
    end
    
    Im_1 = Im_1.*(direc_arrow);
    Im_1 = Im_1.*((Im_1>=0) & (Im_1<=1)) + double(Im_1>1);
    
    figure(5)
    imagesc(Im_1,[0 1])
    axis square
    axis off
    %print('-deps2c',[output_folder 'fig_1_video_1'])
    
    frame = Im_1;
    
    fm = 14;
    fM = 26;
    cm = 9;
    cM = 11;
    
    direc_arrow = ones(size(frame,1),size(frame,2),3);
    direc_arrow(fm:fM,cm:cM,[2 3]) = zeros;
    
    for i=1:6
        direc_arrow(fM+2-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+2-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM+1-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+1-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM+0-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM+0-i,cm+i,[2 3]) = zeros;
        direc_arrow(fM-1-i,cM-i,[2 3]) = zeros;
        direc_arrow(fM-1-i,cm+i,[2 3]) = zeros;
    end
    
    fm = 19;
    fM = 21;
    cm = 30;
    cM = 32;
    
    direc_arrow(fm:fM,cm:cM,[2 3]) = zeros;
    
    for ii=1:3
        direc_arrow(:,:,ii) = direc_arrow(:,:,ii)';
    end
    
    Im_2 = Im_2.*(direc_arrow(:,end:-1:1,:));
    Im_2 = Im_2.*((Im_2>=0) & (Im_2<=1)) + double(Im_2>1);
    
    figure(6)
    imagesc(Im_2,[0 1])
    colormap gray
    axis square
    axis off
    
    print(5,'-deps2c',[output_folder 'fig_1_video_5'])
    print(6,'-deps2c',[output_folder 'fig_1_video_6'])
    
end