% ------------------------------------
% DEMO on COLOR AFTEREFFECTS
%
% V. Laparra & J. Malo 
% Universitat de Valencia 2014
% ------------------------------------
%
% In this script we generate examples of the hue repulsion (or complementary hue) 
% aftereffect.
% 
% Here we use natural stimuli from the IPL calibrated color image database
% (such as those explored using Sequential Pricipal Curves Analysis 
% -section 2.3, Fig. 9 of the paper-) and synthetic stimuli (munsell samples 
% under CIE D65 and CIE A filters).
% 
% This script requires having the COLORLAB toolbox installed.
% http://isp.uv.es/colorlab.html
%
% In the experiments we first adapt for 20 secs to some environment in which 
% the central part has biased color statistics (either due to filters or to 
% particular object reflectance). A fixation point helps to keep gaze in place. 
% Then the adaptor disappears and a chromatically stationary pattern comes in. 
% Do you see the same average color across the visual field?. 
%
% We generate the individual stimuli and a movie made of two frames 
% (adaptor and test) to simplify the illustration: by playing the movie the
% adaptation time is controlled and the test appears in the same position
% as the adaptor.
%
% NOTE: You have the option of printing representative images and generating 
% *.avi files with the illusions by choosing print_figures = 1. 
% (see the first line of the code)
% In this case you have to specify the path where you want the files stored.
% If you choose print_figures = 0 the program just shows the movies but
% prints nothing.

print_figures = 0;


% COLORLAB initialization: load ciexyz.mat (colorimetric quantities) and
% std_crt.mat (display calibration parameters)

[T_l,Yw,Msx]=loadsysm('ciexyz.mat');
[tm,a,g]=loadmonm('std_crt.mat',Msx);

% Fixation point
cond=ones(128,128);
cond(62:66,64)=zeros(5,1);
cond(64,62:66)=zeros(1,5);

% Simple case: orange-filter over achromatic reflectance 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% T1=coor2tri([0.37 0.41 0.86*100],Yw);
% T2=coor2tri([0.37 0.41 0.86*70],Yw);
% T3=coor2tri([0.37 0.41 0.86*40],Yw);

T1=coor2tri([0.45 0.41 0.86*100],Yw);
T2=coor2tri([0.45 0.41 0.86*70],Yw);
T3=coor2tri([0.45 0.41 0.86*40],Yw);

T1b=coor2tri([0.33 0.33 0.86*100],Yw);
T2b=coor2tri([0.33 0.33 0.86*70],Yw);
T3b=coor2tri([0.33 0.33 0.86*40],Yw);

im = cond;
im(27:128-26,27:128-26) = 2*ones(76,76);
im(42:128-42,42:128-42) = 3*ones(45,45);
im(58:128-58,58:128-58) = 4*ones(13,13);

im = im.*cond;
im = im + 1;

pal1 = [T1b;T1;T2;T3];
pal2 = [T1b;T1b;T2b;T3b];

[n1,saturat1,Tn1]=tri2val(pal1,Yw,tm,a,g,8);
[n2,saturat2,Tn2]=tri2val(pal2,Yw,tm,a,g,8);

im_simple = im;
n_a = n1;
n_d65 = n2;
figure(1),colormap([0 0 0;n_a]),image(im_simple),axis off,axis square
figure(2),colormap([0 0 0;n_d65]),image(im_simple),axis off,axis square

% More complex case: orange filter over multiple reflectances
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Cargamos 20 reflectancias Munsell de value (claridad) constante
% (p.ej. V=5) recorriendo los 10 tonos fundamentales y considerando 2 
% cromas (2 y 6).

V=5;       % V puede tomar los valores [0:9]
C=[2 4 6];   % C puede tomar los valores [0,1,2:2:16]
H=5;       % H puede tomar los valores [1.25:1.25:10]
h=1:10;    % h puede tomar los valores [1:10]
descript_reflec=[H*ones(20,1) V*ones(20,1) [C(1)*ones(10,1);C(3)*ones(10,1)] [h';h']];

[reflec, vHVCh]=loadrefm(descript_reflec);

figure,plot(reflec(:,1),reflec(:,2:11)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(1))]),axis([350 750 0 0.5])
figure,plot(reflec(:,1),reflec(:,12:21)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(2))]),axis([350 750 0 0.5])
%figure(3),plot(reflec(:,1),reflec(:,22:31)),xlabel('\lambda (nm)'),ylabel('Reflectancia'),title(['Croma Munsell ',num2str(C(3))]),axis([350 750 0 0.5])

% Difusor perfecto para el fondo

ref_fondo=0.7*ones(length(reflec(:,1)),1);

ref=[reflec ref_fondo];

% Definimos o cargamos 2 iluminantes diferentes con la misma luminancia 
% (p.ej. 300 cd/m2)

%esp1=defillu(300,1,10,T_l,Yw,3);title('Iluminante 1'),axis([380 800 0 11e-3])
%esp2=defillu(300,1,10,T_l,Yw,4);title('Iluminante 2')
%esp2=loadillu(300,1,10,T_l,Yw);

esp1=loadilum('iluminan.d65',300,1,10,T_l,Yw);
esp2=loadilum('iluminan.a',300,1,10,T_l,Yw);

figure,plot(esp1(:,1),esp1(:,2)),title('Iluminant 1 (CIE D65)'),axis([380 800 0 10e-3]),xlabel('\lambda (nm)'),ylabel('Radiance (W/m^2*str)')
figure,plot(esp2(:,1),esp2(:,2)),title('Iluminant 2 (CIE A)'),axis([380 800 0 10e-3]),xlabel('\lambda (nm)'),ylabel('Radiance (W/m^2*str)')

% Colores con los iluminantes 1 y 2

[T1,RR1]=spec2tri(T_l,10,ref,esp1);
[T2,RR2]=spec2tri(T_l,10,ref,esp2);
T1=0.6*[T1;0.8*T1(end,:);0.7*T1(end,:);0.5*T1(end,:);0.3*T1(end,:);0.2*T1(end,:);0.15*T1(end,:)];
T2=0.6*[T2;0.8*T2(end,:);0.7*T2(end,:);0.5*T2(end,:);0.3*T2(end,:);0.2*T2(end,:);0.15*T2(end,:)];

[n1,saturat,Tn]=tri2val(T1,Yw,tm,a,g,8);
[n2,saturat,Tn]=tri2val(T2,Yw,tm,a,g,8);

imm1 = cond;
imm2 = cond;

for i=1:16
    for j=1:16
        %if (i>4) & (i<13) & (j>4) & (j<13)
        if (i>3) & (i<14) & (j>3) & (j<14)    
           num = length(T1(:,1)) + 1 + floor(length(T1(:,1))*rand); 
           imm1((i-1)*8+1:i*8,(j-1)*8+1:j*8) = (num - length(T1(:,1)))*ones(8,8);
           imm2((i-1)*8+1:i*8,(j-1)*8+1:j*8) = num*ones(8,8);
        else    
           num = 1 + floor(length(T1(:,1))*rand); 
           imm1((i-1)*8+1:i*8,(j-1)*8+1:j*8) = num*ones(8,8);
           imm2((i-1)*8+1:i*8,(j-1)*8+1:j*8) = num*ones(8,8);
        end
    end
end
imm1 = 1 + imm1.*cond;
imm2 = 1 + imm2.*cond;

n_reflects = [0 0 0;n1;n2];
im_ref_a = imm1;
im_ref_d65 = imm2;

figure,colormap([n1;n2]),image([1:length(T1(:,1));length(T1(:,1))+1:2*length(T1(:,1))]),axis off,axis square
figure,colormap([0 0 0;n1;n2]),image(imm1),axis off,axis square
figure,colormap([0 0 0;n1;n2]),image(imm2),axis off,axis square

% Ahora con imagenes
%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%

im1 = imread('im1.JPG');
im2 = imread('im2.JPG');
im3 = imread('im3.JPG');
im4 = imread('im5.JPG');
im5 = imread('im6.JPG');
im6 = imread('im7.JPG');
im7 = imread('im8.JPG');
im8 = imread('im4.JPG');
im9 = imread('im10.JPG');


im10 = imread('im12.JPG');
im11 = imread('im13.JPG');
im12 = imread('im14.JPG');
im13 = imread('im15.JPG');
im14 = imread('im16.JPG');
im15 = imread('im17.JPG');
im16 = imread('im18.JPG');
im17 = imread('im19.JPG');
im18 = imread('im20.JPG');
im19 = imread('im21.JPG');

im20 = imread('im22.JPG');
im21 = imread('im23.JPG');
im22 = imread('im24.JPG');
im23 = imread('im25.JPG');
im24 = imread('im26.JPG');
im25 = imread('im27.JPG');

% AMARILLOS
%%%%%%%%%%%%%%%%%%%%

sh = 32;
sw = 5;

im = [im1 im2 im3;im4 im6 im5;im7 imrotate(im8,90) im9];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_roja = im;
figure,image(im_roja),axis off,axis square
im6bn = im6;
im6bn(:,:,1) = im6(:,:,1);
im6bn(:,:,2) = im6(:,:,1);
im6bn(:,:,3) = im6(:,:,1);
im = [im1 im2 im3;im4 im6bn im5;im7 imrotate(im8,90) im9]; 
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_roja_centro_blanco = im;
figure,image(im_roja_centro_blanco),axis off,axis square

% Ladrillos-tierra
im = [imrotate(im2,0) imrotate(im3,180) imrotate(im2,90);imrotate(im3,0) imrotate(im4,0) imrotate(im3,0);imrotate(im3,180) imrotate(im2,90) imrotate(im2,270)];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_ladrillos_tierra = im;
figure,image(im_ladrillos_tierra),axis off,axis square
im4bn = im4;
im4bn(:,:,1) = im4(:,:,1);
im4bn(:,:,2) = im4(:,:,1);
im4bn(:,:,3) = im4(:,:,1);
im = [imrotate(im2,0) imrotate(im3,180) imrotate(im2,90);imrotate(im3,0) imrotate(im4bn,0) imrotate(im3,0);imrotate(im3,180) imrotate(im2,90) imrotate(im2,270)];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_ladrillos_tierra_centro_blanco = im;
figure,image(im_ladrillos_tierra_centro_blanco),axis off,axis square

im2bn = im2;
im2bn(:,:,1) = im2(:,:,1);
im2bn(:,:,2) = im2(:,:,1);
im2bn(:,:,3) = im2(:,:,1);

im3bn = im3;
im3bn(:,:,1) = im3(:,:,1);
im3bn(:,:,2) = im3(:,:,1);
im3bn(:,:,3) = im3(:,:,1);

% Solo Ladrillos (amarillo central)

im = [imrotate(im2bn,0) imrotate(im3bn,180) imrotate(im2bn,90);imrotate(im3bn,0) imrotate(im2,90) imrotate(im3bn,0);imrotate(im3bn,180) imrotate(im2bn,90) imrotate(im2bn,270)];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_ladrillos_centro_rojo = im;
figure,image(im_ladrillos_centro_rojo),axis off,axis square
im=[imrotate(im2bn,0) imrotate(im3bn,180) imrotate(im2bn,90);imrotate(im3bn,0) imrotate(im2bn,90) imrotate(im3bn,0);imrotate(im3bn,180) imrotate(im2bn,90) imrotate(im2bn,270)];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_ladrillos_blancos = im;
figure,image(im_ladrillos_blancos),axis off,axis square

im=[imrotate(im2,0) imrotate(im3,180) imrotate(im2,90);imrotate(im3,0) imrotate(im2,90) imrotate(im3,0);imrotate(im3,180) imrotate(im2,90) imrotate(im2,270)];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_ladrillos = im;
figure,image(im_ladrillos),axis off,axis square
im = [imrotate(im2,0) imrotate(im3,180) imrotate(im2,90);imrotate(im3,0) imrotate(im2bn,90) imrotate(im3,0);imrotate(im3,180) imrotate(im2,90) imrotate(im2,270)];
im(256+128-sh:256+128+sh,256+128-sw:256+128+sw,:) = zeros(2*sh+1,2*sw+1,3); 
im(256+128-sw:256+128+sw,256+128-sh:256+128+sh,:) = zeros(2*sw+1,2*sh+1,3); 
im_ladrillos_centro_blanco = im;
figure,image(im_ladrillos_centro_blanco),axis off,axis square

% AZULES
%%%%%%%%%%

im16=im23;

figure,image([imrotate(im11,0) imrotate(im12,90) imrotate(im13,90);imrotate(im10,90) imrotate(im15,0) imrotate(im16,180);imrotate(im17,180) imrotate(im18,90) imrotate(im19,270)]),axis off,axis square
im15bn = im15;
im15bn(:,:,1) = im15(:,:,2);
im15bn(:,:,2) = im15(:,:,2);
im15bn(:,:,3) = im15(:,:,2);
figure,image([imrotate(im11,0) imrotate(im12,90) imrotate(im13,90);imrotate(im10,90) imrotate(im15bn,0) imrotate(im16,180);imrotate(im17,180) imrotate(im18,90) imrotate(im19,270)]),axis off,axis square

im10bn = im10;
im10bn(:,:,1) = im10(:,:,2);
im10bn(:,:,2) = im10(:,:,2);
im10bn(:,:,3) = im10(:,:,2);

im11bn = im10;
im11bn(:,:,1) = im11(:,:,2);
im11bn(:,:,2) = im11(:,:,2);
im11bn(:,:,3) = im11(:,:,2);

im12bn = im10;
im12bn(:,:,1) = im12(:,:,2);
im12bn(:,:,2) = im12(:,:,2);
im12bn(:,:,3) = im12(:,:,2);

im13bn = im10;
im13bn(:,:,1) = im13(:,:,2);
im13bn(:,:,2) = im13(:,:,2);
im13bn(:,:,3) = im13(:,:,2);

im14bn = im10;
im14bn(:,:,1) = im14(:,:,2);
im14bn(:,:,2) = im14(:,:,2);
im14bn(:,:,3) = im14(:,:,2);

im15bn = im10;
im15bn(:,:,1) = im15(:,:,2);
im15bn(:,:,2) = im15(:,:,2);
im15bn(:,:,3) = im15(:,:,2);

im16bn = im10;
im16bn(:,:,1) = im16(:,:,2);
im16bn(:,:,2) = im16(:,:,2);
im16bn(:,:,3) = im16(:,:,2);

im17bn = im10;
im17bn(:,:,1) = im17(:,:,2);
im17bn(:,:,2) = im17(:,:,2);
im17bn(:,:,3) = im17(:,:,2);

im18bn = im10;
im18bn(:,:,1) = im18(:,:,2);
im18bn(:,:,2) = im18(:,:,2);
im18bn(:,:,3) = im18(:,:,2);

im19bn = im10;
im19bn(:,:,1) = im19(:,:,2);
im19bn(:,:,2) = im19(:,:,2);
im19bn(:,:,3) = im19(:,:,2);

figure,image([imrotate(im11bn,0) imrotate(im12bn,90) imrotate(im13bn,90);imrotate(im10bn,90) imrotate(im15,0) imrotate(im16bn,180);imrotate(im17bn,180) imrotate(im18bn,90) imrotate(im19bn,270)]),axis off,axis square
figure,image([imrotate(im11bn,0) imrotate(im12bn,90) imrotate(im13bn,90);imrotate(im10bn,90) imrotate(im15bn,0) imrotate(im16bn,180);imrotate(im17bn,180) imrotate(im18bn,90) imrotate(im19bn,270)]),axis off,axis square

%%%%%%

im20bn = im10;
im20bn(:,:,1) = im20(:,:,2);
im20bn(:,:,2) = im20(:,:,2);
im20bn(:,:,3) = im20(:,:,2);

im21bn = im10;
im21bn(:,:,1) = im21(:,:,2);
im21bn(:,:,2) = im21(:,:,2);
im21bn(:,:,3) = im21(:,:,2);

im22bn = im10;
im22bn(:,:,1) = im22(:,:,2);
im22bn(:,:,2) = im22(:,:,2);
im22bn(:,:,3) = im22(:,:,2);

im23bn = im10;
im23bn(:,:,1) = im23(:,:,2);
im23bn(:,:,2) = im23(:,:,2);
im23bn(:,:,3) = im23(:,:,2);

im24bn = im10;
im24bn(:,:,1) = im24(:,:,2);
im24bn(:,:,2) = im24(:,:,2);
im24bn(:,:,3) = im24(:,:,2);

im25bn = im10;
im25bn(:,:,1) = im25(:,:,2);
im25bn(:,:,2) = im25(:,:,2);
im25bn(:,:,3) = im25(:,:,2);

figure,image([imrotate(im20bn,0) imrotate(im21bn,90) imrotate(im22bn,90);imrotate(im23bn,90) imrotate(im22,180) imrotate(im25bn,180);imrotate(im20bn,180) imrotate(im21bn,90) imrotate(im22bn,270)]),axis off,axis square
figure,image([imrotate(im20bn,0) imrotate(im21bn,90) imrotate(im22bn,90);imrotate(im23bn,90) imrotate(im22bn,180) imrotate(im25bn,180);imrotate(im20bn,180) imrotate(im21bn,90) imrotate(im22bn,270)]),axis off,axis square

figure,image([imrotate(im20,0) imrotate(im21,90) imrotate(im22,90);imrotate(im23,90) imrotate(im22,180) imrotate(im25,180);imrotate(im20,180) imrotate(im21,90) imrotate(im22,270)]),axis off,axis square
figure,image([imrotate(im20,0) imrotate(im21,90) imrotate(im22,90);imrotate(im23,90) imrotate(im22bn,180) imrotate(im25,180);imrotate(im20,180) imrotate(im21,90) imrotate(im22,270)]),axis off,axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PRINT FIGURES AND MOVIE VERSIONS OF THE ILLUSIONS IF REQUIRED. 
% MODIFY THE FOLDER SPECIFICATION WHERE THE FIGURES WILL BE STORED! 
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if print_figures == 1
    
    % FIGURES
    
    output_folder = 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\code\stimuli_after\color\'
    output_folder = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/stimuli_after/color/'
    
    print (1,'-depsc2', [output_folder 'cuadros_c.eps'])
    print (2,'-depsc2', [output_folder 'cuadros_d65.eps'])
    print (7,'-depsc2', [output_folder 'random_d65.eps'])
    print (8,'-depsc2', [output_folder 'random_c.eps'])
    print (9,'-depsc2', [output_folder 'natural_roig.eps'])
    print (10,'-depsc2', [output_folder 'natural_roig_blanc.eps'])
    print (13,'-depsc2', [output_folder 'ladrillo_central.eps'])
    print (16,'-depsc2', [output_folder 'ladrillo_periferia.eps'])
    
    print (1,'-djpeg', [output_folder 'cuadros_c.jpg'])
    print (2,'-djpeg', [output_folder 'cuadros_d65.jpg'])
    print (7,'-djpeg', [output_folder 'random_d65.jpg'])
    print (8,'-djpeg', [output_folder 'random_c.jpg'])
    print (9,'-djpeg', [output_folder 'natural_roig.jpg'])
    print (10,'-djpeg', [output_folder 'natural_roig_blanc.jpg'])
    print (13,'-djpeg', [output_folder 'ladrillo_central.jpg'])
    print (16,'-djpeg', [output_folder 'ladrillo_periferia.jpg'])
    
    
    %   MOVIES
    
    close all
    
    figure(1)
    set(gcf,'color',[1 1 1])
    
    % Cuadrito
    
    for i=1:16
        if i<11
            figure(1),colormap([0 0 0;n_a]),image(im_simple),axis off,axis square
        else
            figure(1),colormap([0 0 0;n_d65]),image(im_simple),axis off,axis square
        end
        M_albers(i)=getframe;
    end
    
    % Random reflectances
    
    for i=1:16
        if i<11
            figure(1),colormap(n_reflects),image(im_ref_d65),axis off,axis square
        else
            figure(1),colormap(n_reflects),image(im_ref_a),axis off,axis square
        end
        M_random(i)=getframe;
    end
    
    % Biased reflectance 1
    
    for i=1:16
        if i<11
            figure(1),image(im_roja),axis off,axis square
        else
            figure(1),image(im_roja_centro_blanco),axis off,axis square
        end
        M_biased_1(i)=getframe;
    end
    
    % Biased reflectance 2
    
    for i=1:16
        if i<11
            figure(1),image(im_ladrillos_centro_rojo),axis off,axis square
        else
            figure(1),image(im_ladrillos_centro_blanco),axis off,axis square
        end
        M_biased_2(i)=getframe;
    end
    
    % Biased reflectance 2
    
    for i=1:16
        if i<11
            figure(1),image(im_ladrillos_centro_rojo),axis off,axis square
        else
            figure(1),image(im_ladrillos_blancos),axis off,axis square
        end
        M_biased_3(i)=getframe;
    end
    
    figure(1),image(im_ladrillos_centro_rojo),axis off,axis square
    print(1,'-deps2c',[output_folder 'ladrillos_centro_rojo.eps'])
    figure(1),image(im_ladrillos_centro_blanco),axis off,axis square
    print(1,'-deps2c',[output_folder 'ladrillos_centro_blanco.eps'])
    figure(1),image(im_ladrillos_blancos),axis off,axis square
    print(1,'-deps2c',[output_folder 'ladrillos_blanco.eps'])
    
    movie2avi(M_albers,[output_folder 'albers.avi'],'FPS',1,'COMPRESSION','None')
    movie2avi(M_random,[output_folder 'random.avi'],'FPS',1,'COMPRESSION','None')
    movie2avi(M_biased_1,[output_folder 'biased_1.avi'],'FPS',1,'COMPRESSION','None')
    movie2avi(M_biased_2,[output_folder 'biased_2.avi'],'FPS',1,'COMPRESSION','None')
    movie2avi(M_biased_3,[output_folder 'biased_3.avi'],'FPS',1,'COMPRESSION','None')
    
    
end


% 
% movie2avi(M_albers,[output_folder 'albers.avi'],'FPS',1,'COMPRESSION','None')
% movie2avi(M_random,[output_folder 'random.avi'],'FPS',1,'COMPRESSION','None')
% movie2avi(M_biased_1,[output_folder 'biased_1.avi'],'FPS',1,'COMPRESSION','None')
% movie2avi(M_biased_2,[output_folder 'biased_2.avi'],'FPS',1,'COMPRESSION','None')


% % % Biased Contrast 
% % 
% % figure,colormap gray,imagesc(im_centro_high,[0 2*Lm]),axis square,axis off
% % figure,colormap gray,imagesc(im_low,[0 2*Lm]),axis square,axis off
% % figure,colormap gray,imagesc(im_low_trans,[0 2*Lm]),axis square,axis off
% % figure,colormap gray,imagesc(im_low_high_freq,[0 2*Lm]),axis square,axis off
% 
% for i=1:16
%     if i<11
%        figure(1),colormap gray,imagesc(im_centro_high,[0 2*Lm]),axis square,axis off
%     else
%        figure(1),colormap gray,imagesc(im_low,[0 2*Lm]),axis square,axis off
%     end
%     M_contrast_1(i)=getframe;
% end
% 
% for i=1:16
%     if i<11
%        figure(1),colormap gray,imagesc(im_centro_high,[0 2*Lm]),axis square,axis off
%     else
%        figure(1),colormap gray,imagesc(im_low_trans,[0 2*Lm]),axis square,axis off
%     end
%     M_contrast_2(i)=getframe;
% end
% 
% for i=1:16
%     if i<11
%        figure(1),colormap gray,imagesc(im_centro_high,[0 2*Lm]),axis square,axis off
%     else
%        figure(1),colormap gray,imagesc(im_low_high_freq,[0 2*Lm]),axis square,axis off
%     end
%     M_contrast_3(i)=getframe;
% end

% movie2avi(M_contrast_1,[output_folder contrast_1.avi','FPS',1,'COMPRESSION','None')
% movie2avi(M_contrast_2,[output_folder contrast_2.avi','FPS',1,'COMPRESSION','None')
% movie2avi(M_contrast_3,[output_folder contrast_3.avi','FPS',1,'COMPRESSION','None')

% %%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%% CONTRASTE
% %%%%%%%%%%%%%%%%%%
% 
% imm2 = double(squeeze(im2(:,:,1)));
% imm3 = double(squeeze(im3(:,:,1)));
% imm4 = double(squeeze(im19(:,:,1)));
% 
% imm_fondo = [rot90(imm2,1) rot90(imm2,4) rot90(imm3,1);rot90(imm2,3) rot90(imm3,2) rot90(imm2,4);rot90(imm3,3) rot90(imm2,5) rot90(imm3,4)];
% m = min(min(imm_fondo));
% M = max(max(imm_fondo));
% imm_fondo = (imm_fondo - m)/(M - m);
% imm_fondo = 2*(imm_fondo - 0.5);
% 
% imm_centro = 0*imm_fondo;
% imm_centro(257:512,257:512) = imm_fondo(257:512,257:512);
% 
% Lm = 200;
% Ccentro = 1.5;
% Cfondo = 0.5;
% 
% im = Lm*(1+Ccentro*imm_centro);
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_centro_high = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% im = Lm*(1+Cfondo*imm_fondo);
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_low = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% im = Lm*(1+Cfondo*imm_fondo');
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_low_trans = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% imm_fondo2 = [imm4 imm4 imm4;imm4 imm4 imm4;imm4 imm4 imm4];
% m = min(min(imm_fondo2));
% M = max(max(imm_fondo2));
% imm_fondo2 = (imm_fondo2 - m)/(M - m);
% imm_fondo2 = 2*(imm_fondo2 - 0.5);
% imm_fondo2 = imm_fondo2(2:2:end,2:2:end);
% imm_fondo2 = [imm_fondo2 imm_fondo2;imm_fondo2 imm_fondo2];
% imm_fondo2 = imm_fondo2(2:2:end,2:2:end);
% imm_fondo2 = [imm_fondo2 imm_fondo2;imm_fondo2 imm_fondo2];
% m = min(min(imm_fondo2));
% M = max(max(imm_fondo2));
% imm_fondo2 = (imm_fondo2 - m)/(M - m);
% imm_fondo2 = 2*(imm_fondo2 - 0.5);
% 
% im = Lm*(1+Cfondo*imm_fondo2);
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_low_high_freq = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% close(3),close(4),close(5),close(6),close(11),close(12)
% close(14),close(15),close(17),close(18),close(19)
% close(20),close(21),close(22),close(23),close(24)
% 
% % print -f1,-depsc2, 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\cuadros_c.eps'
% % print -f2 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\cuadros_d65.eps'
% % print -f7 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\random_d65.eps'
% % print -f8 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\random_c.eps'
% % print -f9 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\natural_roig.eps'
% % print -f10 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\natural_roig_blanc.eps'
% % print -f13 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_central.eps'
% % print -f16 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_periferia.eps'
% % print -f25 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_high_contrast_h.eps'
% % print -f26 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_low_contrast_h.eps'
% % print -f27 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_low_contrast_v.eps'
% % print -f28 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_low_contrast_high_freq.eps'
% % 
% % print -f1 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\cuadros_c.jpg'
% % print -f2 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\cuadros_d65.jpg'
% % print -f7 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\random_d65.jpg'
% % print -f8 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\random_c.jpg'
% % print -f9 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\natural_roig.jpg'
% % print -f10 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\natural_roig_blanc.jpg'
% % print -f13 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_central.jpg'
% % print -f16 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_periferia.jpg'
% % print -f25 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_high_contrast_h.jpg'
% % print -f26 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_low_contrast_h.jpg'
% % print -f27 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_low_contrast_v.jpg'
% % print -f28 -djpeg 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\ladrillo_low_contrast_high_freq.jpg'

% %%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%% CONTRASTE 2
% %%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%% 
% %%%%%%%%%%%%%%%%%%
% 
% imm2 = double(squeeze(im2(:,:,1)));
% imm3 = double(squeeze(im3(:,:,1)));
% imm4 = double(squeeze(im19(:,:,1)));
% 
% imm_fondo = [rot90(imm2,1) rot90(imm2,4) rot90(imm3,1);rot90(imm2,3) rot90(imm3,2) rot90(imm2,4);rot90(imm3,3) rot90(imm2,5) rot90(imm3,4)];
% m = min(min(imm_fondo));
% M = max(max(imm_fondo));
% imm_fondo = (imm_fondo - m)/(M - m);
% imm_fondo = 2*(imm_fondo - 0.5);
% 
% imm_centro = 0*imm_fondo;
% imm_centro(257:512,257:512) = imm_fondo(257:512,257:512);
% 
% Lm = 200;
% Ccentro = 1.5;
% Cfondo = 0.5;
% 
% im = Lm*(1+Ccentro*imm_centro);
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_centro_high = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% im = Lm*(1+Ccentro*imm_centro');
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_centro_high_trans = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% im = Lm*(1+Cfondo*imm_fondo);
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_low = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% 
% imm_fondo2 = [imm4 imm4 imm4;imm4 imm4 imm4;imm4 imm4 imm4];
% m = min(min(imm_fondo2));
% M = max(max(imm_fondo2));
% imm_fondo2 = (imm_fondo2 - m)/(M - m);
% imm_fondo2 = 2*(imm_fondo2 - 0.5);
% imm_fondo2 = imm_fondo2(2:2:end,2:2:end);
% imm_fondo2 = [imm_fondo2 imm_fondo2;imm_fondo2 imm_fondo2];
% imm_fondo2 = imm_fondo2(2:2:end,2:2:end);
% imm_fondo2 = [imm_fondo2 imm_fondo2;imm_fondo2 imm_fondo2];
% m = min(min(imm_fondo2));
% M = max(max(imm_fondo2));
% imm_fondo2 = (imm_fondo2 - m)/(M - m);
% imm_fondo2 = 2*(imm_fondo2 - 0.5);
% 
% imm_centro = 0*imm_fondo;
% imm_centro(257:512,257:512) = imm_fondo2(257:512,257:512);
% 
% im = Lm*(1+Ccentro*imm_centro');
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_high_high = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% 
% imm_fondo2 = [imm4 imm4 imm4;imm4 imm4 imm4;imm4 imm4 imm4];
% m = min(min(imm_fondo2));
% M = max(max(imm_fondo2));
% imm_fondo2 = (imm_fondo2 - m)/(M - m);
% imm_fondo2 = 2*(imm_fondo2 - 0.5);
% %imm_fondo2 = imm_fondo2(2:2:end,2:2:end);
% %imm_fondo2 = [imm_fondo2 imm_fondo2;imm_fondo2 imm_fondo2];
% %imm_fondo2 = imm_fondo2(2:2:end,2:2:end);
% %imm_fondo2 = [imm_fondo2 imm_fondo2;imm_fondo2 imm_fondo2];
% m = min(min(imm_fondo2));
% M = max(max(imm_fondo2));
% imm_fondo2 = (imm_fondo2 - m)/(M - m);
% imm_fondo2 = 2*(imm_fondo2 - 0.5);
% 
% imm_centro = 0*imm_fondo;
% imm_centro(257:512,257:512) = imm_fondo2(257:512,257:512);
% 
% im = Lm*(1+Ccentro*imm_centro');
% im(256+128-sh:256+128+sh,256+128-sw:256+128+sw) = zeros(2*sh+1,2*sw+1); 
% im(256+128-sw:256+128+sw,256+128-sh:256+128+sh) = zeros(2*sw+1,2*sh+1); 
% im_high_high = im;
% figure,colormap gray,imagesc(im,[0 2*Lm]),axis square,axis off
% 
% print -f1 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\lad_cent_high.eps'
% print -f2 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\lad_cent_high_trans.eps'
% print -f3 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\lad_cent_low.eps'
% print -f4 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\lad_cent_high_freq.eps'
% print -f5 -depsc2 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\abstract\images\lad_cent_high_freq2.eps'
