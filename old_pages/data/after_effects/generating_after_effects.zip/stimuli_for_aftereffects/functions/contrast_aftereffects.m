% ------------------------------------
% DEMO on CONTRAST AFTEREFFECTS
%
% V. Laparra & J. Malo 
% Universitat de Valencia 2014
% ------------------------------------
%
% In this script we explore the frequency dependence of contrast-induced blindness.
%
% In the experiments we first adapt to a localized high contrast pattern for 20 secs, 
% looking at the fixation point. Then the adaptor disappears and a stationary pattern
% comes in. Do you see the same contrast across the visual field?. 
% It depends on the interaction between adaptor and test...
%
% We make two sets of experiments:
% (1) using Gabor adaptors and sinusoidal test patterns. 
% (2) using Principal Components of natural images -McGill database- (see show_texture_data_masking.m)
%     
% The second set of stimuli is related to the statistics of natural images 
% and we generate exactly the same patterns as those explored using 
% Sequential Principal Curves Analysis (section 2.2, Figs. 6-8 of the paper). 
% See also show_texture_data_masking.m and XXXX.
%
% In both cases we choose low frequency tests and three different adaptors:
% (i)  similar frequency and orientation
% (ii) different (higher) freqeuncy and the same orientation
% (iii) different (higher) and different orientation
%
% In every case we generate the individual stimuli and a movie made of two frames 
% (adaptor and test) to simplify the illustration: by playing the movie the
% adaptation time is controlled and the test appears in the same position
% as the adaptor.
%
% NOTE: You have the option of printing representative images and generating 
% *.avi files with the illusions by choosing print_figures = 1. 
% (see the first line of the code)
% In this case you have to specify the path where you want the files stored.
% If you choose print_figures = 0 the program just shows the movies but
% prints nothing.
% 
% NOTE: definition of the spatial and frequency domain requires some
% functions from BasicVideoTools package (http://isp.uv.es/Basic_Video.html)

print_figures = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% GABOR ADAPTOR AND SINUSOIDAL TEST
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

C=0.7;   % Contrast of the adaptor
Cs=0.2;  % Contrast of the test
Lm=128;  % Average Luminance (in digital counts)

fx1=0;   % frequency of the test 
fx2=3;

fx1a = [0 0 11*sin(pi/4)]; % Frequencies of the adaptors
fx2a = [3 11 11*sin(pi/4)];

delta_x1=0.4;  % Spatial width of the adaptor (in deg)
delta_x2=0.4;

% spatial domain
[x,y,t,fx,fy,ft] = spatio_temp_freq_domain(128,128,10,64,10);
xx=x(1:128,1:128);
yy=y(1:128,1:128);

% Fixation stimulus (cross)
cond=ones(128,128);
cond(62:67,64:65)=zeros(6,2);
cond(64:65,62:67)=zeros(2,6);

% Gabor adaptors 
[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(1),fx2a(1),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
norma1=norm(C*2*gc2(:)/(M-m));
gc_1=Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);

[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(2),fx2a(2),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
norma2=norm(C*2*gc2(:)/(M-m));
gc_2=Lm*(1+(norma1/norma2)*C*2*gc2/(M-m)).*cond+0.*(cond==0);

[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(3),fx2a(3),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
norma3=norm(C*2*gc2(:)/(M-m));
gc_31=Lm*(1+(norma1/norma2)*C*2*gc2/(M-m)).*cond+0.*(cond==0);
[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(3),-fx2a(3),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
gc_32=Lm*(1+(norma1/norma2)*C*2*gc2/(M-m)).*cond+0.*(cond==0);
gc_3 = 0.5*gc_31 + 0.5*gc_32;

% Sinusoidal test
s=Lm*(1+Cs*cos(2*pi*(fx1*(xx-max(max(xx))/2)+fx2*(yy-max(max(xx))/2)))).*cond+0.*(cond==0);

% Experimento psicofisico ;-)
figure(3),colormap(gray),imagesc(gc_1,[0 2*Lm]),axis('off'),axis('square')
set(3,'Color',[1 1 1])

figure(4),colormap(gray),imagesc(gc_2,[0 2*Lm]),axis('off'),axis('square')
set(4,'Color',[1 1 1])

figure(5),colormap(gray),imagesc(gc_3,[0 2*Lm]),axis('off'),axis('square')
set(5,'Color',[1 1 1])

figure(6),colormap(gray),imagesc(s,[0 2*Lm]),axis('off'),axis('square')
set(6,'Color',[1 1 1])

%%%%%%%%%%

fx1=3*sin(pi/4);   % frequency of the test 
fx2=3*sin(pi/4);

fx1a = [3*sin(pi/4) 11*sin(pi/4) 11]; % Frequencies of the adaptors
fx2a = [3*sin(pi/4) 11*sin(pi/4) 0];

delta_x1=0.4;  % Spatial width of the adaptor (in deg)
delta_x2=0.4;

% spatial domain
[x,y,t,fx,fy,ft] = spatio_temp_freq_domain(128,128,10,64,10);
xx=x(1:128,1:128);
yy=y(1:128,1:128);

% Fixation stimulus (cross)
cond=ones(128,128);
cond(62:67,64:65)=zeros(6,2);
cond(64:65,62:67)=zeros(2,6);

% Gabor adaptors 
[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(1),fx2a(1),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
gc_11=Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);
[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(1),-fx2a(1),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
gc_12=Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);
gc_1_2 = 0.5*(gc_11+gc_12);

[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(2),fx2a(2),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
gc_21=Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);
[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(2),-fx2a(2),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
gc_22=Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);
gc_2_2 = 0.5*(gc_21+gc_22);

[gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(3),fx2a(3),delta_x1,delta_x2);
m=mini(gc2);
M=maxi(gc2);
gc_3_2 = Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);
% [gs2,gc2]=sens_gabor2d_spac(xx,yy,max(max(xx))/2,max(max(xx))/2,fx1a(3),-fx2a(3),delta_x1,delta_x2);
% m=mini(gc2);
% M=maxi(gc2);
% gc_32=Lm*(1+C*2*gc2/(M-m)).*cond+0.*(cond==0);
% gc_3 = 0.5*gc_31 + 0.5*gc_32;

% Sinusoidal test
s1 = Lm*(1+Cs*cos(2*pi*(fx1*(xx-max(max(xx))/2)+fx2*(yy-max(max(xx))/2)))).*cond+0.*(cond==0);
s2 = Lm*(1+Cs*cos(2*pi*(fx1*(xx-max(max(xx))/2)-fx2*(yy-max(max(xx))/2)))).*cond+0.*(cond==0);

s_2 = 0.5*(s1+s2);

% Experimento psicofisico ;-)
figure(7),colormap(gray),imagesc(gc_1_2,[0 2*Lm]),axis('off'),axis('square')
set(7,'Color',[1 1 1])

figure(8),colormap(gray),imagesc(gc_2_2,[0 2*Lm]),axis('off'),axis('square')
set(8,'Color',[1 1 1])

figure(9),colormap(gray),imagesc(gc_3_2,[0 2*Lm]),axis('off'),axis('square')
set(9,'Color',[1 1 1])

figure(10),colormap(gray),imagesc(s_2,[0 2*Lm]),axis('off'),axis('square')
set(10,'Color',[1 1 1])

figure(150),colormap gray,imagesc([gc_1(:,1:64) gc_2(:,65:end)],[0 2*Lm]),axis square,axis off,hold on,%plot(63.5,63.5,'r+','markersize',10,'linewidth',3)
set(150,'Color',[1 1 1])
figure(151),colormap gray,imagesc([gc_1(:,1:64) gc_3(:,65:end)],[0 2*Lm]),axis square,axis off,hold on,%plot(63.5,63.5,'r+','markersize',10,'linewidth',3)
set(151,'Color',[1 1 1])

adapt_1 = [gc_1(:,1:64) gc_2(:,65:end)];
adapt_2 = [gc_1(:,1:64) gc_3(:,65:end)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% ADAPTOR AND TEST FROM PCA SENSORS (used in the paper)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

try
    % SELECTED BASIS FUNCTIONS
    load('pca_images15x15_1','B')
    data_pca=1;
catch
    data_pca=0;
    disp(' ')
    disp(' Patterns based on PCA functions (not shown) require loading texture_data_after_SPCA.zip !')
    disp(' ')
end

if data_pca ==1
    B=fliplr(B);
    
    % figure,colormap gray,imagesc(reshape(B(:,10),15,15)),axis off,axis square
    % figure,colormap gray,imagesc(reshape(B(:,15),15,15)),axis off,axis square
    % figure,colormap gray,imagesc(reshape(B(:,85),15,15)),axis off,axis square
    % figure,colormap gray,imagesc(reshape(B(:,88),15,15)),axis off,axis square
    %
    % figure,colormap gray,imagesc(reshape(B(:,16),15,15)),axis off,axis square
    % figure,colormap gray,imagesc(reshape(B(:,22),15,15)),axis off,axis square
    % figure,colormap gray,imagesc(reshape(B(:,88),15,15)),axis off,axis square
    % figure,colormap gray,imagesc(reshape(B(:,87),15,15)),axis off,axis square
    
    % close all
    
    % BUILD IMAGES WITH BASIS FUNCTIONS
    
    low_h = reshape(B(:,10),15,15);
    low_h_2 = reshape(B(:,15),15,15);
    high_h = reshape(B(:,85),15,15);
    high_d = reshape(B(:,88),15,15);
    
    low_d = reshape(B(:,16),15,15);
    low_d_2 = reshape(B(:,22),15,15);
    
    high_v = reshape(B(:,87),15,15);
    
    % figure,colormap gray,imagesc([low_h low_h low_h;low_h low_h low_h;low_h low_h low_h]),axis off,axis square
    % figure,colormap gray,imagesc([low_h_2 low_h_2 low_h_2;low_h_2 low_h_2 low_h_2;low_h_2 low_h_2 low_h_2]),axis off,axis square
    % figure,colormap gray,imagesc([high_h high_h high_h;high_h high_h high_h;high_h high_h high_h]),axis off,axis square
    % figure,colormap gray,imagesc([high_d high_d high_d;high_d high_d high_d;high_d high_d high_d]),axis off,axis square
    %
    % figure,colormap gray,imagesc([low_d low_d low_d;low_d low_d low_d;low_d low_d low_d]),axis off,axis square
    % figure,colormap gray,imagesc([low_d_2 low_d_2 low_d_2;low_d_2 low_d_2 low_d_2;low_d_2 low_d_2 low_d_2]),axis off,axis square
    % figure,colormap gray,imagesc([high_d high_d high_d;high_d high_d high_d;high_d high_d high_d]),axis off,axis square
    % figure,colormap gray,imagesc([high_v high_v high_v;high_v high_v high_v;high_v high_v high_v]),axis off,axis square
    %
    % close all
    
    A = [low_h;low_h(6:end,:);low_h(6:end,:)];
    B = [A A];
    
    Low_h = B(1:30,1:30);
    Low_h_2 = [low_h_2 low_h_2;low_h_2 low_h_2];
    
    High_h = [high_h high_h;high_h high_h];
    High_d = [high_d high_d;high_d high_d];
    
    Low_d = [low_d low_d;low_d low_d];
    %A = [low_d;low_d(6:end,:);low_d(6:end,:)];
    %B = [A A];
    %Low_d = B(1:30,1:30);
    Low_d_2 = [low_d_2 low_d_2;low_d_2 low_d_2];
    
    High_v = [high_v high_v;high_v high_v];
    
    %%%%%%%%
    
    Low_h = Low_h/norm(Low_h(:));
    Low_h_2 = Low_h_2/norm(Low_h_2(:));
    
    High_h = High_h/norm(High_h(:));
    High_d = High_d/norm(High_d(:));
    
    Low_d = Low_d/norm(Low_d(:));
    Low_d_2 = Low_d_2/norm(Low_d_2(:));
    
    High_v = High_v/norm(High_v(:));
    
    %%%%%%%%
    
    % figure,colormap gray,imagesc([Low_h Low_h;Low_h Low_h],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([Low_h_2 Low_h_2;Low_h_2 Low_h_2],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_h High_h;High_h High_h],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_d High_d;High_d High_d],[-0.065 0.065]),axis off,axis square
    %
    % figure,colormap gray,imagesc([Low_d Low_d ;Low_d Low_d ],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([Low_d_2 Low_d_2; Low_d_2 Low_d_2],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_d High_d;High_d High_d],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_v High_v ;High_v High_v ],[-0.065 0.065]),axis off,axis square
    
    %%%%%%%%
    
    % figure,colormap gray,imagesc([Low_h Low_h Low_h ;Low_h Low_h Low_h;Low_h Low_h Low_h ],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([Low_h_2 Low_h_2 Low_h_2;Low_h_2 Low_h_2 Low_h_2;Low_h_2 Low_h_2 Low_h_2],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_h High_h High_h;High_h High_h High_h;High_h High_h High_h],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_d High_d High_d;High_d High_d High_d;High_d High_d High_d],[-0.065 0.065]),axis off,axis square
    %
    % figure,colormap gray,imagesc([Low_d Low_d Low_d ;Low_d Low_d Low_d ;Low_d Low_d Low_d ],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([Low_d_2 Low_d_2 Low_d_2;Low_d_2 Low_d_2 Low_d_2;Low_d_2 Low_d_2 Low_d_2],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_d High_d High_d;High_d High_d High_d;High_d High_d High_d],[-0.065 0.065]),axis off,axis square
    % figure,colormap gray,imagesc([High_v High_v High_v;High_v High_v High_v;High_v High_v High_v],[-0.065 0.065]),axis off,axis square
    
    % %%%%%%%%
    % %%%%%%%% LOW FREQUENCY ADAPTORS
    %
    % C = 0.25;
    % adapt_low_h = [zeros(30,90);zeros(30,30) Low_h zeros(30,30);zeros(30,90)];
    % test_low_h_2 = C*[Low_h_2 Low_h_2 Low_h_2;Low_h_2 Low_h_2 Low_h_2;Low_h_2 Low_h_2 Low_h_2];
    % test_high_h = C*[High_h High_h High_h;High_h High_h High_h;High_h High_h High_h];
    % test_high_d = C*[High_d High_d High_d;High_d High_d High_d;High_d High_d High_d];
    %
    % adapt_low_d = [zeros(30,90);zeros(30,30) Low_d zeros(30,30);zeros(30,90)];
    % test_low_d_2 = C*[Low_d_2 Low_d_2 Low_d_2;Low_d_2 Low_d_2 Low_d_2;Low_d_2 Low_d_2 Low_d_2];
    % test_high_v = C*[High_v High_v High_v;High_v High_v High_v;High_v High_v High_v];
    %
    % close all
    %
    % figure(1),colormap gray,imagesc(adapt_low_h,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    % figure(2),colormap gray,imagesc(test_low_h_2,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    % figure(3),colormap gray,imagesc(test_high_h,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    % figure(4),colormap gray,imagesc(test_high_d,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    %
    % figure(5),colormap gray,imagesc(adapt_low_d,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    % figure(6),colormap gray,imagesc(test_low_d_2,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    % figure(7),colormap gray,imagesc(test_high_d,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    % figure(8),colormap gray,imagesc(test_high_v,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    
    %%%%%%%%
    %%%%%%%% LOW FREQUENCY TESTS
    
    Cadapt = 0.7;
    C = 0.2;
    adapt_low_h_2 = Cadapt*[zeros(30,90);zeros(30,30) Low_h_2 zeros(30,30);zeros(30,90)];
    adapt_high_h = Cadapt*[zeros(30,90);zeros(30,30) High_h zeros(30,30);zeros(30,90)];
    adapt_high_d = Cadapt*[zeros(30,90);zeros(30,30) High_d zeros(30,30);zeros(30,90)];
    test_low_h = C*[Low_h Low_h Low_h;Low_h Low_h Low_h;Low_h Low_h Low_h];
    test_low_h_double = [test_low_h test_low_h;test_low_h test_low_h];
    test_low_h = test_low_h_double(6:95,1:90);
    
    adapt_low_d_2 = Cadapt*[zeros(30,90);zeros(30,30) Low_d_2 zeros(30,30);zeros(30,90)];
    adapt_high_v = Cadapt*[zeros(30,90);zeros(30,30) High_v zeros(30,30);zeros(30,90)];
    test_low_d = C*[Low_d Low_d Low_d;Low_d Low_d Low_d;Low_d Low_d Low_d];
    
    % close all
    
    figure(11),colormap gray,imagesc(adapt_low_h_2,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(11,'Color',[1 1 1])
    figure(12),colormap gray,imagesc(adapt_high_h,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(12,'Color',[1 1 1])
    figure(13),colormap gray,imagesc(adapt_high_d,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(13,'Color',[1 1 1])
    figure(14),colormap gray,imagesc(test_low_h,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(14,'Color',[1 1 1])
    
    figure(110),colormap gray,imagesc([adapt_low_h_2(:,1:45) adapt_high_h(:,46:end)],[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(110,'Color',[1 1 1])
    figure(111),colormap gray,imagesc([adapt_low_h_2(:,1:45) adapt_high_d(:,46:end)],[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(111,'Color',[1 1 1])
    
    figure(15),colormap gray,imagesc(adapt_low_d_2,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(15,'Color',[1 1 1])
    figure(16),colormap gray,imagesc(adapt_high_d,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(16,'Color',[1 1 1])
    figure(17),colormap gray,imagesc(adapt_high_v,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(17,'Color',[1 1 1])
    figure(18),colormap gray,imagesc(test_low_d,[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(18,'Color',[1 1 1])
    
    figure(210),colormap gray,imagesc([adapt_low_d_2(:,1:45) adapt_high_d(:,46:end)],[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(210,'Color',[1 1 1])
    figure(211),colormap gray,imagesc([adapt_low_d_2(:,1:45) adapt_high_v(:,46:end)],[-0.065 0.065]),axis square,axis off,hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
    set(211,'Color',[1 1 1])
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PRINT FIGURES AND MOVIE VERSIONS OF THE ILLUSIONS IF REQUIRED.
% MODIFY THE FOLDER SPECIFICATION WHERE THE FIGURES WILL BE STORED!
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if print_figures ==1
    
    output_folder = 'C:\disco_portable\mundo_irreal\latex\aranya\after_effects\code\stimuli_after\contrast\';
    
    print(3,'-depsc2',[output_folder,'mask_gabor_low_freq_horiz.eps'])
    print(4,'-depsc2',[output_folder,'mask_gabor_high_freq_horiz.eps'])
    print(5,'-depsc2',[output_folder,'mask_gabor_high_freq_diag.eps'])
    print(6,'-depsc2',[output_folder,'test_sin_low_freq_horiz.eps'])
    
    print(7,'-depsc2',[output_folder,'mask_gabor_low_freq_diag.eps'])
    print(8,'-depsc2',[output_folder,'mask_gabor_high_freq_diag.eps'])
    print(9,'-depsc2',[output_folder,'mask_gabor_high_freq_vert.eps'])
    print(10,'-depsc2',[output_folder,'test_sin_low_freq_diag.eps'])
    
    print(150,'-depsc2',[output_folder,'mask_gabors_low_high.eps'])
    print(151,'-depsc2',[output_folder,'mask_gabors_low_diag.eps'])    
    
    if data_pca ==1
        print(11,'-depsc2',[output_folder,'mask_pca_low_freq_horiz.eps'])
        print(12,'-depsc2',[output_folder,'mask_pca_high_freq_horiz.eps'])
        print(13,'-depsc2',[output_folder,'mask_pca_high_freq_diag.eps'])
        print(14,'-depsc2',[output_folder,'test_pca_low_freq_horiz.eps'])
        
        print(15,'-depsc2',[output_folder,'mask_pca_low_freq_diag.eps'])
        print(16,'-depsc2',[output_folder,'mask_pca_high_freq_diag.eps'])
        print(17,'-depsc2',[output_folder,'mask_pca_high_freq_vert.eps'])
        print(18,'-depsc2',[output_folder,'test_pca_low_freq_diag.eps'])
    end
    
    %%
    %%
    %%  MOVIE VERSIONS
    %%
    %%
    
    %%%%% GABORS
    %%%%% Low Freq. Horiz. Sensor
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(gc_1,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s,[0 2*Lm]),axis('off'),axis('square')
        end
        M1(i)=getframe;
    end
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(gc_2,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s,[0 2*Lm]),axis('off'),axis('square')
        end
        M2(i)=getframe;
    end
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(gc_3,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s,[0 2*Lm]),axis('off'),axis('square')
        end
        M3(i)=getframe;
    end
    
    %%%%% GABORS
    %%%%% Low Freq. Diag. Sensor
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(gc_1_2,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s_2,[0 2*Lm]),axis('off'),axis('square')
        end
        M4(i)=getframe;
    end
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(gc_2_2,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s_2,[0 2*Lm]),axis('off'),axis('square')
        end
        M5(i)=getframe;
    end
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(gc_3_2,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s_2,[0 2*Lm]),axis('off'),axis('square')
        end
        M6(i)=getframe;
    end
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(adapt_1,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s,[0 2*Lm]),axis('off'),axis('square')
        end
        M_a_1(i)=getframe;
    end    
    
    for i=1:30
        if i<20
            figure(100),colormap(gray),imagesc(adapt_2,[0 2*Lm]),axis('off'),axis('square')
        else
            figure(100),colormap(gray),imagesc(s,[0 2*Lm]),axis('off'),axis('square')
        end
        M_a_2(i)=getframe;
    end    
    
    %%%%% PCA
    %%%%% Low Freq. Horiz. Sensor
    if data_pca ==1
        
        for i=1:30
            if i<20
                figure(100),colormap(gray),imagesc(adapt_low_h_2,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            else
                figure(100),colormap(gray),imagesc(test_low_h,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            end
            M1p(i)=getframe;
        end
        
        for i=1:30
            if i<20
                figure(100),colormap(gray),imagesc(adapt_high_h,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            else
                figure(100),colormap(gray),imagesc(test_low_h,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            end
            M2p(i)=getframe;
        end
        
        for i=1:30
            if i<20
                figure(100),colormap(gray),imagesc(adapt_high_d,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            else
                figure(100),colormap(gray),imagesc(test_low_h,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            end
            M3p(i)=getframe;
        end
        
        %%%%% PCA
        %%%%% Low Freq. Diag. Sensor
        
        
        for i=1:30
            if i<20
                figure(100),colormap(gray),imagesc(adapt_low_d_2,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            else
                figure(100),colormap(gray),imagesc(test_low_d,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            end
            M4p(i)=getframe;
        end
        
        for i=1:30
            if i<20
                figure(100),colormap(gray),imagesc(adapt_high_d,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            else
                figure(100),colormap(gray),imagesc(test_low_d,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            end
            M5p(i)=getframe;
        end
        
        for i=1:30
            if i<20
                figure(100),colormap(gray),imagesc(adapt_high_v,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            else
                figure(100),colormap(gray),imagesc(test_low_d,[-0.065 0.065]),axis('off'),axis('square'),hold on,plot(45.5,45.5,'r+','markersize',10,'linewidth',3)
            end
            M6p(i)=getframe;
        end
        
        movie2avi(M1p,[output_folder,'contrast_pca_MASK_low_freq_horiz_TEST_low_freq_horiz'],'FPS',1.0,'COMPRESSION','None')
        movie2avi(M2p,[output_folder,'contrast_pca_MASK_high_freq_horiz_TEST_low_freq_horiz'],'FPS',1.0,'COMPRESSION','None')
        movie2avi(M3p,[output_folder,'contrast_pca_MASK_high_freq_diag_TEST_low_freq_horiz'],'FPS',1.0,'COMPRESSION','None')
        
        movie2avi(M4p,[output_folder,'contrast_pca_MASK_low_freq_diag_TEST_low_freq_diag'],'FPS',1.0,'COMPRESSION','None')
        movie2avi(M5p,[output_folder,'contrast_pca_MASK_high_freq_diag_TEST_low_freq_diag'],'FPS',1.0,'COMPRESSION','None')
        movie2avi(M6p,[output_folder,'contrast_pca_MASK_high_freq_vert_TEST_low_freq_diag'],'FPS',1.0,'COMPRESSION','None')
        
        
    end
    
    movie2avi(M1,[output_folder,'contrast_MASK_low_freq_horiz_TEST_low_freq_horiz'],'FPS',1.0,'COMPRESSION','None')
    movie2avi(M2,[output_folder,'contrast_MASK_high_freq_horiz_TEST_low_freq_horiz'],'FPS',1.0,'COMPRESSION','None')
    movie2avi(M3,[output_folder,'contrast_MASK_high_freq_diag_TEST_low_freq_horiz'],'FPS',1.0,'COMPRESSION','None')
    
    movie2avi(M4,[output_folder,'contrast_MASK_low_freq_diag_TEST_low_freq_diag'],'FPS',1.0,'COMPRESSION','None')
    movie2avi(M5,[output_folder,'contrast_MASK_high_freq_diag_TEST_low_freq_diag'],'FPS',1.0,'COMPRESSION','None')
    movie2avi(M6,[output_folder,'contrast_MASK_high_freq_vert_TEST_low_freq_diag'],'FPS',1.0,'COMPRESSION','None')

    movie2avi(M_a_1,[output_folder,'contrast_MASK_low_high_1_TEST_low'],'FPS',1.0,'COMPRESSION','None')
    movie2avi(M_a_2,[output_folder,'contrast_MASK_low_high_2_TEST_low'],'FPS',1.0,'COMPRESSION','None')
    
    
end