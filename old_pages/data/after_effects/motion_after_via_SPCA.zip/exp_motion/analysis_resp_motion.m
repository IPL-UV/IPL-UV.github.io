% --------------------------------------------
% SPCA DERIVATION OF MASKING DUE TO MOTION (plot results)
%
% SPCA RESPONSES OF SENSORS TUNED TO STATIC OBJECTS OF CERTAIN SPATIAL FREQUENCY
% AS A FUNCTION OF THE AMPLITUDE OF THE RESPONSE OF NEIGHBOR SENSORS
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% In this script we plot the results computed using resp_motion.m
% As stated in the help of resp_motion.m, it is not strictly necessary to
% run resp_motion since the results are provided in the subfolder "/exp_motion/motion_results/"
% contained in "motion_after_via_SPCA.zip"
% 
% In order to run this script results have to be in the above subfolder
% either because they were downloaded with the code or because they were
% recomputed using resp_motion.m.
%
% NOTE: You have the option of printing representative images 
% (fig 5 of the paper) by choosing print_figures = 1. (see the first 
% line of the code). In this case you have to specify the path where you want 
% the files stored. 
% If you choose print_figures = 0 the program just shows the plots but
% prints nothing.
%

print_figures = 0;
out_fold = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/after_reproducible/exp_motion/motion_results/';

% Load responses and relations 
 load(['relations_V1_analit_natural_1'],'freq')

fx = freq(1:11:120,2);
ft = freq(1:11,3);

close all
clc
%%%%%%%%%%%%%%%%%%%%% Horizontal
[C,R1,sR1]=graph_motion_resp('resp_1',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,10)
figure(gcf),title('Close frequencies (\gamma = 1)')
[C,R2,sR2]=graph_motion_resp('resp_2',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,20)
[C,R3,sR3]=graph_motion_resp('resp_3',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,30)
[C,R4,sR4]=graph_motion_resp('resp_4',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,40)
[C,R5,sR5]=graph_motion_resp('resp_5',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,50)
figure(gcf),title('Distant frequencies (\gamma = 1)')

[C,R1n,sR1n]=graph_motion_resp('resp_1n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,100)
figure(gcf),title('Close frequencies (\gamma = 1)')
[C,R2n,sR2n]=graph_motion_resp('resp_2n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,20)
[C,R3n,sR3n]=graph_motion_resp('resp_3n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,300)
[C,R4n,sR4n]=graph_motion_resp('resp_4n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,400)
[C,R5n,sR5n]=graph_motion_resp('resp_5n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,500)
figure(gcf),title('Distant frequencies (\gamma = 1)')

[C,R13,sR13]=graph_motion_resp('resp_13',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,1000)
figure(gcf),title('Close frequencies (\gamma = 1/3)')
[C,R23,sR23]=graph_motion_resp('resp_23',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,2000)
[C,R33,sR33]=graph_motion_resp('resp_33',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,3000)
[C,R43,sR43]=graph_motion_resp('resp_43',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,4000)
[C,R53,sR53]=graph_motion_resp('resp_53',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,5000)
figure(gcf),title('Distant frequencies (\gamma = 1/3)')

[C,R13n,sR13n]=graph_motion_resp('resp_13n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,10000)
figure(gcf),title('Close frequencies (\gamma = 1/3)')
[C,R23n,sR23n]=graph_motion_resp('resp_23n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,20000)
[C,R33n,sR33n]=graph_motion_resp('resp_33n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,30000)
[C,R43n,sR43n]=graph_motion_resp('resp_43n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,40000)
[C,R53n,sR53n]=graph_motion_resp('resp_53n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,50000)
figure(gcf),title('Distant frequencies (\gamma = 1/3)')

%%%%%%%%%%%%%%%%%%%%%%%% Vertical
[C,R1v,sR1v]=graph_motion_resp('resp_1v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,10)
figure(gcf),title('Close frequencies (\gamma = 1)')
[C,R2v,sR2v]=graph_motion_resp('resp_2v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,20)
[C,R3v,sR3v]=graph_motion_resp('resp_3v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,30)
[C,R4v,sR4v]=graph_motion_resp('resp_4v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,40)
[C,R5v,sR5v]=graph_motion_resp('resp_5v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,50)
figure(gcf),title('Distant frequencies (\gamma = 1)')

[C,R1nv,sR1nv]=graph_motion_resp('resp_1nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,100)
figure(gcf),title('Close frequencies (\gamma = 1)')
[C,R2nv,sR2nv]=graph_motion_resp('resp_2nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,20)
[C,R3nv,sR3nv]=graph_motion_resp('resp_3n',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,300)
[C,R4nv,sR4nv]=graph_motion_resp('resp_4nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,400)
[C,R5nv,sR5nv]=graph_motion_resp('resp_5nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,500)
figure(gcf),title('Distant frequencies (\gamma = 1)')

[C,R13v,sR13v]=graph_motion_resp('resp_13v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,1000)
figure(gcf),title('Close frequencies (\gamma = 1/3)')
[C,R23v,sR23v]=graph_motion_resp('resp_23v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,2000)
[C,R33v,sR33v]=graph_motion_resp('resp_33v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,3000)
[C,R43v,sR43v]=graph_motion_resp('resp_43v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,4000)
[C,R53v,sR53v]=graph_motion_resp('resp_53v',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,5000)
figure(gcf),title('Distant frequencies (\gamma = 1/3)')

[C,R13nv,sR13nv]=graph_motion_resp('resp_13nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 1.8 Hz)',3,23,10000)
figure(gcf),title('Close frequencies (\gamma = 1/3)')
[C,R23nv,sR23nv]=graph_motion_resp('resp_23nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 3.6 Hz)',3,23,20000)
[C,R33nv,sR33nv]=graph_motion_resp('resp_33nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 5.4 Hz)',3,23,30000)
[C,R43nv,sR43nv]=graph_motion_resp('resp_43nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 7.2 Hz)',3,23,40000)
[C,R53nv,sR53nv]=graph_motion_resp('resp_53nv',[-0.01 0.3 -5 100],'C   (f_x,f_t) = (10.8 cpd, 0 Hz)','Response (Mask f_t = 9 Hz)',3,23,50000)
figure(gcf),title('Distant frequencies (\gamma = 1/3)')

close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% HORIZONTAL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ft = [1.8  3.6  5.4  7.2000  9];
LW = 3,
FS = 23
ejes =[-0.01 0.3 -5/100 1.05];

for i=2:5   % Infomax

textox = 'C_{test}   (f_x,f_t) = (10.8 cpd, 0 Hz)';
textoy = ['Response (Mask f_t = ',num2str(ft(i)),' Hz)'];

R = eval(['0.5*(R',num2str(i),'+R',num2str(i),'n)']);
MM = max(R(1,:));
R = R/MM;
sR = eval(['sqrt(sR',num2str(i),'.^2+sR',num2str(i),'n.^2)/MM']);

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

end

for i=2:5  % Error minimization

textox = 'C_{test}   (f_x,f_t) = (10.8 cpd, 0 Hz)';
textoy = ['Response (Mask f_t = ',num2str(ft(i)),' Hz)'];

R = eval(['0.5*(R',num2str(i),'3+R',num2str(i),'3n)']);
MM = max(R(1,:));
R = R/MM;
sR = eval(['sqrt(sR',num2str(i),'3.^2+sR',num2str(i),'3n.^2)/MM']);

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VERTICAL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=2:5   % Infomax

textox = 'C_{test}   (f_y,f_t) = (10.8 cpd, 0 Hz)';
textoy = ['Response (Mask f_t = ',num2str(ft(i)),' Hz)'];

R = eval(['0.5*(R',num2str(i),'v+R',num2str(i),'nv)']);
MM = max(R(1,:));
R = R/MM;
sR = eval(['sqrt(sR',num2str(i),'v.^2+sR',num2str(i),'nv.^2)/MM']);

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

end

for i=2:5  % Error minimization

textox = 'C_{test}   (f_y,f_t) = (10.8 cpd, 0 Hz)';
textoy = ['Response (Mask f_t = ',num2str(ft(i)),' Hz)'];

R = eval(['0.5*(R',num2str(i),'3v+R',num2str(i),'3nv)']);
MM = max(R(1,:));
R = R/MM;
sR = eval(['sqrt(sR',num2str(i),'3v.^2+sR',num2str(i),'3nv.^2)/MM']);

      figure,errorbar(C,R(1,:),sR(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R(2,:),sR(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R(3,:),sR(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R(4,:),sR(4,:),'ro--','linewidth',LW)
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)

end

tile

if print_figures == 0;

% PRINT     

print('-deps2c','-f1',[out_fold 'resp_motion_h_f2_exp_1.eps'])
print('-deps2c','-f2',[out_fold 'resp_motion_h_f3_exp_1.eps'])
print('-deps2c','-f3',[out_fold 'resp_motion_h_f4_exp_1.eps'])
print('-deps2c','-f4',[out_fold 'resp_motion_h_f5_exp_1.eps'])

print('-deps2c','-f5',[out_fold 'resp_motion_h_f2_exp_13.eps'])
print('-deps2c','-f6',[out_fold 'resp_motion_h_f3_exp_13.eps'])
print('-deps2c','-f7',[out_fold 'resp_motion_h_f4_exp_13.eps'])
print('-deps2c','-f8',[out_fold 'resp_motion_h_f5_exp_13.eps'])

print('-deps2c','-f9',[out_fold 'resp_motion_v_f2_exp_1.eps'])
print('-deps2c','-f10',[out_fold 'resp_motion_v_f3_exp_1.eps'])
print('-deps2c','-f11',[out_fold 'resp_motion_v_f4_exp_1.eps'])
print('-deps2c','-f12',[out_fold 'resp_motion_v_f5_exp_1.eps'])

print('-deps2c','-f13',[out_fold 'resp_motion_v_f2_exp_13.eps'])
print('-deps2c','-f14',[out_fold 'resp_motion_v_f3_exp_13.eps'])
print('-deps2c','-f15',[out_fold 'resp_motion_v_f4_exp_13.eps'])
print('-deps2c','-f16',[out_fold 'resp_motion_v_f5_exp_13.eps'])

end

% if print_figures == 0;
% 
% % PRINT     
% 
% print('-deps2c','-f1',[out_fold 'resp_motion_h_f1_exp_1.eps'])
% print('-deps2c','-f2',[out_fold 'resp_motion_h_f2_exp_1.eps'])
% print('-deps2c','-f3',[out_fold 'resp_motion_h_f3_exp_1.eps'])
% print('-deps2c','-f4',[out_fold 'resp_motion_h_f4_exp_1.eps'])
% print('-deps2c','-f5',[out_fold 'resp_motion_h_f5_exp_1.eps'])
% 
% print('-deps2c','-f6',[out_fold 'resp_motion_h_f1_exp_13.eps'])
% print('-deps2c','-f7',[out_fold 'resp_motion_h_f2_exp_13.eps'])
% print('-deps2c','-f8',[out_fold 'resp_motion_h_f3_exp_13.eps'])
% print('-deps2c','-f9',[out_fold 'resp_motion_h_f4_exp_13.eps'])
% print('-deps2c','-f10',[out_fold 'resp_motion_h_f5_exp_13.eps'])
% 
% print('-deps2c','-f11',[out_fold 'resp_motion_v_f1_exp_1.eps'])
% print('-deps2c','-f12',[out_fold 'resp_motion_v_f2_exp_1.eps'])
% print('-deps2c','-f13',[out_fold 'resp_motion_v_f3_exp_1.eps'])
% print('-deps2c','-f14',[out_fold 'resp_motion_v_f4_exp_1.eps'])
% print('-deps2c','-f15',[out_fold 'resp_motion_v_f5_exp_1.eps'])
% 
% print('-deps2c','-f16',[out_fold 'resp_motion_v_f1_exp_13.eps'])
% print('-deps2c','-f17',[out_fold 'resp_motion_v_f2_exp_13.eps'])
% print('-deps2c','-f18',[out_fold 'resp_motion_v_f3_exp_13.eps'])
% print('-deps2c','-f19',[out_fold 'resp_motion_v_f4_exp_13.eps'])
% print('-deps2c','-f20',[out_fold 'resp_motion_v_f5_exp_13.eps'])
% 
% end