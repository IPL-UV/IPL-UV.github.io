% --------------------------------------------
% DATA FOR SPCA DERIVATION OF MASKING DUE TO MOTION
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% This script shows illustrative clips of VQEG and LIVE (spatially undersampled)
% and the responses of selectd linear sensors to patches coming from these
% videos.
%  VQEG:  http://youtu.be/Ri7Pl-Fu84M
%  LIVE:  http://youtu.be/SwtfFEAlz_M
%  PCA:   http://youtu.be/81_nY5hdbWI
%
% Please see read_and_pca_raw_video_data.m for additional information on
% the video data
% 

% Raw data
load clips_vqeg
M_vqeg = build_achrom_movie(Y_vqeg,min(Y_vqeg(:)),max(Y_vqeg(:)),78*4,1);

load clips_live
M_live = build_achrom_movie(Y_live,min(Y_live(:)),max(Y_live(:)),200*3,2);

% PCA
load('pca_vqeg_live','BBB','spectrum')
M_pca = build_achrom_movie(BBB,min(BBB(:)),max(BBB(:)),171,3);

figure,loglog(spectrum),xlabel('PCA component'),ylabel('Eigenvalue'),title('Eigenspectrum of video patches')

figure,plot([0 1],[0 0],'color',[1 1 1]),set(gca,'color',[1 1 1]),axis equal,axis off,text(0,0.1,'Press any key to continue') 
tile
pause

close all

% Data of selectd coeffcients after the first linear stage in V1
stats_selected_coeff