function [V1,freq]=analytic_spatio_temp_V1(fse,fst,Nx,Nt,N_grid,factor_width) 

% --------------------------------------------------------
% LINEAR MODEL OF SPATIO-TEMPORAL V1
% 
% V. Laparra and J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------------------
%
% This function computes a set of V1-like 3D gabor sensors to be applied to
% Nx*Nx*Nt sequence patches. 
% These should be qualitatively similar to PCA or ICA features of 3D movies.
% The purpose is analyzing the statistics of the linear responses to justify 
%
% fse=48;     % spatial sampling frequency (cycl/deg)
% fst=24;     % temporal sampling frequency (Hz)
% Nx=16;      % size in pixels (square images)
% Nt=32;      % number of frames
%
% N_grid = 11;      % Number of sensors per dimension (odd number ensures sensors in freq=0)
% factor_width =1;  % In principle, the width of the Gaussian windows is the distance 
%                   % between frequencies in the grid. But a factor can be
%                   % applied to this distance to obtain bigger or lower overlap
%
% [V1,freq]=analytic_spatio_temp_V1(fse,fst,Nx,Nt,N_grid,factor_width);
%

[x,y,t,fx,fy,ft] = spatio_temp_freq_domain(Nx,Nx,Nt,fse,fst);

% Set of frequencies

factor = 0.75;     % Factor over the range of possible frequencies (neglect 1-factor high frequencies)
f_x = linspace(-factor*fse/2,factor*fse/2,N_grid);
f_t = linspace(-factor*fst/2,factor*fst/2,N_grid);

% Widths

factor_width = 1;      % Factor over the distance between selected frequencies
delta_fx = factor_width*(f_x(2)-f_x(1));
delta_ft = factor_width*(f_t(2)-f_t(1));

% Phase (determines the location in the domain)
% we choose central position

x0=max(max(x))/2;
y0=max(max(y))/2;
t0=max(max(t))/2;

fase = fx*x0+fy*y0+ft*t0;

% Set of sensors

V1 = zeros(length(f_x)*length(f_x)*length(f_t),Nx*Nx*Nt);
freq = zeros(length(f_x)*length(f_x)*length(f_t),3);

d = 1;
g_a = zeros(Nx,Nx,Nt);
for i = 1:length(f_x)
    for j = 1:length(f_x)
        [i j]
        for k = 1:length(f_t)
            freq(d,:) = [f_x(i) f_x(j) f_t(k)];
            % Sensor in the Fourier domain
            G = sens_gabor3d(Nx,Nx,Nt,fse,fse,fst,f_x(i),f_x(j),f_t(k),delta_fx,delta_fx,delta_ft);
            % vertf3d_3d(G,fse,fst,1001)
            % pause(0.5)
            GG = G.*exp(sqrt(-1)*2*pi*fase);            
            % Sensor in the spatio-temporal domain
            g = real(ifft3(GG,1));            
            % Sensor arranged as sequence patches
            for ii=1:Nt
                g_a(:,:,ii) = sacafot(g,Nx,Nx,ii);
            end
            g_arr = im2colcube(g_a,[Nx Nx],1);
            V1(d,:) = g_arr';
            d = d+1;
        end
    end
end

% save(['/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/motion/v1_analytic_2'],'V1','freq','-v7.3')
% 
% %
% % Analysis of certain sensor
% %
% 
% frec_desired = [f_x(1) f_x(1)]
% [find((freq(:,1) == frec_desired(1)) & freq(:,2) == frec_desired(2)) freq(find(freq(:,1) == frec_desired(1) & freq(:,2) == frec_desired(2)),:)]
% 
% d = 650;
% 
% g_a = V1(d,:);
% g = col2imcube(g_a',[Nx Nt],[Nx Nx]);
% gj = [];
% for i = 1:Nt
%     gj = [gj g(:,:,i)];    
% end
% 
% P = build_achrom_movie(64*(gj-min(min(gj)))/(max(max(gj))-min(min(gj))),0,64,Nx,1000);
% 
% show_fft3(abs(fft3(gj,1)),fse,fst,1001)