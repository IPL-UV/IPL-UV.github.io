% --------------------------------------------
% RELATIONS BETWEEN RESPONSES OF LINEAR MOTION SENSORS
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% This script explores the Correlation and Mutual Information between the
% responses to natural sequences of pairs of linear motion sensors in V1.
% 
% Here we use the linear V1 configuration used in the paper
% (but using this code you can change the parameters of V1).
% 
% You may skip running this script since the results come with the data
% file "motion_data_after_SPCA.zip". 
%
%     relations_V1_analit_natural_1.mat  with variables: 
%            'r'       responses to each sequence in x in samples_vqeg_live.mat (in amplitude)
%            'freq'    frequency meaning of each coeffcient 
%            'MI'      matrix of mutual information between responses i and j
%            'C'      matrix of correlation between responses i and j 
%
%
% NOTE: this function requires to access the sequence data as stored in 
% samples_vqeg_live.mat or less_samples_vqeg_live.mat. These files come
% with the file "motion_data_after_SPCA.zip". If your computer does not
% support the ammount of data in samples_vqeg_live.mat, try less_samples_vqeg_live.mat
% or even_less_samples.mat (in "generating_after_effects.zip")
% 
% If you run this function, you need to provide a path to the folder that
% will contain the result "relations_V1_analit_natural_1.mat"
% (see first line of the code).
%

out_folder = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/after_reproducible/data/data_motion/';

%
% LINEAR MODEL OF V1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Computes a set of 11*11*11 3d-Gabor filters in the range 
% [-18,18] cpd and [-9,9]Hz.
% See the help of analytic_spatio_temp_V1
%

fse=48;     % spatial sampling frequency (cycl/deg)
fst=24;     % temporal sampling frequency (Hz)
Nx=16;      % size in pixels (square images)
Nt=32;      % number of frames

N_grid = 11;      % Number of sensors per dimension (odd number ensures sensors in freq=0)
factor_width =1;  % In principle, the width of the Gaussian windows is the distance 
                  % between frequencies in the grid. But a factor can be
                  % applied to this distance to obtain bigger or lower overlap

[V1,freq]=analytic_spatio_temp_V1(fse,fst,Nx,Nt,N_grid,factor_width);

%
% NATURAL SEQUENCES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(['samples_vqeg_live.mat'],'x');
% load(['less_samples_vqeg_live.mat'],'x');
% load(['even_less_samples.mat'],'x');

xm = mean(x')';
r = V1*(x - repmat(xm,1,length(x(1,:))));
sig_r = std(r')';
r = r./repmat(sig_r,1,length(r(1,:)));

rm = mean(r')';

C = (r-repmat(rm,1,length(r(1,:))))*(r-repmat(rm,1,length(r(1,:))))';

for i = 1:length(r(:,1))
    for j = i:length(r(:,1))
        [i j]
        % figure(100),plot(r(i,:),r(j,:),'b.'),axis equal,axis([-1 1 -1 1]),title([num2str(i),'   ',num2str(j)])
        % pause(0.5)
        co(i,j) = corr(r(i,:)',r(j,:)');
        MI(i,j) = mutual_information_4(r(i,:),r(j,:),101);
        MI(j,i) = MI(i,j);
        co(j,i) = co(i,j);
    end
end

save([out_folder,'relations_V1_analit_natural_1'],'freq','r','MI','C','-v7.3')
