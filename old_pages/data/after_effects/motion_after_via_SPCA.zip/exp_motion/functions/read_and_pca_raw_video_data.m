% --------------------------------------------
% READ RAW VIDEO DATA AND PCA COMPUTATION
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% This script shows you how to collect video data in two different ways:
%
% (1) Video patches: 16*16*32 spatio-temporal patches from raw
%     videos of the LIVE and VQEG databases for the statistical analysis
%     (we also compute the first 5000 Principal Components of the patches)
%
% (2) Short clips from the videos in VQEG and LIVE to make an illustrative
%     video
%
% IMPORTANT: You may skip running this script since the results are in the
% file "motion_data_after_SPCA.zip"
%    
% The original data sources are (please cite them):
%
%    Video Quality Experts Group (VQEG) http://www.its.bldrdoc.gov/vqeg/projects/frtv-phase-i/frtv-phase-i.aspx
%    Laboratory for Image and Video Engineering (LIVE) http://live.ece.utexas.edu/research/quality/live_video.html
%    
% For the user convenience, we already selected the natural and undistorted
% sequences from the above (huge) databases.
% These were stored in a single file that should be downloaded before
% running this script:
%    
% Subset of VQEG and LIVE databases used in our motion experiments
% (available as video data file from the BasicVideoTools site http://isp.uv.es/Basic_Video.html)
%    http://isp.uv.es/code/video_data.rar  
%
% In order to run this script you have to enter (i) the path to the folder with
% the database in video_data.rar, and (ii) the path to the folder you want to store the results.
%    
% (1) Gathering patches
% ---------------------
%
% We read patches from the raw videos and save the samples (vectors) and local
% covariance in these temporary separate files (not provided with the data):
%
%      samples_and_covariance_K.mat      'Y_ref','C','x'   where K = [1 2 3 5 6 7 9 10 13 14 15 18 19 20 21 22]
%      covariances_vqeg.mat              'C_cov'
%      samples_and_covariance_live_K.mat 'Y_ref','C','x'   where K = 1:10
%      covariances_live.mat              'C_cov'
%
% Then, we collect all the samples in a single matrix 'x', compute the global 
% covariance matrix and the global PCA, and store these data in:
%
%      samples_vqeg_live.mat             'x'                       (data)
%      pca_vqeg_live.mat                 'CC','B','BBB','spectrum' (covariance, eigenfunctions, movie with the first 100 eigenfunctions, and eigenspectrum)
%
% Provided in motion_data_after_SPCA.zip
% We also saved subsets from samples_vqeg_live for the users with smaller
% computers:
%
%      less_samples_vqeg_live.mat   (also provided in motion_data_after_SPCA.zip)
%      even_less_samples.mat        (provided in motion_after_div_normaliz.zip)
%  
% (2) Illustrative VQEG and LIVE video clips
% ------------------------------------------
%
% This script also generates two illustrative video clips of both databases.
% They come with the data file motion_data_after_SPCA.zip in the *.mat
% files containing the variables:
%
%      clips_vqeg.mat     'Y_vqeg', 'M'   (sequence with 16 subsequences and a movie-like variable)
%      clips_vqeg.mat     'Y_live', 'M'   (sequence with 9 subsequences and a movie-like variable)
%

source_folder = '/media/raid5/vista/BBDD/Video_Quality';
out_folder = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/after_reproducible/data/data_motion/';

% 
% READ SEQUENCES, GATHER SAMPLES AND COMPUTE COVARIANCE AND PCA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%
%           % 
%  PATCHES  %
%           %
%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VQEG

% 
%  The average luminance is about 110
%
%  The dimension is 16*16*32 = 8192
%

m = 110*ones(8192,1);

x = [];

C_cov = zeros(8192,8192,16);
long = 0;
k=1;
for peli = [2 3 5 6 7 9 10 13 14 15 18 19 20 21 22 1];
  
    peli
    [YUV_ref]=read_vqeg_mg([source_folder,'/VQEG/Reference/src',num2str(peli),'_ref__625.yuv']);

    Y_ref = YUV_ref(:,:,1:3:end);
    clear YUV_ref
    Y_ref = double(Y_ref(30:2:end-30,30:2:end-30,:));    
    
    trozos = 1:32:length(Y_ref(1,1,:));
    
    C = zeros(8192,8192);
    L = length(trozos)-1;
    x = [];
    for i = 1:L
        trozos(i)
        tic
        xx = im2colcube(Y_ref(:,:,trozos(i):trozos(i+1)-1),[16 16],0);
        x_sub = xx(:,1000:50:end);
        clear xx
        if i==1
            media = repmat(m,1,length(x_sub(1,:)));
        end
        x_sub = x_sub - media;
        N = length(x_sub(1,:));
        C = C + x_sub*x_sub'/(L*N);
        long = long + N;
        x = [x x_sub];
        save([out_folder,'samples_and_covariance_',num2str(peli)],'Y_ref','C','x','-v7.3')
        toc        
    end
    C_cov(:,:,k) = C;
    k=k+1;
end

save([out_folder,'covariances_vqeg'],'C_cov','-v7.3')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LIVE

addpath(genpath([source_folder,'/LIVE/']))

bs = [source_folder,'/LIVE/videos/bs/'];   % Arbol
mc = [source_folder,'/LIVE/videos/mc/'];
pa = [source_folder,'/LIVE/videos/pa/'];
pr = [source_folder,'/LIVE/videos/pr/'];
rb = [source_folder,'/LIVE/videos/rb/'];
rh = [source_folder,'/LIVE/videos/rh/'];
sf = [source_folder,'/LIVE/videos/sf/'];
sh = [source_folder,'/LIVE/videos/sh/'];
st = [source_folder,'/LIVE/videos/st/'];
tr = [source_folder,'/LIVE/videos/tr/'];

names = {'bs','mc','pa','pr','rb','rh','sf','sh','st','tr'};
frames = [25,50,25,50,25,25,25,50,25,25];


m = 110*ones(8192,1);

x = [];
long = 0;
C_cov = zeros(8192,8192,10);
k=1;

for i=1:10
     i
     nam =names{i};
     fr = frames(i);
     tray = eval(nam);
     name_original = [nam,'1_', num2str(fr),'fps.yuv'];
     data =  yuv2mov([tray,name_original],768,432,'420');
     
     Y_ref = zeros(432/2,768/2,length(data));
     
     for ii=1:length(data)
         ii
         frame=data(ii).cdata;
         frame = rgb2ycbcr(frame);
         Y_ref(:,:,ii) = double(squeeze(frame(1:2:end,1:2:end,1)));
         %figure(1),colormap gray,imagesc(peli_Y(:,:,ii)),axis off,title(num2str(i))
         %M(ii) = getframe;
     end
     %pause     
     clear data frame
     
    trozos = 1:32:length(Y_ref(1,1,:));
    
    C = zeros(8192,8192);
    L = length(trozos)-1;
    x = [];
    for iii = 1:L
        [i trozos(iii) L]
        tic
        xx = im2colcube(Y_ref(:,:,trozos(iii):trozos(iii+1)-1),[16 16],0);
        x_sub = xx(:,1000:50:end);
        clear xx
        if iii==1
            media = repmat(m,1,length(x_sub(1,:)));
        end
        x_sub = x_sub - media;
        N = length(x_sub(1,:));
        C = C + x_sub*x_sub'/(L*N);
        long = long + N;
        x = [x x_sub];
        save([out_folder,'samples_and_covariance_live_',num2str(i)],'Y_ref','C','x','-v7.3')
        toc        
    end
    C_cov(:,:,k) = C;
    k=k+1;     
     
end

save([out_folder,'covariances_live'],'C_cov','-v7.3')

% LIVE AND VQEG TOGETHER

ind_vqeg=[2:3 5:7 9:10 13:15 18:22];  % First VQEG scene is static (i dont use it)
ind_live=1:10;

xx = [];
for ind = 1:length([ind_live ind_vqeg])-1;
    if ind<=length(ind_live)
       load(['samples_and_covariance_live_',num2str(ind),'.mat'],'x');
       xx = [xx x(:,1:2:end)];
       clear x
    else
       load(['samples_and_covariance_',num2str(ind_vqeg(ind-length(ind_live)+1)),'.mat'],'x');
       xx = [xx x(:,1:2:end)];
       clear x
    end
    [ind length(xx(1,:))]
end
x = xx;
clear xx;
save([out_folder,'samples_vqeg_live.mat'],'x','-v7.3');

%
% PCA OF NATURAL SEQUENCES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

load([out_folder,'covariances_vqeg'])
CC1 = sum(C_cov,3)/length(C_cov(1,1,:));
L1 = length(C_cov(1,1,:));
clear C_cov

load([out_folder,'covariances_live'])
CC2 = sum(C_cov,3)/length(C_cov(1,1,:));
L2 = length(C_cov(1,1,:));
clear C_cov

CC = (L1*CC1 + L2*CC2)/(L1+L2); 
clear CC1 CC2

tic,[B,D]=eigs(CC,5000);toc
spectrum = diag(D);


BBB = zeros(10*16 + 9 +2,10*16 + 9 +2,32);

for fot = 1:32
    
    BB = zeros(16*16,100);
    for i=1:100
        base=col2imcube(B(:,i),[16 32],[16 16]);
        im_base = base(:,:,fot);
        BB(:,i) = im_base(:);
    end
    
    array = disp_patches(BB,10);
    BBB(:,:,fot)=array;
    
    figure(gcf),colormap gray,imagesc(array),axis square,axis off
    M(fot)=getframe;
end

save([out_folder,'pca_vqeg_live'],'CC','B','BBB','spectrum','-v7.3')

%%%%%%%%%%%%%%%%
%              %     
% VIDEO CLIPS  %
%              %
%%%%%%%%%%%%%%%%

% VQEG

k=1;
for peli = [2 3 5 6 7 9 10 13 14 15 18 19 20 21 22 1];
  
    peli
    
    if peli<11
       [YUV_ref]=read_vqeg_mg([source_folder,'/VQEG/Reference/src',num2str(peli),'_ref__625.yuv']);
    else
       [YUV_ref]=read_vqeg_mg([source_folder,'/VQEG/Reference/src',num2str(peli),'_ref__525.yuv']); 
    end
    Y_ref = YUV_ref(:,:,1:3:end);
    clear YUV_ref
    Y_ref = double(Y_ref(30:2:end-30,30:2:end-30,:));    

    eval(['Y_',num2str(k),' = Y_ref(1:78,1:78,1:25);']);
    
    k=k+1;
    
end

Y_vqeg = zeros(78*4,78*4,25);
for i = 1:25
    Y_vqeg(:,:,i) = [Y_1(:,:,i) Y_2(:,:,i) Y_3(:,:,i) Y_4(:,:,i);...
                     Y_5(:,:,i) Y_6(:,:,i) Y_7(:,:,i) Y_8(:,:,i);...
                     Y_9(:,:,i) Y_10(:,:,i) Y_11(:,:,i) Y_12(:,:,i);...
                    Y_13(:,:,i) Y_14(:,:,i) Y_15(:,:,i) Y_16(:,:,i)];
end

M = build_achrom_movie(Y_vqeg,min(Y_vqeg(:)),max(Y_vqeg(:)),78*4,1);
save([out_folder,'clips_vqeg'],'M','Y_vqeg')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LIVE

addpath(genpath([source_folder,'/LIVE/']))

bs = [source_folder,'/LIVE/videos/bs/'];   % Arbol
mc = [source_folder,'/LIVE/videos/mc/'];
pa = [source_folder,'/LIVE/videos/pa/'];
pr = [source_folder,'/LIVE/videos/pr/'];
rb = [source_folder,'/LIVE/videos/rb/'];
rh = [source_folder,'/LIVE/videos/rh/'];
sf = [source_folder,'/LIVE/videos/sf/'];
sh = [source_folder,'/LIVE/videos/sh/'];
st = [source_folder,'/LIVE/videos/st/'];
tr = [source_folder,'/LIVE/videos/tr/'];

names = {'bs','mc','pa','pr','rb','rh','sf','sh','st','tr'};
frames = [25,50,25,50,25,25,25,50,25,25];
k=1;
for i=1:10
     i
     nam =names{i};
     fr = frames(i);
     tray = eval(nam);
     name_original = [nam,'1_', num2str(fr),'fps.yuv'];
     data =  yuv2mov([tray,name_original],768,432);
     
     Y_ref = zeros(432/2,768/2,length(data));
     
     for ii=1:length(data)
         ii
         frame=data(ii).cdata;
         frame = rgb2ycbcr(frame);
         Y_ref(:,:,ii) = double(squeeze(frame(1:2:end,1:2:end,1)));
         %figure(1),colormap gray,imagesc(peli_Y(:,:,ii)),axis off,title(num2str(i))
         %M(ii) = getframe;
     end
     %pause     
     clear data frame
    
    eval(['Y_',num2str(k),' = Y_ref(1:200,1:200,25:50);']);
     
    k=k+1;     
     
end


Y_live = zeros(200*3,200*3,25);
for i = 1:25
    Y_live(:,:,i) = [Y_1(:,:,i) Y_10(:,:,i) Y_3(:,:,i); 
                     Y_4(:,:,i) Y_5(:,:,i) Y_6(:,:,i);
                     Y_7(:,:,i) Y_8(:,:,i) Y_9(:,:,i)];  % I do not show sequence 2 since it is almos static
end

M = build_achrom_movie(Y_live,min(Y_live(:)),max(Y_live(:)),200*3,1);
save([out_folder,'clips_live'],'M','Y_live')
