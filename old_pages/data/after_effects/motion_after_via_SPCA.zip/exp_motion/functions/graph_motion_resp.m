function [C,R2,sR2] = graph_motion_resp(fichero,ejes,textox,textoy,LW,FS,figura)

% GRAPH_MOTION_RESP carga los resultados del fichero que se le pasa
% % (calculado mediante experimento_masking_texturas.m ó experimento_masking_texturas_o.m)
% Y genera las gráficas de 4 formas:
%
%    - Respeustas tal cual
%    - Opcion 1:
%      Pone origen a cero, promedia realizaciones con masking positivo y
%      negativo, y promedia estimulacion positiva y negativa
%    - Opcion 2:
%      Promedia realizaciones con masking positivo y negativo, promedia
%      estimulacion positiva y negativa, y pone origen a cero
%    - Opcion 3:
%      Promedia valor absoluto de masking positivo y negativo, promedia
%      estimulacion positiva y negativa, y pone origen a cero
%
%   [C,R,sR] = graph_motion_resp(fichero,ejes,textox,textoy,LW,FS,figura) 


% Cm=[0 0.02 -0.02 0.04 -0.04 0.06 -0.06 0.08 -0.08];
% Cm=[0 0.03 -0.03 0.06 -0.06 0.09 -0.09 0.12 -0.12];
% 
% 1
% [2 3]
% [4 5]
% [6 7]
% [8 9]

pinta=0;

load(fichero)

   % Respuestas tal cual

        R0=resp_fisio(2,:,1);
        R1a=resp_fisio(2,:,2);
        R1b=resp_fisio(2,:,3);
        R2a=resp_fisio(2,:,4);
        R2b=resp_fisio(2,:,5);
        R3a=resp_fisio(2,:,6);
        R3b=resp_fisio(2,:,7);
        R4a=resp_fisio(2,:,8);
        R4b=resp_fisio(2,:,9);
        
        if pinta
        figure(figura),plot(dat_test(2,1:end),R0,'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,1:end),R2a,'ko--','linewidth',LW)
        hold on,plot(dat_test(2,1:end),(R2b),'bo--','linewidth',LW)
        hold on,plot(dat_test(2,1:end),(R4a),'ro--','linewidth',LW)
        hold on,plot(dat_test(2,1:end),(R4b),'mo--','linewidth',LW),
        title('Tal cual'),
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis([-0.3 0.3 -100 100])
        end
        
   % Asumo respuesta cero en el origen (resto R(11)) 
        
        R0=resp_fisio(2,:,1);
        R1ao=R1a-R1a(11);
        R1bo=R1b-R1b(11);
        R2ao=R2a-R2a(11);
        R2bo=R2b-R2b(11);
        R3ao=R3a-R3a(11);
        R3bo=R3b-R3b(11);
        R4ao=R4a-R4a(11);
        R4bo=R4b-R4b(11);
        
        if pinta
        figure,plot(dat_test(2,1:end),R0,'ko-')
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,1:end),R2ao,'ko--')
        hold on,plot(dat_test(2,1:end),R2bo,'bo--')
        hold on,plot(dat_test(2,1:end),R4ao,'ro--')
        hold on,plot(dat_test(2,1:end),R4bo,'mo--')        
        end
        
  % Promedio las realizaciones a y b
  
        R0=resp_fisio(2,:,1);
        R1om=0.5*(R1ao+R1bo);
        R2om=0.5*(R2ao+R2bo);
        R3om=0.5*(R3ao+R3bo);
        R4om=0.5*(R4ao+R4bo);
        
        if pinta
        figure,plot(dat_test(2,1:end),R0,'ko-')
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,1:end),R2om,'ko--')
        hold on,plot(dat_test(2,1:end),R4om,'ro--')
        end
        
% Promedio estimulacion positiva y negativa

        R0_abs=0.5*(R0(11:end)-fliplr(R0(1:11)));
        R1om_abs=0.5*(R1om(11:end)-fliplr(R1om(1:11)));
        R2om_abs=0.5*(R2om(11:end)-fliplr(R2om(1:11)));
        R3om_abs=0.5*(R3om(11:end)-fliplr(R3om(1:11)));
        R4om_abs=0.5*(R4om(11:end)-fliplr(R4om(1:11)));
        
        if pinta
        figure(figura+1),plot(dat_test(2,11:end),R0_abs,'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,11:end),R1om_abs,'ko--','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R2om_abs,'ko:','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R3om_abs,'ro--','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R4om_abs,'ro:','linewidth',LW),
        title('Opcion 1')
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Promedio de las realizaciones a y b, y las partes positivas y negativas y
% pongo el origen en cero

R1m=0.5*(R1a+R1b);
R2m=0.5*(R2a+R2b);
R3m=0.5*(R3a+R3b);
R4m=0.5*(R4a+R4b);

      if pinta
      figure,plot(dat_test(2,1:end),R0,'ko-')
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,1:end),R2m,'ko--')
        hold on,plot(dat_test(2,1:end),R4m,'ro--')
      end
      
R0_abs=0.5*(abs(R0(11:-1:1))+abs(R0(11:end)));
R1m_abs=0.5*(abs(R1m(11:-1:1))+abs(R1m(11:end)));
R2m_abs=0.5*(abs(R2m(11:-1:1))+abs(R2m(11:end)));
R3m_abs=0.5*(abs(R3m(11:-1:1))+abs(R3m(11:end)));
R4m_abs=0.5*(abs(R4m(11:-1:1))+abs(R4m(11:end)));

     if pinta
      figure,plot(dat_test(2,11:end),R0_abs,'ko-')
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,11:end),R2m_abs,'ko--')
        hold on,plot(dat_test(2,11:end),R4m_abs,'ro--')
     end
     
R0_abs0=R0_abs-R0_abs(1);
R1m_abs0=R1m_abs-R1m_abs(1);
R2m_abs0=R2m_abs-R2m_abs(1);
R3m_abs0=R3m_abs-R3m_abs(1);
R4m_abs0=R4m_abs-R4m_abs(1);

     if pinta
      figure(figura+2),plot(dat_test(2,11:end),R0_abs0,'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,11:end),R1m_abs0,'ko--','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R2m_abs0,'ko:','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R3m_abs0,'ro--','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R4m_abs0,'ro:','linewidth',LW),
        title('Opcion 2')
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
     end
     
% Promedio los valores absolutos de las realizaciones a y b, las
% estimulaciones positivas y negativas y pongo el origen en cero


R1ma=0.5*(abs(R1a)+abs(R1b));
R2ma=0.5*(abs(R2a)+abs(R2b));
R3ma=0.5*(abs(R3a)+abs(R3b));
R4ma=0.5*(abs(R4a)+abs(R4b));

    if pinta 
      figure,plot(dat_test(2,1:end),R0,'ko-')
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,1:end),R2ma,'ko--')
        hold on,plot(dat_test(2,1:end),R4ma,'ro--')
    end
    
R0a_abs=0.5*(abs(R0(11:-1:1))+abs(R0(11:end)));
R1ma_abs=0.5*(abs(R1ma(11:-1:1))+abs(R1ma(11:end)));
R2ma_abs=0.5*(abs(R2ma(11:-1:1))+abs(R2ma(11:end)));
R3ma_abs=0.5*(abs(R3ma(11:-1:1))+abs(R3ma(11:end)));
R4ma_abs=0.5*(abs(R4ma(11:-1:1))+abs(R4ma(11:end)));

R0a_abs2 =    mean([abs(R0(11:end));abs(R0(11:-1:1))]);
R0a_abs2_std = std([abs(R0(11:end));abs(R0(11:-1:1))]);
R1ma_abs2 =    mean([abs(R1a(11:end));abs(R1a(11:-1:1));abs(R1b(11:end));abs(R1b(11:-1:1))]);
R1ma_abs2_std = std([abs(R1a(11:end));abs(R1a(11:-1:1));abs(R1b(11:end));abs(R1b(11:-1:1))]);
R2ma_abs2 =    mean([abs(R2a(11:end));abs(R2a(11:-1:1));abs(R2b(11:end));abs(R2b(11:-1:1))]);
R2ma_abs2_std = std([abs(R2a(11:end));abs(R2a(11:-1:1));abs(R2b(11:end));abs(R2b(11:-1:1))]);
R3ma_abs2 =    mean([abs(R3a(11:end));abs(R3a(11:-1:1));abs(R3b(11:end));abs(R3b(11:-1:1))]);
R3ma_abs2_std = std([abs(R3a(11:end));abs(R3a(11:-1:1));abs(R3b(11:end));abs(R3b(11:-1:1))]);


    if pinta
      figure,plot(dat_test(2,11:end),R0a_abs,'ko-')
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,11:end),R2ma_abs,'ko--')
        hold on,plot(dat_test(2,11:end),R4ma_abs,'ro--')
    end
    
R0a_abs0=R0a_abs-R0a_abs(1);
R1ma_abs0=R1ma_abs-R1ma_abs(1);
R2ma_abs0=R2ma_abs-R2ma_abs(1);
R3ma_abs0=R3ma_abs-R3ma_abs(1);
R4ma_abs0=R4ma_abs-R4ma_abs(1);

R0a_abs02=R0a_abs2-R0a_abs2(1);
R1ma_abs02=R1ma_abs2-R1ma_abs2(1);
R2ma_abs02=R2ma_abs2-R2ma_abs2(1);
R3ma_abs02=R3ma_abs2-R3ma_abs2(1);

      figure(figura+3),plot(dat_test(2,11:end),R0a_abs0,'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,plot(dat_test(2,11:end),R1ma_abs0,'ko--','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R2ma_abs0,'ko:','linewidth',LW)
        hold on,plot(dat_test(2,11:end),R3ma_abs0,'ro--','linewidth',LW)
        % hold on,plot(dat_test(2,11:end),R4ma_abs0,'ro:','linewidth',LW),
        if pinta
        title('Opcion 3')
        end
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)
        
        C = dat_test(2,11:end);
        R = [R0a_abs0;R1ma_abs0;R2ma_abs0;R3ma_abs0];
        R2 = [R0a_abs02;R1ma_abs02;R2ma_abs02;R3ma_abs02];
        sR2 = [R0a_abs2_std;R1ma_abs2_std;R2ma_abs2_std;R3ma_abs2_std];
        
      figure(figura+4),errorbar(C,R2(1,:),sR2(1,:),'ko-','linewidth',LW)
        hold on,plot([-0.3 0.3],[0 0],'b-')
        hold on,plot([0 0],[-100 100],'b-')
        hold on,errorbar(C,R2(2,:),sR2(2,:),'ko--','linewidth',LW)
        hold on,errorbar(C,R2(3,:),sR2(3,:),'ko:','linewidth',LW)
        hold on,errorbar(C,R2(4,:),sR2(4,:),'ro--','linewidth',LW)
        % hold on,plot(dat_test(2,11:end),R4ma_abs0,'ro:','linewidth',LW),
        if pinta
        title('Opcion 3')
        end
        set(gca,'fontsize',FS)
        xlabel(textox,'fontsize',FS)
        ylabel(textoy,'fontsize',FS)
        axis(ejes)        