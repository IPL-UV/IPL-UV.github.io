% --------------------------------------------
% BASIC STATISTICS OF SELECTED RESPONSES OF LINEAR MOTION SENSORS
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% In this script we show the basic behavior (scatterplots and Mutual Information) 
% of pairs of responses of motion sensors as a function of the distance in
% frequency.
%
% As a consequence of the results shown in motion_aftereffect_div_norm.m, 
% We will study the 2D scatter plots of the sensors tuned to these frequencies:
%
%  f_{spatial} = 10.8 cpd    (horizontal and vertical -fx and fy-)
%  ft = [-9 -7.2 -5.4 -3.6 -1.8 0 1.8 3.6 5.4 7.2 9] Hz
%
% NOTE: You have the option of printing representative images 
% (fig 4 of the paper) by choosing print_figures = 1. (see the first 
% line of the code). In this case you have to specify the path where you want 
% the files stored. 
% If you choose print_figures = 0 the program just shows the plots but
% prints nothing.
%

print_figures = 0; 
out_folder = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/after_reproducible/data/data_motion/';

% Load responses and relations 
 load(['relations_V1_analit_natural_1'],'freq','r','MI','C')

fxx = freq(1:11:120,2)';
ftt = freq(1:11,3)';

% Selected coefficients

fx = fxx(9);
ft = ftt(1:11);

index_selected_h = [];
index_selected_v = [];
for ind = 1:length(ft)
        
        index_selected_h = [index_selected_h find( (freq(:,1) == fx(1)) & (freq(:,2) == 0) & (freq(:,3) == ft(ind)) )];
        index_selected_v = [index_selected_v find( (freq(:,1) == 0) & (freq(:,2) == fx(1)) & (freq(:,3) == ft(ind)) )];

end

index_0_h = find( (freq(:,1) == fx(1)) & (freq(:,2) == 0) & (freq(:,3) == 0) );
index_0_v = find( (freq(:,1) == 0) & (freq(:,2) == fx(1)) & (freq(:,3) == 0) );

figure,colormap gray,imagesc(MI(index_selected_h,index_selected_h).^0.2),title('Mutual Information h (exponent 0.2)')
figure,colormap gray,imagesc(abs(C(index_selected_h,index_selected_h)).^1),title('Correlation h ')

figure,colormap gray,imagesc(MI(index_selected_v,index_selected_v).^0.2),title('Mutual Information v (exponent 0.2)')
figure,colormap gray,imagesc(abs(C(index_selected_v,index_selected_v)).^1),title('Correlation v')

pause(1)
close all

rh = r(index_selected_h,:);
rv = r(index_selected_v,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cada = 3;
FS = 21;
LW = 3;
for i=2:5
    figure(i),clf,plot(rh(6,1:cada:end),rh(6+i,1:cada:end),'b.'),
    minimo=-0.12;
    maximo=0.12;
    axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (f_x = 10.8 cpd, f_t = 0 Hz)'],'fontsize',FS),ylabel(['C_{mask} (f_x = 10.8 cpd, f_t = ',num2str(ftt(6+i)),' Hz)'],'fontsize',FS)
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',LW)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',LW)   
    title(['MI = ',num2str(MI(index_0_h,index_selected_h(6+i))),' bits'])
    set(get(gcf,'Children'),'FontSize',FS)
    
    if print_figures == 1
       print('-deps2c',['-f',num2str(i)],[out_fold 'stat_motion_h_f',num2str(i),'p.eps'])
    end
    %pause
end

for i=2:5
    figure(i+5),clf,plot(rh(6,1:cada:end),rh(6-i,1:cada:end),'b.'),
    minimo=-0.12;
    maximo=0.12;
    axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (f_x = 10.8 cpd, f_t = 0 Hz)'],'fontsize',FS),ylabel(['C_{mask} (f_x = 10.8 cpd, f_t = ',num2str(ftt(6-i)),' Hz)'],'fontsize',FS)
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',LW)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',LW)   
    title(['MI = ',num2str(MI(index_0_h,index_selected_h(6-i))),' bits'])
    set(get(gcf,'Children'),'FontSize',FS)
    
    if print_figures == 1    
    print('-deps2c',['-f',num2str(i)],[out_fold 'stat_motion_h_f',num2str(i),'n.eps'])
    end
    %pause
end

for i=2:5
    figure(i+10),clf,plot(rv(6,1:cada:end),rv(6+i,1:cada:end),'b.'),
    minimo=-0.12;
    maximo=0.12;
    axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (f_y = 10.8 cpd, f_t = 0 Hz)'],'fontsize',FS),ylabel(['C_{mask} (f_y = 10.8 cpd, f_t = ',num2str(ftt(6+i)),' Hz)'],'fontsize',FS)
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',LW)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',LW) 
    title(['MI = ',num2str(MI(index_0_v,index_selected_v(6+i))),' bits'])
    set(get(gcf,'Children'),'FontSize',FS)
    if print_figures == 1
        print('-deps2c',['-f',num2str(i)],[out_fold 'stat_motion_v_f',num2str(i),'p.eps'])
    end
    %pause
end

for i=2:5
    figure(i+15),clf,plot(rv(6,1:cada:end),rv(6-i,1:cada:end),'b.'),
    minimo=-0.12;
    maximo=0.12;
    axis([minimo maximo minimo maximo]),axis square,xlabel(['C_{test} (f_y = 10.8 cpd, f_t = 0 Hz)'],'fontsize',FS),ylabel(['C_{mask} (f_y = 10.8 cpd, f_t = ',num2str(ftt(6-i)),' Hz)'],'fontsize',FS)
    hold on,plot([0 0],[minimo maximo],'g-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),0*ones(1,9),'ko-','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.03*ones(1,9)],'ko--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.06*ones(1,9)],'ko:','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[-0.06*ones(1,9)],'ko:','linewidth',LW)    
    hold on,plot(linspace(minimo,maximo,9),[-0.09*ones(1,9)],'ro--','linewidth',LW)
    hold on,plot(linspace(minimo,maximo,9),[0.09*ones(1,9)],'ro--','linewidth',LW)   
    title(['MI = ',num2str(MI(index_0_v,index_selected_v(6-i))),' bits'])
    set(get(gcf,'Children'),'FontSize',FS)
    if print_figures == 1
        print('-deps2c',['-f',num2str(i)],[out_fold 'stat_motion_v_f',num2str(i),'n.eps'])
    end
    %pause
end
tile