function [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat,CRIT,fichero_temporal)

% [dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat,CRIT,results_file)

% P3 = genpath('/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2');
% P4 = genpath('/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_experiment');
% addpath(P3,P4)


   %%%%%%%%%%%%%%%%%%
   %  INICIALIZACION
   %%%%%%%%%%%%%%%%%%

       % Punto origen
            pto = [0 0 0]';
       
       % Parametros
       
           % Num vecinos
               N_datos = length(dat(1,:));         % Number of training samples
               % Number of neighbors (percentage of the training samples, e.g 4%)
               Nv = [round(0.2*N_datos)];
           % Tau
               tau = 0.25;
           % Muelle
               muelle = 0.06;
           % Num bits
               Btotal = 9;
           % Distancia fuera manifold
               dist_fuera = 0.05;
           % Matriz referencia
               Aref = eye(3);
           % Tolerancia en la inversa
               tol=0.005;  
      
       disp('initializing...')
       tic
       [init_param] = initialize_SPCA_2(dat,pto,Nv,tau,muelle,CRIT,Btotal,0,dist_fuera,Aref);
       toc
       disp('initialized!')
      

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%
    %%   TRANSFORM OF TEST DATA (for different masking contrast)
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    Cm=[0 0.03 -0.03 0.06 -0.06 0.09 -0.09 0.12 -0.12];

    resp_fisio=zeros(3,21,length(Cm));
    resp_psico=zeros(1,20,length(Cm));

    
    for jj=1:length(Cm)
        
        puntos_eje_T(:,1) = 0*ones(21,1);
        puntos_eje_T(:,2) = linspace(-0.3,0.3,21); % test
        puntos_eje_T(:,3) = Cm(jj)*ones(21,1);          % enmascarador
        
        dat_test = puntos_eje_T';
        N_samples = length(dat_test(1,:));         % Number of training samples
        
        for nn=1:N_samples
            tic
            [pto_proximo_T2(:,nn) R_T2(:,nn) pto_proximo_T(:,nn) R_T(:,nn)]= spca_2(dat,dat_test(:,nn),init_param,tol) ;
            [nn toc]
        end
        
        
        RR = sqrt(sum(R_T2.^2));
        
        incR=R_T2(:,2:end)-R_T2(:,1:end-1);
        mod_incR=sqrt(sum(incR.^2));
        resp=cumsum(mod_incR);
        
            %         figure,plot(dat_test(2,1:size(R_T2,2)),R_T2(1,1:end),'ko-')
            %         hold on,plot(dat_test(2,1:size(R_T2,2)),R_T2(2,1:end),'ro-')
            %         hold on,plot(dat_test(2,1:size(R_T2,2)),R_T2(3,1:end),'bo-')
            %         
            %         figure,subplot(131),plot(dat_test(2,1:size(R_T2,2)),RR,'ko-'),title('Modulo del vector de respuestas')
            %         subplot(132),plot(dat_test(2,1:size(R_T2,2)),R_T2(2,1:end),'ko-'),title('Respuesta fisiologica (sensor 2 -the correct one?-)')
            %         subplot(133),plot(dat_test(2,1:size(R_T2,2)-1),resp,'ko-'),title('Respuesta psicofisica')
        
        resp_fisio(:,:,jj)=R_T2;
        resp_psico(1,:,jj)=resp;
        
        save(fichero_temporal,'dat_test','resp_fisio','resp_psico')
        
    end
    
    %     figure,plot3(dat(1,:),dat(2,:),dat(3,:),'m.','markersize',0.1), axis square, axis equal
    %     hold on,plot3(dat_test(1,:),dat_test(2,:),dat_test(3,:),'ko','linewidth',5), axis square, axis equal
    %     hold on,plot3(pto(1,:),pto(2,:),pto(3,:),'ro','linewidth',5), axis square, axis equal
    %     plotea_eje(eje_CRIT,'ko-')
    %     hold on,plot3(pto_proximo_T2(1,:),pto_proximo_T2(2,:),pto_proximo_T2(3,:),'go','linewidth',5), axis square, axis equal