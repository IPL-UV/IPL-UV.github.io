% --------------------------------------------
% SPCA DERIVATION OF MASKING DUE TO MOTION:
%
% SPCA RESPONSES OF SENSORS TUNED TO STATIC OBJECTS OF CERTAIN SPATIAL FREQUENCY
% AS A FUNCTION OF THE AMPLITUDE OF THE RESPONSE OF NEIGHBOR SENSORS
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% In this script we compute the SPCA responses to the data of selected coeffcients  
% shown in stats_selected_coef.m 
% We will study the influence of the sensors tuned to these frequencies:
%
%  f_{spatial} = 10.8 cpd    (horizontal and vertical -fx and fy-)
%  ft = [-9 -7.2 -5.4 -3.6 -1.8 0 1.8 3.6 5.4 7.2 9] Hz
%
% on this sensor
%
%  f_{spatial} = 10.8 cpd    (horizontal and vertical -fx and fy-)
%  ft = 0 Hz
%
% We will compute the responses using SPCA with infomax and error minimization criteria. 
%
% This function is just a loop that calls "experimento_masking_texturas"
% that actually calls "spca_2" from the SPCA toolbox required to run this
% experiment! (see the toolbox here http://isp.uv.es/spca).
%
% The similarity between the motion and texture data lead us to use the
% same parameters for the principal curves in SPCA (and hence we use the texture 
% experiment routine) 
%
% NOTE: You have to specify the path where you want the files stored. 
% (see -substitute- the first line in the code)
% 
% Results computed at the time of submission are provided in the subfolder "/exp_motion/motion_results/"
% contained in "motion_after_via_SPCA.zip"
%

destination = '/media/raid5/vista/Papers/aranyas/general_y_analiticas/general/after_reproducible/exp_motion/motion_results/';

% Load responses and relations 
 load(['relations_V1_analit_natural_1'],'freq','r')

fxx = freq(1:11:120,2)';
ftt = freq(1:11,3)';

% Selected coefficients

fx = fxx(9);
ft = ftt(1:11);

index_selected_h = [];
index_selected_v = [];
for ind = 1:length(ft)
        
        index_selected_h = [index_selected_h find( (freq(:,1) == fx(1)) & (freq(:,2) == 0) & (freq(:,3) == ft(ind)) )];
        index_selected_v = [index_selected_v find( (freq(:,1) == 0) & (freq(:,2) == fx(1)) & (freq(:,3) == ft(ind)) )];

end

index_0_h = find( (freq(:,1) == fx(1)) & (freq(:,2) == 0) & (freq(:,3) == 0) );
index_0_v = find( (freq(:,1) == 0) & (freq(:,2) == fx(1)) & (freq(:,3) == 0) );

rh = r(index_selected_h,:);
rv = r(index_selected_v,:);

clear r

cada=50;figure(1),subplot(2,5,1),plot(rh(6,1:cada:end),rh(5,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,2),plot(rh(6,1:cada:end),rh(4,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,3),plot(rh(6,1:cada:end),rh(3,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,4),plot(rh(6,1:cada:end),rh(2,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,5),plot(rh(6,1:cada:end),rh(1,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square

cada=50;figure(1),subplot(2,5,6),plot(rh(6,1:cada:end),rh(7,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,7),plot(rh(6,1:cada:end),rh(8,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,8),plot(rh(6,1:cada:end),rh(9,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,9),plot(rh(6,1:cada:end),rh(10,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(1),subplot(2,5,10),plot(rh(6,1:cada:end),rh(11,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square

cada=50;figure(2),subplot(2,5,1),plot(rv(6,1:cada:end),rv(5,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,2),plot(rv(6,1:cada:end),rv(4,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,3),plot(rv(6,1:cada:end),rv(3,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,4),plot(rv(6,1:cada:end),rv(2,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,5),plot(rv(6,1:cada:end),rv(1,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square

cada=50;figure(2),subplot(2,5,6),plot(rv(6,1:cada:end),rv(7,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,7),plot(rv(6,1:cada:end),rv(8,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,8),plot(rv(6,1:cada:end),rv(9,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,9),plot(rv(6,1:cada:end),rv(10,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square
cada=50;figure(2),subplot(2,5,10),plot(rv(6,1:cada:end),rv(11,1:cada:end),'b.'),axis([-0.4 0.4 -0.4 0.4]),axis square

%%%%%%%
%%%%%%% HORIZONTAL
%%%%%%%

% INFOMAX
cada = 5;
dat_1 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(7,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1,2,[destination,'resp_1']);
dat_2 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(8,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2,2,[destination,'resp_2']);
dat_3 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(9,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3,2,[destination,'resp_3']);
dat_4 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(10,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4,2,[destination,'resp_4']);
dat_5 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(11,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5,2,[destination,'resp_5']);

dat_1n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(5,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1n,2,[destination,'resp_1n']);
dat_2n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(4,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2n,2,[destination,'resp_2n']);
dat_3n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(3,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3n,2,[destination,'resp_3n']);
dat_4n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(2,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4n,2,[destination,'resp_4n']);
dat_5n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(1,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5n,2,[destination,'resp_5n']);

% ERROR
cada = 5;
dat_1 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(7,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1,3,[destination,'resp_13']);
dat_2 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(8,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2,3,[destination,'resp_23']);
dat_3 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(9,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3,3,[destination,'resp_33']);
dat_4 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(10,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4,3,[destination,'resp_43']);
dat_5 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(11,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5,3,[destination,'resp_53']);

dat_1n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(5,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1n,3,[destination,'resp_13n']);
dat_2n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(4,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2n,3,[destination,'resp_23n']);
dat_3n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(3,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3n,3,[destination,'resp_33n']);
dat_4n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(2,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4n,3,[destination,'resp_43n']);
dat_5n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(1,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5n,3,[destination,'resp_53n']);


%%%%%%%
%%%%%%% VERTICAL
%%%%%%%

rh = rv;

% INFOMAX
cada = 5;
dat_1 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(7,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1,2,[destination,'resp_1v']);
dat_2 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(8,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2,2,[destination,'resp_2v']);
dat_3 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(9,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3,2,[destination,'resp_3v']);
dat_4 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(10,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4,2,[destination,'resp_4v']);
dat_5 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(11,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5,2,[destination,'resp_5v']);

dat_1n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(5,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1n,2,[destination,'resp_1nv']);
dat_2n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(4,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2n,2,[destination,'resp_2nv']);
dat_3n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(3,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3n,2,[destination,'resp_3nv']);
dat_4n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(2,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4n,2,[destination,'resp_4nv']);
dat_5n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(1,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5n,2,[destination,'resp_5nv']);

% ERROR
cada = 5;
dat_1 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(7,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1,3,[destination,'resp_13v']);
dat_2 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(8,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2,3,[destination,'resp_23v']);
dat_3 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(9,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3,3,[destination,'resp_33v']);
dat_4 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(10,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4,3,[destination,'resp_43v']);
dat_5 = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(11,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5,3,[destination,'resp_53v']);

dat_1n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(5,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_1n,3,[destination,'resp_13nv']);
dat_2n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(4,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_2n,3,[destination,'resp_23nv']);
dat_3n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(3,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_3n,3,[destination,'resp_33nv']);
dat_4n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(2,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_4n,3,[destination,'resp_43nv']);
dat_5n = [zeros(1,length(rh(6,1:cada:end)));rh(6,1:cada:end);rh(1,1:cada:end)];
[dat_test,resp_fisio,resp_psico]=experimento_masking_texturas(dat_5n,3,[destination,'resp_53nv']);
