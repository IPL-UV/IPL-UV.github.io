% --------------------------------------------
% SPCA DERIVATION OF MASKING DUE TO MOTION (GENERAL DESCRIPTION)
%
% V. Laparra & J. Malo
% Universitat de Valencia. 2014
% --------------------------------------------
%
% In this experiment we computed the non-linear response of SPCA sensors to
% achromatic moving patterns as in the masking experiments of the vision science 
% literature [Morgan06]. Different SPCA optimization criteria were
% used to (1) check the kind of nonlinearities that emerge from data in those
% cases and (2) to test different statistical explanations (organization principles) 
% that may be behind the psychophysical behavior of texture sensors in the
% brain.
%
% To this end, we considered the response of SPCA sensor tuned to a static
% pattern of certain spatial frequency (fx 10.8 cpd, ft = 0 Hz) in different
% conditions:
%   - Response in isolation
%   - Response when other linear sensors (tuned to the same spatial frequency) are active
%         . Close frequency ft = 3.6 Hz   (low to high masking contrast)
%         . Distant frequency ft = 9   Hz (low to high masking contrast)
%
% The software to perform these simulations (reproducing the results in the paper) 
% is organized as follows:
%
%    1- Data for the experiment:  
%
%       *  read_and_pca_raw_video_data.m        
%
%               This script extracts 16x16 patches of 32 frames from the 
%               LIVE and VQEG databases and computes the response of 
%               V1 linear filters on these patches.
%               This gives the data in samples_vqeg_live.mat and the PCA
%               results in pca_vqeg_live.mat
%
%       *  relat_resp_linear_senosrs.m
%
%               This script explores the Correlation and Mutual Information 
%               between the responses to natural sequences of all pairs of linear 
%               motion sensors in the considered V1 model.
%               This generates the V1 model with analytic_spatio_temp_V1.m
%               This gives the responses in the file
%               relations_V1_analit_natural_1.m
%
%       *  stats_selected_coeff.m
%
%               In this script we show the basic behavior (scatter plots and
%               Mutual Information) of the pairs of responses which are 
%               relevant to illustrate the motion aftereffect. 
%               We show the sensor tuned to zero speed together with sensors 
%               tuned to increasing speeds.
%               These are the data to be analyzed with SPCA.
%         
%
%    2- Computation of the responses from the texture data: 
%
%       *  resp_motion.m
%
%               In this script we compute the SPCA responses to the data of 
%               selected coeffcients shown in stats_selected_coef.m 
%               The SPCA parameters are fixed and the experiment launched
%               in: experimento_masking_texturas.m
%
%    3- Show results (responses):
%
%           analysis_resp_motion.m
%                     graph_motion_resp.m
%
% Consideration of 2 sensors (horizontal and vertical), 5 masking stimuli, 
% (only 4 shown in the paper) two motion directions (positive and negative) 
% and 2 criteria, gives rise to 40 files with results:
%
% INFOMAX CRITERION:
%
%  * Test (optimal sensor): (10.8,0,0)  Horizontal motion
%         . Mask 1: (10.8, 0, 1.8)   -> output file: resp_1   
%         . Mask 2: (10.8, 0, 3.6)   -> output file: resp_2   
%         . Mask 3: (10.8, 0, 5.4)   -> output file: resp_3   
%         . Mask 4: (10.8, 0, 7.2)   -> output file: resp_4
%         . Mask 5: (10.8, 0, 9)     -> output file: resp_5
%         . Mask 6: (10.8, 0, -1.8)  -> output file: resp_1n   
%         . Mask 7: (10.8, 0, -3.6)  -> output file: resp_2n   
%         . Mask 8: (10.8, 0, -5.4)  -> output file: resp_3n   
%         . Mask 9: (10.8, 0, -7.2)  -> output file: resp_4n
%         . Mask 10: (10.8, 0,-9)    -> output file: resp_5n
%
%  * Test (optimal sensor): (10.8,0,0)  Vertical motion
%         . Mask 1: (0, 10.8, 1.8)   -> output file: resp_1v   
%         . Mask 2: (0, 10.8, 3.6)   -> output file: resp_2v   
%         . Mask 3: (0, 10.8, 5.4)   -> output file: resp_3v   
%         . Mask 4: (0, 10.8, 7.2)   -> output file: resp_4v
%         . Mask 5: (0, 10.8, 9)     -> output file: resp_5v
%         . Mask 6: (0, 10.8, -1.8)  -> output file: resp_1nv   
%         . Mask 7: (0, 10.8, -3.6)  -> output file: resp_2nv  
%         . Mask 8: (0, 10.8, -5.4)  -> output file: resp_3nv   
%         . Mask 9: (0, 10.8, -7.2)  -> output file: resp_4nv
%         . Mask 10: (0, 10.8,-9)    -> output file: resp_5nv
%
% ERROR MINIMIZATION CRITERION:
%
%  * Test (optimal sensor): (10.8,0,0)  Horizontal motion
%         . Mask 1: (10.8, 0, 1.8)   -> output file: resp_13   
%         . Mask 2: (10.8, 0, 3.6)   -> output file: resp_23   
%         . Mask 3: (10.8, 0, 5.4)   -> output file: resp_33   
%         . Mask 4: (10.8, 0, 7.2)   -> output file: resp_43
%         . Mask 5: (10.8, 0, 9)     -> output file: resp_53
%         . Mask 6: (10.8, 0, -1.8)  -> output file: resp_13n   
%         . Mask 7: (10.8, 0, -3.6)  -> output file: resp_23n   
%         . Mask 8: (10.8, 0, -5.4)  -> output file: resp_33n   
%         . Mask 9: (10.8, 0, -7.2)  -> output file: resp_43n
%         . Mask 10: (10.8, 0,-9)    -> output file: resp_53n
%
%  * Test (optimal sensor): (10.8,0,0)  Vertical motion
%         . Mask 1: (0, 10.8, 1.8)   -> output file: resp_13v   
%         . Mask 2: (0, 10.8, 3.6)   -> output file: resp_23v   
%         . Mask 3: (0, 10.8, 5.4)   -> output file: resp_33v   
%         . Mask 4: (0, 10.8, 7.2)   -> output file: resp_43v
%         . Mask 5: (0, 10.8, 9)     -> output file: resp_53v
%         . Mask 6: (0, 10.8, -1.8)  -> output file: resp_13nv   
%         . Mask 7: (0, 10.8, -3.6)  -> output file: resp_23nv   
%         . Mask 8: (0, 10.8, -5.4)  -> output file: resp_33nv   
%         . Mask 9: (0, 10.8, -7.2)  -> output file: resp_43nv
%         . Mask 10: (0, 10.8,-9)    -> output file: resp_53nv   
%
% In each case 9 contrast (zero, four positive and four negative) in the 
% masking stimuli are considered, and 21 test points per masking contrast, 
% i.e. a total of 189 test points. 
% 
% In a Dell PowerEdge 2900 processor initialization takes 25 secs and 
% transforms take 14 secs/sample, i.e. a total of 45 min per data file
% (these take longer than texture since in that case we took 3d vectors).
% 
% By splitting the experiment in 10 parts (assuming you have 10 processors) 
% the whole experiment will be done in 3 hours.
%
% If you find this slow, think about measuring this psychophysically or
% physiologically...
%

analysis_resp_motion

