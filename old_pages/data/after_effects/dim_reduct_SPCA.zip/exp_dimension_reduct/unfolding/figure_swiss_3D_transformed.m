


clear all
close all

PINTA = 0;
destino = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/figures/';


%%%%%%%%%%%%%%%%

N_data = 3000;          % Number of training samples

criterio = 1;   % metric criterion (1 stands for euclidean metric, 2 stands for infomax, and 3 stands for error minimization)
tol = 0.1;              % tolerance in for the inversion error

Btotal = 7;             % number of bits to be distributed among dimensions.

Nbins = 0;    % Number of bins (resolution) in each dimension e.g. Nbins = [N1, N2, ..., Nd]
DIST = 0;     % Euclidean distance threshold for the "out-of-the-manifold" condition
Aref = 0;     % Reference matrix with the local PCA directions at the origin

Nv = 0.1*N_data;
tau = 0.3;
q  = 0.005;

% load('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/results_swiss_roll_3D_SPCA_mas_samples.mat','Res2')
load('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/results_swiss_roll_3D_SPCA_mas_samples_2.mat','Res2','dat')

X = dat(:,1:10:end);

%%%%%%%%%%%%%%%%%%%
%%% MAPEADOS
%%%%%%%%%%%%%%%%%%%


% XX = X(:,1:4:end);
% 
% options.dims = 2;
% 
% D = zeros(size(XX,2));
% for i = 1:size(XX,2)
%     D(i,:) = sqrt(sum((repmat(XX(:,i),1,size(XX,2))-XX).^2));
% end % Matriz de distancias para el ISOMAP
% 
% for k=2:26
%     [mappedX, mapping] = Isomap_tenen(D, k, options);
%     Res_mapp(k).ISO_Y = mappedX.coords{:};
%     
%     Res_mapp(k).LLE_Y = lle_roweis(XX,k, 2);
%     
%     [mappedX, mapping] = charting(XX', 2, k, 200, 'Matlab');
%      Res_mapp(k).CHART_Y = mappedX';
%     k
% end % aprendiendo mapas de LLE e ISOMAP para distintos vecinos
% 
% 
% for k=2:26
%     figure(1)
%     subplot(5,5,k-1)
%     
%     ind_color = DR_colormap(Res_mapp(k).ISO_Y);
%     hold on
%     for nn = 1:size(ind_color,1)
%         plot(Res_mapp(k).ISO_Y(1,nn),Res_mapp(k).ISO_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
%     end
%     %axis equal
%     
%     if size(ind_color,1) == size(XX,2)
%         figure(2)
%         subplot(5,5,k-1)
%         
%         hold on
%         for nn = 1:size(ind_color,1)
%             plot3(XX(1,nn),XX(2,nn),XX(3,nn),'.','color',ind_color(nn,:),'markersize',20)
%         end
%         axis equal
%         view(3)
%     end
%     
%     figure(3)
%     subplot(5,5,k-1)
%     
%     ind_color = DR_colormap(Res_mapp(k).LLE_Y);
%     hold on
%     for nn = 1:size(ind_color,1)
%         plot(Res_mapp(k).LLE_Y(1,nn),Res_mapp(k).LLE_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
%     end
%     %axis equal
%     
%     if size(ind_color,1) == size(XX,2)
%         figure(4)
%         subplot(5,5,k-1)
%         
%         hold on
%         for nn = 1:size(ind_color,1)
%             plot3(XX(1,nn),XX(2,nn),XX(3,nn),'.','color',ind_color(nn,:),'markersize',20)
%         end
%         axis equal
%         view(3)
%     end
%     
%      figure(5)
%     subplot(5,5,k-1)
%     
%     ind_color = DR_colormap(real(Res_mapp(k).CHART_Y));
%     hold on
%     for nn = 1:size(ind_color,1)
%         plot(Res_mapp(k).CHART_Y(1,nn),Res_mapp(k).CHART_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
%     end
%     %axis equal
%     
%     if size(ind_color,1) == size(XX,2)
%         figure(6)
%         subplot(5,5,k-1)
%         
%         hold on
%         for nn = 1:size(ind_color,1)
%             plot3(XX(1,nn),XX(2,nn),XX(3,nn),'.','color',ind_color(nn,:),'markersize',20)
%         end
%         axis equal
%         view(3)
%     end
% end % mostrando mapas de LLE e ISOMAP para distintos vecinos
% 
% 
% 
% 
% D = zeros(size(X,2));
% for i = 1:size(X,2)
%     D(i,:) = sqrt(sum((repmat(X(:,i),1,size(X,2))-X).^2));
% end % Matriz de distancias para el ISOMAP
% 
% [mappedX, mapping] = Isomap_tenen(D,19, options);
% ISO_Y = mappedX.coords{:};
% 
% LLE_Y = lle_roweis(X, 19, 2);
% 
% [mappedX, mapping] = charting(X', 2, 9, 200, 'Matlab');
% CHART_Y = mappedX';
% 
% save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/mats/exp_results_swiss_3D_varios_metodos_2.mat','Res_mapp','ISO_Y','LLE_Y','CHART_Y')

load('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/mats/exp_results_swiss_3D_varios_metodos_2.mat','Res_mapp','ISO_Y','LLE_Y','CHART_Y')


%%%%%%%%%%%%%%%
%%% MEDIDAS
%%%%%%%%%%%%%%%

% [sm_prec_SPCA_1 sm_recall_SPCA_1 A_SPCA_1] = DR_measures(X,SPCA_1_Y(1:2,:),5);
% [sm_prec_SPCA_2 sm_recall_SPCA_2 A_SPCA_2] = DR_measures(X,SPCA_2_Y(1:2,:),5);
% [sm_prec_SPCA_3 sm_recall_SPCA_3 A_SPCA_3] = DR_measures(X,SPCA_3_Y(1:2,:),5);
%
% [sm_prec_LLE sm_recall_LLE A_SPCA] = DR_measures(X,LLE_Y,5);
% [sm_prec_ISO sm_recall_ISO A_SPCA] = DR_measures(X,ISO_Y,5);


%%%%%%%%%%%%%%%
%%% PLOTEOS
%%%%%%%%%%%%%%%

% ISOMAP

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

ind_color = DR_colormap(ISO_Y);
hold on
for nn = 1:size(ind_color,1)
    plot(ISO_Y(1,nn),ISO_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando ISOMAP dominio transformado 2D
%title('ISOMAP mapping')
axis square
%axis([-25 20 -4 3])
if PINTA,print('-deps2c',[destino 'ISO_transf_swiss_3D.eps']),end

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

hold on
for nn = 1:size(ind_color,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando ISOMAP dominio original 3D
%title('original ISOMAP')
view(3)
axis equal

if PINTA,print('-deps2c',[destino 'ISO_ori_swiss_3D.eps']),end

% LLE

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

ind_color = DR_colormap(LLE_Y);
hold on
for nn = 1:size(ind_color,1)
    plot(LLE_Y(1,nn),LLE_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando LLE dominio transformado 2D
%title('LLE mapping')
axis square
if PINTA,print('-deps2c',[destino 'LLE_transf_swiss_3D.eps']),end


figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');
hold on
for nn = 1:size(ind_color,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando LLE dominio original 3D
view(3)
axis equal
if PINTA,print('-deps2c',[destino 'LLE_ori_swiss_3D.eps']),end

% CHARTING

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');
ind_color = DR_colormap(CHART_Y);
hold on
for nn = 1:size(ind_color,1)
    plot(CHART_Y(1,nn),CHART_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando LLE dominio transformado 2D
%title('CHARTING mapping')
axis square
if PINTA,print('-deps2c',[destino 'CHART_transf_swiss_3D.eps']),end


figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');
hold on
for nn = 1:size(ind_color,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando CHART dominio original 3D
%title('original CHARTING')
view(3)
axis equal
if PINTA,print('-deps2c',[destino 'CHART_ori_swiss_3D.eps']),end

%% SPCA

SPCA_1_Y = Res2(1).R2;
SPCA_2_Y = Res2(2).R2;
SPCA_3_Y = Res2(3).R2;

% SPCA crit  1

aux_SPCA_Y = SPCA_1_Y(1:2,:);

ii1 = find(aux_SPCA_Y(2,:)>10);
aux_SPCA_Y_black = aux_SPCA_Y(:,ii1);

ii = find(aux_SPCA_Y(2,:)<10);
aux_SPCA_Y = aux_SPCA_Y(:,ii);

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

ind_color = DR_colormap(aux_SPCA_Y);
hold on
for nn = 1:size(ind_color,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando SPCA crit 1 dominio transformado 2D
for nn = 1:size(aux_SPCA_Y_black,2)
    plot(aux_SPCA_Y_black(1,nn),aux_SPCA_Y_black(2,nn),'k.','markersize',20)
end % mostrando SPCA crit 1 dominio transformado 2D
%title('SPCA criterium 1 mapping')
axis square
axis([-60 75 -8 10])
if PINTA,print('-deps2c',[destino 'SPCA_1_transf_swiss_3D.eps']),end

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');
hold on
for nn = 1:size(ind_color,1)
    plot3(X(1,ii(nn)),X(2,ii(nn)),X(3,ii(nn)),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando SPCA crit 1 dominio original 3D

for nn = 1:size(aux_SPCA_Y_black,2)
    plot3(X(1,ii1(nn)),X(2,ii1(nn)),X(3,ii1(nn)),'k.','markersize',20)
end % mostrando SPCA crit 1 dominio transformado 2D
%title('original SPCA crit 1')
view(3)
axis equal
if PINTA,print('-deps2c',[destino 'SPCA_1_ori_swiss_3D.eps']),end



% SPCA crit  2

aux_SPCA_Y = SPCA_2_Y(1:2,:);

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

ind_color = DR_colormap(aux_SPCA_Y);
hold on
for nn = 1:size(ind_color,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando SPCA crit 2 dominio transformado 2D
%title('trasnformado SPCA crit 2')
axis square
axis([-60 50 -8 8])
if PINTA,print('-deps2c',[destino 'SPCA_2_transf_swiss_3D.eps']),end

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

hold on
for nn = 1:size(ind_color,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando SPCA crit 2 dominio original 3D
%title('original SPCA crit 2')
view(3)
axis equal
if PINTA,print('-deps2c',[destino 'SPCA_2_ori_swiss_3D.eps']),end

% SPCA crit  3

aux_SPCA_Y = SPCA_3_Y(1:2,:);

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

ind_color = DR_colormap(aux_SPCA_Y);
hold on
for nn = 1:size(ind_color,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando SPCA crit 3 dominio transformado 2D
%title('trasnformado SPCA crit 3')
axis square
axis([-50 60 -8 8])
if PINTA,print('-deps2c',[destino 'SPCA_3_transf_swiss_3D.eps']),end

figure1 = figure
axes1 = axes('Parent',figure1,'YTick',zeros(1,0),'XTick',zeros(1,0),'ZTick',zeros(1,0));
hold(axes1,'all');

hold on
for nn = 1:size(ind_color,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color(nn,:),'markersize',20)
end % mostrando SPCA crit 3 dominio original 3D
%title('original SPCA crit 3')
view(3)
axis equal
if PINTA,print('-deps2c',[destino 'SPCA_3_ori_swiss_3D.eps']),end



