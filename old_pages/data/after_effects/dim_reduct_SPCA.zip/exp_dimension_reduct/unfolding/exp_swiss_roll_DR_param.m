




clear all



load('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/results_swiss_roll_3D_SPCA_mas_samples.mat')


rand('seed',1234)
ind = randperm(size(dat,2));
dat_test = dat(:,ind(8001:end));
dat = dat(:,ind(1:8000));


figure
plot3(dat(1,:),dat(2,:),dat(3,:),'.')
axis equal

LW = 3;
color = [0.8 0.2 0.2];


%% PARAMETERS

pto = [1.5 6.75 2]';



Btotal = 9;
Nbins = [400 100 20];

ddd = squareform((pdist(dat')));
ddd2 = ddd + eye(size(ddd,1))*(max(ddd(:)));
DIST =  max(min(ddd2));
tol = min(min(ddd2));
clear ddd2
clear ddd
Nit = 25;

Aref = [1 0 0;
        0 0 1;
        0 1 0];
a = 0.5;

%% SPCA

RR = [];
ER = [];

criterion = 1;
QS = logspace(-2,0,10);
TAUS = logspace(-2,0,10);
NVS = [500 1000 2000];

qq = 1;
for ind_nv = 1:length(NVS)
    Nv = NVS(ind_nv);
    for ind_q = 1:length(QS)
        q = QS(ind_q);
        for ind_t = 1:length(TAUS)
            tau = TAUS(ind_t);
            
            [RR(qq).init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);
            
            RR(qq).Nv = Nv;
            RR(qq).q = q;
            RR(qq).tau = tau;
            
            ER(ind_nv,ind_q,ind_t) = sum(sqrt(sum(RR(qq).init_param.points_on_PC-dat).^2))/8000;
            RR(qq).ER = ER(ind_nv,ind_q,ind_t);
            
            qq = qq+1;
            [ind_nv ind_q ind_t]
        end
    end
end

figure
imagesc(squeeze(ER(1,:,:)))

figure
imagesc(squeeze(ER(2,:,:)))

figure
pcolor(QS,TAUS,squeeze(ER(3,:,:)))

RR2 = [];
ER2 = [];

criterion = 1;
QS = logspace(-2.2,-1.2,10);
TAUS = logspace(-2.2,-1.2,10);

qq = 1;
for ind_q = 1:length(QS)
    q = QS(ind_q);
    for ind_t = 1:length(TAUS)
        tau = TAUS(ind_t);
        
        [RR2(qq).init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);
        ER2(ind_q,ind_t) = sum(sqrt(sum(RR2(qq).init_param.points_on_PC-dat).^2))/8000;
        qq = qq+1;
        [ind_q ind_t]
    end
end


%% SPCA

RR = [];
ER = [];

criterion = 1;
QS = logspace(-2,0,10);
TAUS = logspace(-2,0,10);
NVS = [500 1000 2000];

qq = 1;
for ind_nv = 1:length(NVS)
    Nv = NVS(ind_nv);
    for ind_q = 1:length(QS)
        q = QS(ind_q);
        for ind_t = 1:length(TAUS)
            tau = TAUS(ind_t);
            
            [RR(qq).init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);
            
            RR(qq).Nv = Nv;
            RR(qq).q = q;
            RR(qq).tau = tau;
            
            ER(ind_nv,ind_q,ind_t) = sum(sqrt(sum(RR(qq).init_param.points_on_PC-dat).^2))/8000;
            RR(qq).ER = ER(ind_nv,ind_q,ind_t);
            
            qq = qq+1;
            [ind_nv ind_q ind_t]
        end
    end
end



RR2 = [];
ER2 = [];

criterion = 1;
QS = logspace(-2.5,-2,20);
TAUS = logspace(-2.5,-2,20);
NVS = [500 1000];

qq = 1;
for ind_nv = 1:length(NVS)
    Nv = NVS(ind_nv);
    for ind_q = 1:length(QS)
        q = QS(ind_q);
        for ind_t = 1:length(TAUS)
            tau = TAUS(ind_t);
            
            [RR2(qq).init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);
            
            RR2(qq).Nv = Nv;
            RR2(qq).q = q;
            RR2(qq).tau = tau;
            
            ER2(ind_nv,ind_q,ind_t) = sum(sqrt(sum(RR2(qq).init_param.points_on_PC-dat).^2))/8000;
            RR2(qq).ER = ER2(ind_nv,ind_q,ind_t);
            
            qq = qq+1;
            [ind_nv ind_q ind_t]
        end
    end
end


QS1 = logspace(-2,0,10);
TAUS1 = logspace(-2,0,10);

QS2 = logspace(-2.5,-2,20);
TAUS2 = logspace(-2.5,-2,20);


mm = min(min(min(ER(1,:,:))),min(min(ER2(1,:,:))))
MM = max(max(max(ER(1,:,:))),max(max(ER2(1,:,:))))

figure
pcolor(QS1,TAUS1,squeeze(ER(1,:,:)))

figure
pcolor(QS2,TAUS2,squeeze(ER2(1,:,:)))


QS2 = logspace(-2.5,-2,20);
TAUS2 = logspace(-2.5,-2,20);


figure
pcolor(QS1,TAUS1,squeeze(ER(2,:,:)))

figure
pcolor(QS2,TAUS2,squeeze(ER2(2,:,:)))





aux = squeeze(ER2(1,:,:));
[xx yy] = find(aux == min(aux(:)));

Nv = 500;
q = 0.0078;
tau =  0.0062;


[init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);
          

figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.','markersize',0.1), axis square, axis equal
plot_axes(init_param,3,1)





aux = squeeze(ER2(2,:,:));
[xx yy] = find(aux == min(aux(:)));

Nv2 = 1000;
q2 = 0.0078;
tau2 = 0.0083;

[init_param] =  initialize_SPCA_2(dat,pto,Nv2,tau2,q2,criterion,Btotal,Nbins,DIST,Aref);
          

figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.','markersize',0.1), axis square, axis equal
plot_axes(init_param,3,1)



figure
imagesc(squeeze(ER(2,:,:)))

figure
pcolor(QS,TAUS,squeeze(ER(3,:,:)))

RR2 = [];
ER2 = [];

criterion = 1;
QS = logspace(-2.2,-1.2,10);
TAUS = logspace(-2.2,-1.2,10);

qq = 1;
for ind_q = 1:length(QS)
    q = QS(ind_q);
    for ind_t = 1:length(TAUS)
        tau = TAUS(ind_t);
        
        [RR2(qq).init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);
        ER2(ind_q,ind_t) = sum(sqrt(sum(RR2(qq).init_param.points_on_PC-dat).^2))/8000;
        qq = qq+1;
        [ind_q ind_t]
    end
end





figure
imagesc(QS,TAUS,ER2)

qq=1


qq = 100*2 + 10 * 3 + 5
figure
RR(qq)
plot3(dat(1,:),dat(2,:),dat(3,:),'.','markersize',0.1), axis square, axis equal
plot_axes(RR(qq).init_param,3,1)



for i1 = 1:5
    for i2 = 1:5
        qq = i1*2+ (i2-1)*20;
figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.','markersize',0.1), axis square, axis equal
plot_axes(RR(qq).init_param,3,1)
    
    end
end
%%

aux = init_param.eucl_PC;
PC = cat(2,aux.pto);

for nn=1:size(PC,2)
    [RES(nn).init_param] =  initialize_SPCA_2(dat,init_param.eucl_PC(nn).pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,init_param.eucl_PC(nn).V_der);
    %     figure,plot(dat(1,:),dat(2,:),'.','markersize',0.1), axis square, axis equal
    %     plot_axes(RES(nn).init_param,3,1)
    nn
end


save('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/RESULTS_exp_swiss_roll_DR_param')
