

%
% SWISS ROLL DIM. REDUCT. EXPERIMENTS WITH NL-PCA [Schulz07], and Local PCs [Ozertem11]
%

%%%% DATOS /media/disk/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments

dat_aux = gipsy_arm(1,1,1,10000,1);

dat = dat_aux;
dat_test = dat_aux(:,1:10:end);

figure, plot3(dat_test(1,:),dat_test(2,:),dat_test(3,:),'b.')
axis equal

%%%% LOCAL PRINCIPAL SURFACES [Ozertem11]  /media/disk/vista/Papers/aranyas/Erdogmus_PCs

sigma=5;
target_dim=2;
pc_1=pc_project_multidim(dat,dat_test,sigma,target_dim);
pc_1=pc_1';

hold on,plot3(pc_1(1,:),pc_1(2,:),pc_1(3,:),'r.')

%%%% NON-LINEAR PCA [Schulz07] /media/disk/vista/Papers/aranyas/JMLR2011/drtoolbox/NLPCA-0.88

n=2;
[ResNLPCA(n).pc, ResNLPCA(n).net, ResNLPCA(n).network] = nlpca(dat,n,'plotting','no','mode','hierarchic');

for n=1:4%DIM
    tic
    [ResNLPCA(n).pc, ResNLPCA(n).net, ResNLPCA(n).network] = nlpca(dat_train,n,'plotting','no','mode','hierarchic');
    toc
end