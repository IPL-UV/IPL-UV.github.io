

clear all
destination_folder = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/exp_dimension_reduct/unfolding';

 rx=1;  % standard deviation of uniform noise along the axes of the 3d space
 ry=1;
 rz=1;
 N_dat=12000;  % Number of samples
 N_turn=1;     % Number of turns

 dat=gipsy_arm(rx,ry,rz,N_dat,N_turn);
 dat_test=dat(:,1:2000);
 dat=dat(:,2001:end);
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       % 
% INITIALIZATION AND TRANSFORM (for the three criteria) %
%                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Appropriate instrumental PC parameters for the swiss roll (obtained by the 
% procedure described in [Laparra et al. IPL Tech Report 2012] http://isp.uv.es/sip/docs/IPL_TR_PCs.pdf)

Nv = 0.1*size(dat,2);   % Number of neighbors 10%
tau = 0.3;              % Step size (in Euclidean units)  
q  = 0.005;             % Stiffness

%% PARAMETERS

Nbins = 0;    % Number of bins (resolution) in each dimension e.g. Nbins = [N1, N2, ..., Nd]
DIST = 0;     % Euclidean distance threshold for the "out-of-the-manifold" condition
Aref = 0;     % Reference matrix with the local PCA directions at the origin

pto=[2.5 6.5 2]';  % origin (a point in the manifold)


Btotal = 7;
tol = 0.1;

%% SPCA

criterion = 2;

[init_param] =  initialize_SPCA_2(dat,pto,Nv,tau,q,criterion,Btotal,Nbins,DIST,Aref);

figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.','markersize',0.1), axis square, axis equal
plot_axes(init_param,3,1)


%%

for nn = 1:size(dat_test,2)
    tic
    [RES.pto_prox2(:,nn) RES.R2(:,nn) RES.pto_prox1(:,nn) RES.R1(:,nn)] ...
        = spca_2(dat,dat_test(:,nn),init_param,tol);
    [nn toc]
    save([destination_folder 'RESULTS_exp_swiss_roll_DR'],'RES')
end

load([destination_folder 'RESULTS_exp_swiss_roll_DR'],'RES')

%% PLOTING

figure,plot(RES.R2(1,:),RES.R2(2,:),'.'),axis equal
figure,plot3(RES.R2(1,:),RES.R2(2,:),RES.R2(3,:),'.'),axis equal

ind_color_SPCA = DR_colormap(RES.R2);

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(dat_test(1,nn),dat_test(2,nn),dat_test(3,nn),'.','color',ind_color_SPCA(nn,:))
end
view(3)
title('Original SPCA')
 axis('equal')

 
figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(RES.R2(1,nn),RES.R2(2,nn),RES.R2(3,nn),'.','color',ind_color_SPCA(nn,:))
end
view(3)
title('Transformed SPCA')
 axis('equal')
 
 