

clear all
close all


% CUERNO 3D

dat_aux = gipsy_arm(1,1,1,1000,1);


figure, plot3(dat_aux(1,:),dat_aux(2,:),dat_aux(3,:),'.')
axis equal


dat = dat_aux;
dat_test = dat_aux(:,1:2:end);

%%%%%%%%%%%%%%%%%%%
% PARAMETERS OF SPCA
%%%%%%%%%%%%%%%%%%%


N_data = length(dat(1,:));          % Number of training samples
N_samples = length(dat_test(1,:));  % Number of test samples

criterio = 2;   % metric criterion (1 stands for euclidean metric, 2 stands for infomax, and 3 stands for error minimization)
tol = 0.1;              % tolerance in for the inversion error

pto = [2.5; 6.5; 2];        % coordinate origin


Btotal = 7;             % number of bits to be distributed among dimensions.

% If zero is given to the following variables, the initialization
% function looks for a default value for them.

Nbins = 0;    % Number of bins (resolution) in each dimension e.g. Nbins = [N1, N2, ..., Nd]
DIST = 0;     % Euclidean distance threshold for the "out-of-the-manifold" condition
Aref = 0;     % Reference matrix with the local PCA directions at the origin

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%   INITIALIZATION (on training data):
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




TAU = 0.002:0.002:0.040;%[0.0025 0.005 0.0075 0.01 0.0125];
Q = 0.005:0.005:0.04;%[0.01 0.03 0.05 0.7 0.9 0.11];
NV = [0.1 0.2];


ERR = zeros(length(NV),length(TAU),length(Q));

criterio = 1;
for ind_Nv = 1:length(NV)
    figure
    Nv = NV(ind_Nv)*N_data;
    kkk=1;
    for ind_tau = 11:length(TAU)
        tau = TAU(ind_tau);

        for ind_q = 1:length(Q)

            q  = Q(ind_q);
            [init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);

            ERR(ind_Nv,ind_tau,ind_q) = sum(sqrt(sum((dat-init_param.points_on_eucl_PC).^2))/size(dat,2));
            [ind_Nv ind_tau ind_q]

            save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/corto_results_swiss_roll_3D_SPCA.mat','ERR')
        end
    end
end

for nn=1:length(NV)
    aux = [];
    aux(:,:) = ERR(nn,:,:); 
    [ind_x(nn) ind_y(nn)] = find(aux==min(aux(:)));
    mmm(nn) = min(aux(:));
end

[TAU(ind_x); Q(ind_y); mmm] 

figure
for nn=1:length(NV)
    aux =[];
    aux(:,:) = 1-(ERR(nn,:,:).^0.1);
    subplot(1,2,nn),imagesc(Q,TAU,aux)
    colorbar
end

%%%%%%%%%%%%%%%%%%%%%

pto = [2.5; 6.5; 2];%dat(:,56);

criterio = 1;

Nv = 0.1*N_data;
tau = 0.04;
q  = 0.02;

tic
[init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);
toc

figure
plot3(dat(1,:),dat(2,:),dat(3,:),'.'), axis square, axis equal
plotea_eje(init_param.eucl_PC,'k.-')
hold on, plot3(pto(1),pto(2),pto(3),'r.','markersize',20)
ERR = sum(sqrt(sum((dat-init_param.points_on_eucl_PC).^2))/size(dat,2));
title(['ERR: ' num2str(ERR) ', t: ' num2str(tau) ', q: ' num2str(q) ', Nv: ' num2str(Nv)])

%%%%%%%%%%%%%%%%

pto = [2.5; 6.5; 2];%dat(:,56);


Nv = 0.1*N_data;
tau = 0.27;
q  = 0.025;


for criterio = 1:3
    [Res2(criterio).init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);

    figure
    plot3(dat(1,:),dat(2,:),dat(3,:),'.'), axis square, axis equal
    plotea_eje(Res2(criterio).init_param.eucl_PC,'k.-')

    tol = 0.1;

    Res2(criterio).R2 = zeros(size(dat_test));
    Res2(criterio).pto_proximo2 = zeros(size(dat_test));
    Res2(criterio).R1 = zeros(size(dat_test));
    Res2(criterio).pto_proximo1 = zeros(size(dat_test));

    for nn=1:size(dat_test,2)
        tic
        [Res2(criterio).pto_proximo2(:,nn) Res2(criterio).R2(:,nn) Res2(criterio).pto_proximo1(:,nn) Res2(criterio).R1(:,nn)] = spca_2(dat,dat_test(:,nn),Res2(criterio).init_param,tol);
        [criterio nn toc]
    end

    save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/demo_swiss_3D_prueba_results.mat','Res2')
    
    figure
    plot3(Res2(criterio).R2(1,:),Res2(criterio).R2(2,:),Res2(criterio).R2(3,:),'.')
end


for criterio=1:3
 figure
    plot3(Res2(criterio).R2(1,:),Res2(criterio).R2(2,:),Res2(criterio).R2(3,:),'.'),axis equal
end



X = dat_test;

%%%%%%%%%%%%%%%%%%%
%%% LLE
%%%%%%%%%%%%%%%%%%%

for k=2:50
    aux_Res(k).LLE_Y = lle(X', 2, k)';%lle_gus(X, k, 2);
    if size(aux_Res(k).LLE_Y,2) == size(X,2)
        [aux_sm_prec(k) aux_sm_recall(k) A_SPCA] = DR_measures(X,aux_Res(k).LLE_Y,5);
    end
    k
end

for k=2:50
    aux_Res_gus(k).LLE_Y = lle_gus(X, k, 2);
    if size(aux_Res_gus(k).LLE_Y,2) == size(X,2)
        [aux_sm_prec_gus(k) aux_sm_recall_gus(k) A_SPCA] = DR_measures(X,aux_Res_gus(k).LLE_Y,5);
    end
    k
end

aux_gus =  aux_sm_prec_gus.*aux_sm_recall_gus;



[ii] = find(aux>0);
aux2 = aux(ii);
[mm ii2] = min(aux2);
k_opt_LLE_2D = ii(ii2);

LLE_Y = lle_gus(X, k_opt_LLE_2D, 2);



for k=2:50
    aux_Res(k).LLE_Y = lle_gus(X, k, 1);
    if size(LLE_Y,2) == size(X,2)
        [aux_sm_prec(k) aux_sm_recall(k) A_SPCA] = DR_measures(X,aux_Res(k).LLE_Y,5);
    end
    k
end
aux =  aux_sm_prec.*aux_sm_recall;
[ii] = find(aux>0);
aux2 = aux(ii);
[mm ii2] = min(aux2);
k_opt_LLE_2D = ii(ii2);

LLE_Y_1D = lle_gus(X, k_opt_LLE_2D, 2);

LLE_Y_1D = lle(X', 1, 10)';

%%%%%%%%%%%%%%%
%%% MEDIDAS
%%%%%%%%%%%%%%%

SPCA_1_Y = Res2(1).R2;
SPCA_2_Y = Res2(2).R2;
SPCA_3_Y = Res2(3).R2;

[sm_prec_SPCA_1 sm_recall_SPCA_1 A_SPCA_1] = DR_measures(X,SPCA_1_Y(1:2,:),5);
[sm_prec_SPCA_2 sm_recall_SPCA_2 A_SPCA_2] = DR_measures(X,SPCA_2_Y(1:2,:),5);
[sm_prec_SPCA_3 sm_recall_SPCA_3 A_SPCA_3] = DR_measures(X,SPCA_3_Y(1:2,:),5);

[sm_prec_LLE sm_recall_LLE A_SPCA] = DR_measures(X,LLE_Y,5);

[sm_prec_SPCA_1_1D sm_recall_SPCA_1_1D A_SPCA_1_1D] = DR_measures(X,SPCA_1_Y(1,:),5);
[sm_prec_SPCA_2_1D sm_recall_SPCA_2_1D A_SPCA_2_1D] = DR_measures(X,SPCA_2_Y(1,:),5);
[sm_prec_SPCA_3_1D sm_recall_SPCA_3_1D A_SPCA_3_1D] = DR_measures(X,SPCA_3_Y(1,:),5);

[sm_prec_LLE_1D sm_recall_LLE_1D A_SPCA_1D] = DR_measures(X,LLE_Y_1D,5);

%%%%%%%%%%%%%%%
%%% PLOTEOS
%%%%%%%%%%%%%%%

% 2D
% LLE
aux_LLE_Y = [];
aux_LLE_Y(1,:) = LLE_Y(1,:)-min(LLE_Y(1,:));
aux_LLE_Y(2,:) = LLE_Y(2,:)-min(LLE_Y(2,:));

ind_color_LLE = [aux_LLE_Y(1,:)/max(aux_LLE_Y(1,:)); aux_LLE_Y(2,:)/max(aux_LLE_Y(2,:)); 0.5*ones(1,size(aux_LLE_Y,2))]';

figure,
for nn = 1:size(ind_color_LLE,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_LLE(nn,:)),title('original LLE')
end

figure,
for nn = 1:size(ind_color_LLE,1)
    hold on
    plot(LLE_Y(1,nn),LLE_Y(2,nn),'.','color',ind_color_LLE(nn,:)),title('transform LLE')
end


title(['LLE - prec: ' num2str(sm_prec_LLE) ', recall: ' num2str(sm_recall_LLE)])

% SPCA crit  1
aux_SPCA_Y = [];
aux_SPCA_Y(1,:) = SPCA_1_Y(1,:)-min(SPCA_1_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_1_Y(2,:)-min(SPCA_1_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),title('original SPCA')
end

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:)),title('transform SPCA')
end


title(['SPCA 1 - prec: ' num2str(sm_prec_SPCA_1) ', recall: ' num2str(sm_recall_SPCA_1)])



% SPCA crit  2

aux_SPCA_Y(1,:) = SPCA_2_Y(1,:)-min(SPCA_2_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_2_Y(2,:)-min(SPCA_2_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),title('original SPCA')
end

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:)),title('transform SPCA')
end


title(['SPCA 2 - prec: ' num2str(sm_prec_SPCA_2) ', recall: ' num2str(sm_recall_SPCA_2)])


% SPCA crit  3

aux_SPCA_Y(1,:) = SPCA_3_Y(1,:)-min(SPCA_3_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_3_Y(2,:)-min(SPCA_3_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),title('original SPCA')
end

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:)),title('transform SPCA')
end


title(['SPCA 3 - prec: ' num2str(sm_prec_SPCA_3) ', recall: ' num2str(sm_recall_SPCA_3)])

%%%%%%%%%%%%%%%
%%% PLOTEOS 1D
%%%%%%%%%%%%%%%

% LLE
aux_LLE_Y =[];
aux_LLE_Y(1,:) = LLE_Y_1D(1,:)-min(LLE_Y_1D(1,:));

ind_color_LLE = [aux_LLE_Y(1,:)/max(aux_LLE_Y(1,:)); aux_LLE_Y(1,:)/max(aux_LLE_Y(1,:)); 0.5*ones(1,size(aux_LLE_Y,2))]';

figure,
for nn = 1:size(ind_color_LLE,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_LLE(nn,:)),title('original LLE')
end

% figure,
% for nn = 1:size(ind_color_LLE,1)
%     hold on
%     plot(aux_LLE_Y(1,nn),'.','color',ind_color_LLE(nn,:)),title('transform LLE')
% end


title(['LLE - prec: ' num2str(sm_prec_LLE_1D) ', recall: ' num2str(sm_recall_LLE_1D)])

% SPCA crit  1

aux_SPCA_Y = [];
aux_SPCA_Y(1,:) = SPCA_1_Y(1,:)-min(SPCA_1_Y(1,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),title('original SPCA')
end

% figure,
% for nn = 1:size(ind_color_SPCA,1)
%     hold on
%     plot(aux_SPCA_Y(1,nn),'.','color',ind_color_SPCA(nn,:)),title('transform SPCA')
% end


title(['SPCA 1 - prec: ' num2str(sm_prec_SPCA_1_1D) ', recall: ' num2str(sm_recall_SPCA_1_1D)])



% SPCA crit  2

aux_SPCA_Y(1,:) = SPCA_2_Y(1,:)-min(SPCA_2_Y(1,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),title('original SPCA')
end

% figure,
% for nn = 1:size(ind_color_SPCA,1)
%     hold on
%     plot(aux_SPCA_Y(1,nn),'.','color',ind_color_SPCA(nn,:)),title('transform SPCA')
% end


title(['SPCA 2 - prec: ' num2str(sm_prec_SPCA_2_1D) ', recall: ' num2str(sm_recall_SPCA_2_1D)])


% SPCA crit  3

aux_SPCA_Y(1,:) = SPCA_3_Y(1,:)-min(SPCA_3_Y(1,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
for nn = 1:size(ind_color_SPCA,1)
    hold on
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),title('original SPCA')
end

% figure,
% for nn = 1:size(ind_color_SPCA,1)
%     hold on
%     plot(aux_SPCA_Y(1,nn),'.','color',ind_color_SPCA(nn,:)),title('transform SPCA')
% end


title(['SPCA 3 - prec: ' num2str(sm_prec_SPCA_3_1D) ', recall: ' num2str(sm_recall_SPCA_3_1D)])





