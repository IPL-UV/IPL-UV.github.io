

clear all


load(['data_swiss_roll_DR'])

rand('seed',1234)
ind = randperm(size(dat,2));
dat_test = dat(:,ind(8001:end));
dat = dat(:,ind(1:8000));

%% LOAD RESULTS

load(['RESULTS_exp_swiss_roll_DR'],'RES')

%load(['unfoldingRESULTS_exp_swiss_roll_DR'],'RES')

%% PLOTING

ind_color_SPCA = DR_colormap(RES.R2);

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(dat_test(1,nn),dat_test(2,nn),dat_test(3,nn),'.','color',ind_color_SPCA(nn,:))
end
view(3)
title({'Data in the input domain';'Color code inherited from the SPCA infomax representation'})
axis('equal')

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(RES.R2(1,nn),RES.R2(2,nn),RES.R2(3,nn),'.','color',ind_color_SPCA(nn,:))
end
view(3)
title({'Data in the response domain (SPCA infomax)';'First dimension: hue change';'Scond dimension: brightness change'})
axis('equal')

tile
