

clear all
close all


% CUERNO 3D

dat_aux = gipsy_arm(1,1,1,10000,1);


figure, plot3(dat_aux(1,:),dat_aux(2,:),dat_aux(3,:),'.')
axis equal


dat = dat_aux;
dat_test = dat_aux(:,1:10:end);

%%%%%%%%%%%%%%%%%%%
% PARAMETERS OF SPCA
%%%%%%%%%%%%%%%%%%%


N_data = length(dat(1,:));          % Number of training samples
N_samples = length(dat_test(1,:));  % Number of test samples

criterio = 2;   % metric criterion (1 stands for euclidean metric, 2 stands for infomax, and 3 stands for error minimization)
tol = 0.1;              % tolerance in for the inversion error

pto = [2.5; 6.5; 2];

Btotal = 7;             % number of bits to be distributed among dimensions.

% If zero is given to the following variables, the initialization
% function looks for a default value for them.

Nbins = 0;    % Number of bins (resolution) in each dimension e.g. Nbins = [N1, N2, ..., Nd]
DIST = 0;     % Euclidean distance threshold for the "out-of-the-manifold" condition
Aref = 0;     % Reference matrix with the local PCA directions at the origin

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%   INITIALIZATION (on training data):
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TAU = 0.01:0.01:0.5;%[0.0025 0.005 0.0075 0.01 0.0125];
Q = 0.0025:0.0025:0.02;%[0.01 0.03 0.05 0.7 0.9 0.11];
NV = [0.05 0.075 0.1 0.15 0.2 0.3];
%ERR = zeros(length(NV),length(TAU),length(Q));

criterio = 1;
for ind_Nv = 1%:length(NV)
    figure
    Nv = NV(ind_Nv)*N_data;
    kkk=1;
    for ind_tau = 1:length(TAU)
        tau = TAU(ind_tau);

        for ind_q = 1:length(Q)

            q  = Q(ind_q);
            [init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);

            Res(ind_tau,ind_q).param_PC = init_param.eucl_PC;
            Res(ind_tau,ind_q).tau = init_param.tau;
            Res(ind_tau,ind_q).q = init_param.q;

            % subplot(length(TAU),length(Q),kkk)
            % kkk=kkk+1;
            % plot3(dat(1,:),dat(2,:),dat(3,:),'.'), axis square, axis equal
            % plotea_eje(init_param.eucl_PC,'k.-')
            % view(2)
            % title(['t: ' num2str(ind_tau) ' q: ' num2str(ind_q)])

            ERR(ind_Nv,ind_tau,ind_q) = sum(sqrt(sum((dat-init_param.points_on_eucl_PC).^2))/size(dat,2));
            [ind_Nv ind_tau ind_q]
            
            save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/results_swiss_roll_3D_SPCA.mat','ERR')
        end
    end
end

% figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.'), axis square, axis equal
% plotea_eje(init_param.PC,'k.-')
% title(['Principal Curve modified metric'])

load('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/results_swiss_roll_3D_SPCA.mat','ERR')

for nn=1:length(NV)
    aux = [];
    aux(:,:) = ERR(nn,:,:); 
    [ind_x(nn) ind_y(nn)] = find(aux==min(aux(:)));
    mmm(nn) = min(aux(:));
end

[TAU(ind_x); Q(ind_y); mmm] 

figure
for nn=1:length(NV)
    aux =[];
    aux(:,:) = 1-(ERR(nn,:,:).^0.1);
    subplot(2,3,nn),imagesc(Q,TAU,aux)
    colormap(gray)
    colorbar
end


%%%%%%%%%%%%%%%%%%%%%
%%% CONCLUSIONES:
%%%  tau =  0.0065, q = 0.0326, Nv = 0.1;
%%%%%%%%%%%%%%%%%%%%


Nv = 0.1*size(dat,2);
tau = 0.3;
q  = 0.005;

for criterio = 1:3
    [Res2(criterio).init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);

    figure
    plot3(dat(1,:),dat(2,:),dat(3,:),'.'), axis square, axis equal
    plotea_eje(Res2(criterio).init_param.eucl_PC,'k.-')

    tol = 0.1;

    Res2(criterio).R2 = zeros(size(dat_test));
    Res2(criterio).pto_proximo2 = zeros(size(dat_test));
    Res2(criterio).R1 = zeros(size(dat_test));
    Res2(criterio).pto_proximo1 = zeros(size(dat_test));

    for nn=1:size(dat_test,2)
        tic
        [Res2(criterio).pto_proximo2(:,nn) Res2(criterio).R2(:,nn) Res2(criterio).pto_proximo1(:,nn) Res2(criterio).R1(:,nn)] = spca_2(dat,dat_test(:,nn),Res2(criterio).init_param,tol);
        [nn toc]
    end


    save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/results_swiss_roll_3D_SPCA_mas_samples_2.mat','Res2','dat')


    figure
    plot3(Res2(criterio).R2(1,:),Res2(criterio).R2(2,:),Res2(criterio).R2(3,:),'.')

end

load('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/results_swiss_roll_3D_SPCA_mas_samples_2.mat','Res2')

for criterio=1:3
 figure
    plot3(Res2(criterio).R2(1,:),Res2(criterio).R2(2,:),Res2(criterio).R2(3,:),'.'),axis equal
end






