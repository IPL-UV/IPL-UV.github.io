
function ind_color = 2D_DR_colormap(aux)

% aux = rand(2,600);
%
% figure
% hold on
% for nn = 1:size(ind_color,1)
%     plot(aux(1,nn),aux(2,nn),'.','color',ind_color(nn,:),'markersize',20)
% end

aux_ISO_Y = [];
A1 = aux(1,:)-min(aux(1,:));
A2 = aux(2,:)-min(aux(2,:));
A1 = A1/max(A1);
A2 = A2/max(A2);

Z1 = [1 1 0.5 0.8 0 0.1];
Z2 = [0.8 0 0.1 0.8 0 0.1];
Z3 = [0.8 0 0.1 1 1 0.5];


[XX YY] = meshgrid([0 1],[1 0.5 0]);

ind_color(:,1) = interp2(XX,YY,reshape(Z1,3,2),A1,A2);
ind_color(:,2) = interp2(XX,YY,reshape(Z2,3,2),A1,A2);
ind_color(:,3) = interp2(XX,YY,reshape(Z3,3,2),A1,A2);



