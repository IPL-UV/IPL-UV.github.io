
function [sm_prec sm_recall A] = DR_measures(X,Y,K)

aux_dat = X';
fid = fopen('input_file.txt','wt');
fprintf(fid,'%f\n',size(aux_dat,2));
fclose(fid);
save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/DR_measures_finl/input_file.txt','aux_dat','-ASCII','-append')

aux_datT = Y';
fid = fopen('output_file.txt','wt');
fprintf(fid,'%f\n',size(aux_datT,2));
fclose(fid);
save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/DR_measures_finl/output_file.txt','aux_datT','-ASCII','-append')


cd('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/DR_measures_finl/')
[QQ dd] = system(['./measure --datafile input_file.txt --projfile output_file.txt --neighbors ' num2str(K)]);
[QQ dd2] = system(['./klmeasure --datafile input_file.txt --projfile output_file.txt --neighbors ' num2str(K)]);

A = sscanf(dd,'%f\n');
A = reshape(A,[9 length(A)/9])';

B = sscanf(dd2(37:end),'%f | %f');

sm_prec = B(1);
sm_recall = B(2);



