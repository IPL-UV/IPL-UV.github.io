

clear all



load('/media/disk/vista/Papers/aranyas/general_y_analiticas/general/SPCA_toolbox_web_2/results_swiss_roll_3D_SPCA_mas_samples.mat')
dat_test = dat(:,1:10:end);


X = dat_test;

%%%%%%%%%%%%%%%%%%%
%%% LLE
%%%%%%%%%%%%%%%%%%%


for k=2:50
    aux_Res(k).LLE_Y = lle(X', 2, k)';%lle_gus(X, k, 2);
    if size(aux_Res(k).LLE_Y,2) == size(X,2)
        [aux_sm_prec(k) aux_sm_recall(k) A_SPCA] = DR_measures(X,aux_Res(k).LLE_Y,5);
    end
    k
end
aux = aux_sm_prec.*aux_sm_recall;

for k=2:50
    aux_Res_roweis(k).LLE_Y = lle_roweis(X, k, 2);%lle_gus(X, k, 2);
    if size(aux_Res_roweis(k).LLE_Y,2) == size(X,2)
        [aux_sm_prec_roweis(k) aux_sm_recall_roweis(k) A_SPCA] = DR_measures(X,aux_Res_roweis(k).LLE_Y,5);
    end
    k
end
aux_roweis = aux_sm_prec_roweis.*aux_sm_recall_roweis;


for k=2:50
    aux_Res_gus(k).LLE_Y = lle_gus(X, k, 2);
    if size(aux_Res_gus(k).LLE_Y,2) == size(X,2)
        [aux_sm_prec_gus(k) aux_sm_recall_gus(k) A_SPCA] = DR_measures(X,aux_Res_gus(k).LLE_Y,5);
    end
    k
end
aux_gus =  aux_sm_prec_gus.*aux_sm_recall_gus;

%%%%%%%%%%%%%%%
%%% MEDIDAS
%%%%%%%%%%%%%%%

SPCA_1_Y = Res2(1).R2;
SPCA_2_Y = Res2(2).R2;
SPCA_3_Y = Res2(3).R2;

% [sm_prec_SPCA_1 sm_recall_SPCA_1 A_SPCA_1] = DR_measures(X,SPCA_1_Y(1:2,:),5);
% [sm_prec_SPCA_2 sm_recall_SPCA_2 A_SPCA_2] = DR_measures(X,SPCA_2_Y(1:2,:),5);
% [sm_prec_SPCA_3 sm_recall_SPCA_3 A_SPCA_3] = DR_measures(X,SPCA_3_Y(1:2,:),5);
% 
% [sm_prec_LLE sm_recall_LLE A_SPCA] = DR_measures(X,LLE_Y,5);


%%%%%%%%%%%%%%%
%%% PLOTEOS
%%%%%%%%%%%%%%%

% LLE

aux_LLE_Y(1,:) = LLE_Y(1,:)-min(LLE_Y(1,:));
aux_LLE_Y(2,:) = LLE_Y(2,:)-min(LLE_Y(2,:));

ind_color_LLE = [aux_LLE_Y(1,:)/max(aux_LLE_Y(1,:)); aux_LLE_Y(2,:)/max(aux_LLE_Y(2,:)); 0.5*ones(1,size(aux_LLE_Y,2))]';

figure,
hold on
for nn = 1:size(ind_color_LLE,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_LLE(nn,:))
end
view(3)
title('original LLE')
 axis('equal')

figure,
hold on
for nn = 1:size(ind_color_LLE,1)
    plot(LLE_Y(1,nn),LLE_Y(2,nn),'.','color',ind_color_LLE(nn,:))
end
title(['LLE - prec: ' num2str(sm_prec_LLE) ', recall: ' num2str(sm_recall_LLE)])
 axis('equal')

% SPCA crit  1

aux_SPCA_Y(1,:) = SPCA_1_Y(1,:)-min(SPCA_1_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_1_Y(2,:)-min(SPCA_1_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:))
end
view(3)
title('original SPCA')
 axis('equal')

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:))
end
axis equal
title(['SPCA 1 - prec: ' num2str(sm_prec_SPCA_1) ', recall: ' num2str(sm_recall_SPCA_1)])
 axis('equal')


% SPCA crit  2

aux_SPCA_Y(1,:) = SPCA_2_Y(1,:)-min(SPCA_2_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_2_Y(2,:)-min(SPCA_2_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
    hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:))
end
view(3)
title('original SPCA')
 axis('equal')
 
 
figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:)),
end
axis equal
title(['SPCA 2 - prec: ' num2str(sm_prec_SPCA_2) ', recall: ' num2str(sm_recall_SPCA_2)])
 axis('equal')

% SPCA crit  3

aux_SPCA_Y(1,:) = SPCA_3_Y(1,:)-min(SPCA_3_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_3_Y(2,:)-min(SPCA_3_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';


figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),
end
view(3)
title('original SPCA')
 axis('equal')


figure
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:))
end
title(['SPCA 3 - prec: ' num2str(sm_prec_SPCA_3) ', recall: ' num2str(sm_recall_SPCA_3)])
 axis('equal')



