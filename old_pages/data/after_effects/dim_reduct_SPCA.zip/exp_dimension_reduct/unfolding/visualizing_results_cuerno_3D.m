


clear all
close all

L = linspace(-2,2,1000);

% CUERNO 3D

p = [0 0.2 0;
    0 0 0.2;
    0 0 0];

C(1,:) = p(1,1) + p(1,2)*L + p(1,3)*L.^2;
C(2,:) = p(2,1) + p(2,2)*L + p(2,3)*L.^2;
C(3,:) = p(3,1) + p(3,2)*L + p(3,3)*L.^2;

C(3,:) = C(2,:).^3;

randn('seed',1)
NN = randn(size(C));

for nn=1:size(C,2)
    dat_aux(:,nn) = C(:,nn) + 0.05*(nn+100)/size(C,2)*NN(:,nn);
end

dat_aux(2:3,:) = dat_aux(2:3,:)/2;

dat = dat_aux;

randn('seed',1)
NN = randn(size(C));

for nn=1:size(C,2)
    dat_aux(:,nn) = C(:,nn) + 0.05*(nn+100)/size(C,2)*NN(:,nn);
end

dat_aux(2:3,:) = dat_aux(2:3,:)/2;
dat_test = dat_aux(:,1:2:end);

%%%%%%%%%%%%%%%%


N_data = length(dat(1,:));          % Number of training samples
N_samples = length(dat_test(1,:));  % Number of test samples

criterio = 2;   % metric criterion (1 stands for euclidean metric, 2 stands for infomax, and 3 stands for error minimization)
tol = 0.1;              % tolerance in for the inversion error

pto = dat(:,1);        % coordinate origin
Btotal = 7;             % number of bits to be distributed among dimensions.

Nbins = 0;    % Number of bins (resolution) in each dimension e.g. Nbins = [N1, N2, ..., Nd]
DIST = 0;     % Euclidean distance threshold for the "out-of-the-manifold" condition
Aref = 0;     % Reference matrix with the local PCA directions at the origin

Nv = 0.1*size(dat,2);
tau = 0.0065;
q  = 0.0326;

% for criterio = 1:3
%     [Res2(criterio).init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);
% 
%     tol = 0.1;
% 
%     Res2(criterio).R2 = zeros(size(dat_test));
%     Res2(criterio).pto_proximo2 = zeros(size(dat_test));
%     Res2(criterio).R1 = zeros(size(dat_test));
%     Res2(criterio).pto_proximo1 = zeros(size(dat_test));
% 
%     for nn=1:size(dat_test,2)
%         tic
%         [Res2(criterio).pto_proximo2(:,nn) Res2(criterio).R2(:,nn) Res2(criterio).pto_proximo1(:,nn) Res2(criterio).R1(:,nn)] = spca_2(dat,dat_test(:,nn),Res2(criterio).init_param,tol);
%         [nn toc]
%     end
% 
%     save('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/exp_results_cuerno_3D_SPCA.mat','Res2')
% end

load('/home/vista/Papers/aranyas/general_y_analiticas/general/SPCA_TNN_experiments/exp_results_cuerno_3D_SPCA.mat','Res2')




X = dat_test;

%%%%%%%%%%%%%%%%%%%
%%% LLE
%%%%%%%%%%%%%%%%%%%

LLE_Y = lle(X', 2, 20)';

%%%%%%%%%%%%%%%
%%% MEDIDAS
%%%%%%%%%%%%%%%

SPCA_1_Y = Res2(1).R2;
SPCA_2_Y = Res2(2).R2;
SPCA_3_Y = Res2(3).R2;

% [sm_prec_SPCA_1 sm_recall_SPCA_1 A_SPCA_1] = DR_measures(X,SPCA_1_Y(1:2,:),5);
% [sm_prec_SPCA_2 sm_recall_SPCA_2 A_SPCA_2] = DR_measures(X,SPCA_2_Y(1:2,:),5);
% [sm_prec_SPCA_3 sm_recall_SPCA_3 A_SPCA_3] = DR_measures(X,SPCA_3_Y(1:2,:),5);
% 
% [sm_prec_LLE sm_recall_LLE A_SPCA] = DR_measures(X,LLE_Y,5);


%%%%%%%%%%%%%%%
%%% PLOTEOS
%%%%%%%%%%%%%%%

% LLE

aux_LLE_Y(1,:) = LLE_Y(1,:)-min(LLE_Y(1,:));
aux_LLE_Y(2,:) = LLE_Y(2,:)-min(LLE_Y(2,:));

ind_color_LLE = [aux_LLE_Y(1,:)/max(aux_LLE_Y(1,:)); aux_LLE_Y(2,:)/max(aux_LLE_Y(2,:)); 0.5*ones(1,size(aux_LLE_Y,2))]';

figure,
hold on
for nn = 1:size(ind_color_LLE,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_LLE(nn,:))
end
title('original LLE')
view(3)
axis('equal')

figure,    
hold on
for nn = 1:size(ind_color_LLE,1)
    plot(LLE_Y(1,nn),LLE_Y(2,nn),'.','color',ind_color_LLE(nn,:)),title('transform LLE')
end
axis('equal')
title(['LLE '])%- prec: ' num2str(sm_prec_LLE) ', recall: ' num2str(sm_recall_LLE)])

% SPCA crit  1

aux_SPCA_Y(1,:) = SPCA_1_Y(1,:)-min(SPCA_1_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_1_Y(2,:)-min(SPCA_1_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),
end
view(3)
axis('equal')
title('original SPCA 1')

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:))
end
title(['SPCA 1 '])%- prec: ' num2str(sm_prec_SPCA_1) ', recall: ' num2str(sm_recall_SPCA_1)])
axis('equal')


% SPCA crit  2

aux_SPCA_Y(1,:) = SPCA_2_Y(1,:)-min(SPCA_2_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_2_Y(2,:)-min(SPCA_2_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:)),
end
title('original SPCA 2')
axis('equal')
view(3)


figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:)),
end
title(['SPCA 2 '])%- prec: ' num2str(sm_prec_SPCA_2) ', recall: ' num2str(sm_recall_SPCA_2)])


% SPCA crit  3

aux_SPCA_Y(1,:) = SPCA_3_Y(1,:)-min(SPCA_3_Y(1,:));
aux_SPCA_Y(2,:) = SPCA_3_Y(2,:)-min(SPCA_3_Y(2,:));

ind_color_SPCA = [aux_SPCA_Y(1,:)/max(aux_SPCA_Y(1,:)); aux_SPCA_Y(2,:)/max(aux_SPCA_Y(2,:)); 0.5*ones(1,size(aux_SPCA_Y,2))]';

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot3(X(1,nn),X(2,nn),X(3,nn),'.','color',ind_color_SPCA(nn,:))
end
title('original SPCA 3')
view(3)
axis('equal')

figure,
hold on
for nn = 1:size(ind_color_SPCA,1)
    plot(aux_SPCA_Y(1,nn),aux_SPCA_Y(2,nn),'.','color',ind_color_SPCA(nn,:))
end
title(['SPCA 3 '])%- prec: ' num2str(sm_prec_SPCA_3) ', recall: ' num2str(sm_recall_SPCA_3)])
axis('equal')


