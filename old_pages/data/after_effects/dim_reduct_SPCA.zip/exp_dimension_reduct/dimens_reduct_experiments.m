%
%  DIMENSIONALITY REDUCTION EXPERIMENTS
%
%  These experiments illustrate the abilities of SPCA to identify the
%  underlying low dimensional structure of a manifold embedded in a higher
%  dimensional space.
%  We perform 2 experiments in the classical noisy Swiss Roll:
%
%    * Visualization of the low dimensional manifold in the response domain
%      identifying the intrinsic coordinates of the latent manifold
%
%    * Projection of the samples into the latent manifold by removing
%      dimensions in the response domain and inverting the result to the
%      input space.
%
%  See details at,
%
%    * show_exp_swiss_roll_DR.m
%    * projection_experiment.m
% 
%  The above scripts load results computed in:
%
%    * exp_swiss_roll_DR.m
%    * projection_exp.m
%
%

clc
disp('  ')
disp('  ')
disp('  DIMENSIONALITY REDUCTION RESULTS: visualization')
disp('  ')
disp('  ')

show_exp_swiss_roll_DR

clc
disp('  ')
disp('  ')
disp('  PRESS ANY KEY TO SHOW DIMENSIONALITY REDUCTION RESULTS: projection onto latent manifold')
disp('  ')
disp('  ')

pause
close all
close all

projection_experiment