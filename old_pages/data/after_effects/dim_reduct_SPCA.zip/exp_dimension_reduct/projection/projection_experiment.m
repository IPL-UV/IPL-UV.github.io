% 
%  PROJECTION EXPERIMENTS
%
%  In this experiment we use the invertibility of SPCA to reveal the latent 
%  manifold in the input space by projecting the data in the response
%  representation and transforming the reduced dimensionality data back
%  into the input space.
%
%  We use a noisy swiss roll in the illustration.
%
%  The procedure (initialization, transform, inverse) and reproduction of 
%  the results is done in:
%
%                       projection_exp.m
%
%  By running this script, and choosing as destination folder 
%
%          .../exp_dimension_reduct/projection/
%              
%  you first obtain the transformed test data
%  according to the different criteria:
%
%   .../exp_dimension_reduct/projection/transf_swiss.mat
%
%  Results are stored in the variable Res2
%
%  and then, the reduced dimensionality inverses are stored in:
%
%   .../exp_dimension_reduct/projection/inverse_swiss_1.mat (unfolding)
%   .../exp_dimension_reduct/projection/inverse_swiss_2.mat (infomax)
%   .../exp_dimension_reduct/projection/inverse_swiss_3.mat (errormin)
%
%  Form these results, figures similar to those in the paper 
%  (up to realization variations) in the paper are reproduced in this
%  script.
%
%

load inverse_swiss_1
load inverse_swiss_2
load inverse_swiss_3
    
color=[0.65 0.65 0.65];
siz=17;
figure(1),set(gcf,'color',[1 1 1]),plot3(inv_R1(1,:),inv_R1(2,:),inv_R1(3,:),'b.','Markersize',siz)
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 30]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=0'})
figure(4),set(gcf,'color',[1 1 1]),
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
plot3(inv_R1(1,:),inv_R1(2,:),inv_R1(3,:),'b.','Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 90]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=0'})

figure(2),set(gcf,'color',[1 1 1]),plot3(inv_R2(1,:),inv_R2(2,:),inv_R2(3,:),'b.','Markersize',siz)
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 30]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1'})
figure(5),set(gcf,'color',[1 1 1]),
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
plot3(inv_R2(1,:),inv_R2(2,:),inv_R2(3,:),'b.','Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 90]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1'})

figure(3),set(gcf,'color',[1 1 1]),plot3(inv_R3(1,:),inv_R3(2,:),inv_R3(3,:),'b.','Markersize',siz)
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 30]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1/3'})
figure(6),set(gcf,'color',[1 1 1]),
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
plot3(inv_R3(1,:),inv_R3(2,:),inv_R3(3,:),'b.','Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 90]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1/3'})

tile

% print('-f100','-depsc2',[destination_folder,'inverse_swiss_1a.eps'])
% print('-f101','-depsc2',[destination_folder,'inverse_swiss_1b.eps'])
% print('-f102','-depsc2',[destination_folder,'inverse_swiss_2a.eps'])
% print('-f103','-depsc2',[destination_folder,'inverse_swiss_2b.eps'])
% print('-f104','-depsc2',[destination_folder,'inverse_swiss_3a.eps'])
% print('-f105','-depsc2',[destination_folder,'inverse_swiss_3b.eps'])
