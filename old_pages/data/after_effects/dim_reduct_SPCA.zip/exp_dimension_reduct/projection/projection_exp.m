% 
%  PROJECTION EXPERIMENTS
%
%  In this experiment we use the invertibility of SPCA to reveal the latent 
%  manifold in the input space by projecting the data in the response
%  representation and transforming the reduced dimensionality data back
%  into the input space.
%
%  We use a noisy swiss roll in the illustration.
%
%  The procedure (initialization, transform, inverse) and reproduction of 
%  the results is done here:
%
%                       projection_exp.m
%
%  Before running this script, you have to choose the destination folder,
%  as for instance (see the second line of the code below):
%
%         destination_folder=' .../exp_dimension_reduct/projection/'
%              
%  By running this script you first obtain the transformed test data
%  (600 samples) according to the different criteria, the results will be
%  stored in:
%
%             ...destination_folder/transf_swiss.mat
%
%  Results are stored in the variable Res2
%
%  and then, the reduced dimensionality inverses are stored in:
%
%   .../exp_dimension_reduct/projection/inverse_swiss_1.mat (unfolding)
%   .../exp_dimension_reduct/projection/inverse_swiss_2.mat (infomax)
%   .../exp_dimension_reduct/projection/inverse_swiss_3.mat (errormin)
%
%  in the variables:
%
%   dat_test  (test data)
%   inv_R1    (reduced dimensionality data using g=0 inverted back to the input space)
%   inv_R2    (reduced dimensionality data using g=1 inverted back to the input space)
%   inv_R3    (reduced dimensionality data using g=1/3 inverted back to the input space)
%
%  Form these results, figures similar to those in the paper 
%  (up to realization variations) in the paper are reproduced in this
%  script.
%  
%  The script projection_experiment.m loads precomputed results and
%  represents the results obtained in a different realization of this
%  script.
%
%  CPU times:
%
%    Transform of each swiss roll sample (with 10000 training samples) takes 
%    20 secs in a Dell Poweredge2900 processor. Inverse takes 6 secs/sample
%    According to this, the experiment for one criterion (600 test samples)
%    takes about 4 hours.
%
%    According to this, the loop for the criteria g=1 and g=1/3 are
%    commented. Uncomment in the loop in case you want to try them.
%    Results using the different criteria are very similar (as shown in the
%    paper or by executing "projection_experiment" or "show_results"). This
%    is consistent with the fact that PDF around the latent manifold is
%    uniform in the swiss roll.
%

clear all
destination_folder = '/media/disk/vista/Papers/aranyas/general_y_analiticas/general/TNN_2012_reproducible/exp_dimension_reduct/projection/';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           % 
% DATA: 3D NOISY SWISS ROLL %
%                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 rx=1;  % standard deviation of uniform noise along the axes of the 3d space
 ry=1;
 rz=1;
 N_dat=10600;  % Number of samples
 N_turn=1;     % Number of turns

 dat=gipsy_arm(rx,ry,rz,N_dat,N_turn);
 dat_test=dat(:,1:600);
 dat=dat(:,601:end);
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       % 
% INITIALIZATION AND TRANSFORM (for the three criteria) %
%                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Appropriate instrumental PC parameters for the swiss roll (obtained by the 
% procedure described in [Laparra et al. IPL Tech Report 2012] http://isp.uv.es/sip/docs/IPL_TR_PCs.pdf)

Nv = 0.1*size(dat,2);   % Number of neighbors 10%
tau = 0.3;              % Step size (in Euclidean units)  
q  = 0.005;             % Stiffness

Btotal = 7;             % number of bits to be distributed among dimensions (just global scaling).

% If zero is given to the following variables, the initialization
% function looks for a default value for them.

Nbins = 0;    % Number of bins (resolution) in each dimension e.g. Nbins = [N1, N2, ..., Nd]
DIST = 0;     % Euclidean distance threshold for the "out-of-the-manifold" condition
Aref = 0;     % Reference matrix with the local PCA directions at the origin


% Initialization and transform of test points for the three criteria

for criterio = 1:3

    pto=[2.5 6.5 2]';  % origin (a point in the manifold)
    
    [Res2(criterio).init_param] = initialize_SPCA_2(dat,pto,Nv,tau,q,criterio,Btotal,Nbins,DIST,Aref);

    figure
    plot3(dat(1,:),dat(2,:),dat(3,:),'.'), axis square, axis equal
    plotea_eje(Res2(criterio).init_param.eucl_PC,'k.-')

    tol = 0.1;    % Tolerance in the inverse (in Euclidean units)

    Res2(criterio).R2 = zeros(size(dat_test));
    Res2(criterio).pto_proximo2 = zeros(size(dat_test));
    Res2(criterio).R1 = zeros(size(dat_test));
    Res2(criterio).pto_proximo1 = zeros(size(dat_test));

    for nn=1:size(dat_test,2)
        tic
        [Res2(criterio).pto_proximo2(:,nn) Res2(criterio).R2(:,nn) Res2(criterio).pto_proximo1(:,nn) Res2(criterio).R1(:,nn)] = spca_2(dat,dat_test(:,nn),Res2(criterio).init_param,tol);
        [nn toc]
    end

    save([destination_folder,'transf_swiss.mat'],'Res2','dat')

    figure
    plot3(Res2(criterio).R2(1,:),Res2(criterio).R2(2,:),Res2(criterio).R2(3,:),'.'),axis equal

end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  % 
% INVERSE (for the three criteria) %
%                                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    crit=1;
    for i=1:size(dat_test,2)
        tic
        [inv_R1(:,i),Aref] = inv_SPCA_2(dat,[Res2(crit).R2(1:2,i);0],Res2(crit).init_param);
        save([destination_folder,'inverse_swiss_1.mat'],'inv_R1','dat_test')
        toc
    end
        
    crit=2;
    for i=1:size(dat_test,2)
        tic
        [inv_R2(:,i),Aref] = inv_SPCA_2(dat,[Res2(crit).R2(1:2,i);0],Res2(crit).init_param);
        save([destination_folder,'inverse_swiss_2.mat'],'inv_R2','dat_test')
        toc
    end
        
    crit=3;
    for i=1:size(dat_test,2)
        tic
        [inv_R3(:,i),Aref] = inv_SPCA_2(dat,[Res2(crit).R2(1:2,i);0],Res2(crit).init_param);
        save([destination_folder,'inverse_swiss_3.mat'],'inv_R3','dat_test')
        toc
    end
 
color=[0.65 0.65 0.65];
siz=17;
figure(1),set(gcf,'color',[1 1 1]),plot3(inv_R1(1,:),inv_R1(2,:),inv_R1(3,:),'b.','Markersize',siz)
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 30]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=0'})
figure(4),set(gcf,'color',[1 1 1]),
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
plot3(inv_R1(1,:),inv_R1(2,:),inv_R1(3,:),'b.','Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 90]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=0'})

figure(2),set(gcf,'color',[1 1 1]),plot3(inv_R2(1,:),inv_R2(2,:),inv_R2(3,:),'b.','Markersize',siz)
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 30]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1'})
figure(5),set(gcf,'color',[1 1 1]),
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
plot3(inv_R2(1,:),inv_R2(2,:),inv_R2(3,:),'b.','Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 90]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1'})

figure(3),set(gcf,'color',[1 1 1]),plot3(inv_R3(1,:),inv_R3(2,:),inv_R3(3,:),'b.','Markersize',siz)
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 30]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1/3'})
figure(6),set(gcf,'color',[1 1 1]),
hold on,plot3(dat(1,1:10:end),dat(2,1:10:end),dat(3,1:10:end),'.','color',color,'Markersize',siz)
plot3(inv_R3(1,:),inv_R3(2,:),inv_R3(3,:),'b.','Markersize',siz)
axis([-10 10 -10 10 0 4]),axis equal,set(gca,'XTick',[],'YTick',[],'ZTick',[]),
view([-56 90]),title({'Reduced dimensionality data in the input space (in blue)';'SPCA \gamma=1/3'})

tile

% print('-f100','-depsc2',[destination_folder,'inverse_swiss_1a.eps'])
% print('-f101','-depsc2',[destination_folder,'inverse_swiss_1b.eps'])
% print('-f102','-depsc2',[destination_folder,'inverse_swiss_2a.eps'])
% print('-f103','-depsc2',[destination_folder,'inverse_swiss_2b.eps'])
% print('-f104','-depsc2',[destination_folder,'inverse_swiss_3a.eps'])
% print('-f105','-depsc2',[destination_folder,'inverse_swiss_3b.eps'])
