
N=30000;
angle = pi*(1.5*rand(1,N/2)-1); height = 5*rand(1,N);
  X = [[cos(angle), -cos(angle)]; height;[ sin(angle), 2-sin(angle)]];
  
dat=X+0.2*rand(size(X));  
  
figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.','markersize',0.1)