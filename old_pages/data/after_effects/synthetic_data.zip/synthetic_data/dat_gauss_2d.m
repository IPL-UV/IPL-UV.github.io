function [dat,C_rot]=dat_gauss_2d(m,C,alfa,N)

% DAT_GAUSS_2D genera N datos gaussianos 2D
% Utiliza una Gaussiana de media, m (vector 2*1), anchuras propias dadas 
% en la matriz de covarianza, C (matriz diagonal 2*2), y girada un angulo 
% alfa, es decir, utiliza la matriz de covarianza:
%
%     C_rot=R(alfa)*C*R(alfa)'
%
% donde R=matriz_rotacion_2d(alfa);
%
% USO: [dat,C_rot]=dat_gauss_2d(m,C,alfa,N);
%


R=matriz_rotacion_2d(alfa);
C_rot=R*C*R';
dat = mvnrnd(m',C_rot,N)';
