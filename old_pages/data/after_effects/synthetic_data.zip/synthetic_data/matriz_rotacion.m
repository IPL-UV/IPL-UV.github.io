function R=matriz_rotacion_3d(a1,a2,a3)

% MATRIZ_ROTACION_3D calcula una matriz de rotacion segun los angulos
% a1, a2 y a3 (en radianes) entorno a los ejes 1, 2 y 3 calculadas en 
% el orden 1, 2, 3.
%
% R=matriz_rotacion_3D(a1,a2,a3)

R3=[cos(a3) -sin(a3) 0;sin(a3) cos(a3) 0;0 0 1];
R2=[cos(a2) 0 -sin(a2);0 1 0;sin(a2) 0 cos(a2)];
R1=[1 0 0;0 cos(a1) -sin(a1);0 sin(a1) cos(a1)];

R=R3*R2*R1;

