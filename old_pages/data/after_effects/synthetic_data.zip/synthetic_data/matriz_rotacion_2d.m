function R=matriz_rotacion_2d(a3)

% MATRIZ_ROTACION_2D calcula una matriz de rotacion segun el angulo
% alfa (en radianes).
%
% R=matriz_rotacion_2D(alfa)

R=[cos(a3) -sin(a3);sin(a3) cos(a3)];

