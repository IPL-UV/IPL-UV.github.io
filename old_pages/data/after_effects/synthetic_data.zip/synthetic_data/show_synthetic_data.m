
%
%  SHOW SYNTHETIC DATA
%
%  This script describes how to use the data generation routines that come
%  with the SPCA toolbox
%
%  This release of the SPCA toolbox comes with two synthetic data
%  generation routines:
%
%   * 3d noisy swiss roll: gypsy_arm.m
%
%   * 2d noisy manifold curved along a spiral principal curve with
%     different marginal PDFs along the direction perpendicular to the
%     principal curve: mani_cuerno_7.m
%
%  

%
% 3D NOISY SWISS ROLL 
%

 rx=1;  % standard deviation of uniform noise along the axes of the 3d space
 ry=1;
 rz=1;
 N_dat=5000;  % Number of samples
 N_turn=1;    % Number of turns

 dat=gipsy_arm(rx,ry,rz,N_dat,N_turn);
 dat_no_noise=gipsy_arm(0,0,0,N_dat,N_turn);
 
 figure,plot3(dat(1,:),dat(2,:),dat(3,:),'b.'),axis equal
 view([-30 34])
 title({'NOISY SWISS ROLL'})
 
%
% 2D NOISY MANIFOLD CURVED ALONG A SPIRAL PRINCIPAL CURVE
%

load(['data_Shrimp_2D'])
 
figure,plot(dat(1,:),dat(2,:),'b.'),axis equal
title({'SPIRAL DATA:';'2d noisy manifold curved along an spiral'})
  
tile