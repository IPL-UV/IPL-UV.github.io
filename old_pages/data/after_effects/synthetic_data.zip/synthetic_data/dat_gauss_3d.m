function [dat,C_rot]=dat_gauss_3d(m,C,a1,a2,a3,N)

% DAT_GAUSS_3D genera N datos gaussianos 3D
% Utiliza una Gaussiana de media, m (vector 3*1), anchuras propias dadas 
% en la matriz de covarianza, C (matriz diagonal 3*3), y girada unos angulos 
% a1, a2, a3 (en radianes), es decir, utiliza la matriz de covarianza:
%
%     C_rot=R(a1,a2,a3)*C*R(a1,a2,a3)'
%
% donde R=matriz_rotacion_3d(a1,a2,a3);
%
% USO: [dat,C_rot]=dat_gauss_3d(m,C,a1,a2,a3,N);
%


R=matriz_rotacion_3d(a1,a2,a3);
C_rot=R*C*R';
dat = mvnrnd(m',C_rot,N)';
