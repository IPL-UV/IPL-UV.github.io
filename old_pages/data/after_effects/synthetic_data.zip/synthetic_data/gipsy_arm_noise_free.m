% dat = gipsy_arm_noise_free(rx,ry,rz,N_datos)
%   rx, ry, rz = desviaciones en sus respectivos ejes
%   N_datos = número de datos
%   vueltas = numero de vueltas
%   eg:
%   rx=1;
%   ry=1;
%   rz=1;
%   N_datos=10000;
% dat=gipsy_arm(1,1,1,10000,1)

function dat_v = gipsy_arm_noise_free(rx,ry,rz,N_datos,vueltas)

tt0 = (vueltas*pi)*(1+2*[0:0.005:1]); 
hh = [0:0.00005:1]*3; %  tt0 = (3*pi/2)*(1+2*[0:0.02:1]); hh = [0:0.125:1]*30;
xx = (tt0.*cos(tt0))'*ones(size(hh));
yy = ones(size(tt0))'*hh;
zz = (tt0.*sin(tt0))'*ones(size(hh));
cc = tt0'*ones(size(hh));

[L,H]=size(xx);
k=1;
dat=zeros(3,L*H);
for i=1:L
    for j=1:H
        dat(2,k)=xx(i,j);
        dat(3,k)=yy(i,j);
        dat(1,k)=zz(i,j);
        k=k+1;
    end
end


dat_v=dat;


