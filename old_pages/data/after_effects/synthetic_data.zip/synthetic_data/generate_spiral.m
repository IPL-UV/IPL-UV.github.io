%
% This script generates samples from the 2d spiral manifold described in the
% papers:
%
%   - Nonlinearities and adaptation of color vision from 
%     Sequential Principal Curves Analysis. Neural Comp. 2012
%
%   - Sequential Principal Curves Analysis with Local Metric
%     submitted 2012
%
% using the function "mani_cuerno_7.m"
% 
% The parameters used here are the same as those used to generate
% demo_toy_data.mat in the SPCA toolbox folder

Ntrain = 13000;
Ntest = 500;
N_datos = Ntrain+Ntest;     % Number of data (both training and testing)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

porc=0.6;
porc2=0.2;
gamma1=0.4;
gamma2=6;

% datos_cuerno_7
[datos,datos_PC,idx1,idx2] = mani_cuerno_7(N_datos,porc,porc2,gamma1,gamma2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,plot(datos(1,:),datos(2,:),'.')

[HH RR] = hist3(datos',[31 31]);
% figure,contour(RR{1},RR{2},HH',10)

r = randperm(size(datos,2));
dat_test = datos(:,r(1:Ntest));
dat = datos(:,r(Ntest:end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% save('/home/vista/Papers/aranyas/general_y_analiticas/general/NECO_2011_experiments/cuerno_reproducible_results/datos_cuerno_7_real_2','dat','dat_test')
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

