function dat_v=gipsy_arm(rx,ry,rz,N_datos,vueltas)

%
% GIPSY_ARM draws 3d noisy samples from a 2d Swiss Roll embbeded in a 3d space
%
%   rx, ry, rz = standard deviation of uniform noise along the axes of the
%                3d space
%   N_dat = number of samples
%   N_turns = number of turns
%
%   eg:
%   rx=1;
%   ry=1;
%   rz=1;
%   N_dat=3000;
%   N_turn=1;
%
% dat=gipsy_arm(rx,ry,rz,N_dat,N_turn);

tt0 = (vueltas*pi)*(1+2*[0:0.005:1]); 
hh = [0:0.00005:1]*3; %  tt0 = (3*pi/2)*(1+2*[0:0.02:1]); hh = [0:0.125:1]*30;
xx = (tt0.*cos(tt0))'*ones(size(hh));
yy = ones(size(tt0))'*hh;
zz = (tt0.*sin(tt0))'*ones(size(hh));
cc = tt0'*ones(size(hh));

[L,H]=size(xx);
k=1;
dat=zeros(3,L*H);
for i=1:L
    for j=1:H
        dat(2,k)=xx(i,j);
        dat(3,k)=yy(i,j);
        dat(1,k)=zz(i,j);
        k=k+1;
    end
end

%figure,plot3(dat(1,:),dat(2,:),dat(3,:),'.'),xlabel('x'),ylabel('y')

dat_v=[];
if (N_datos>length(dat))
    for qq=1:length(dat):N_datos
        dat_v(:,qq:qq+length(dat)-1)=dat+[rx*rand(1,length(dat));ry*rand(1,length(dat));rz*rand(1,length(dat))];
    end
    dat_v(:,end+1:N_datos)=dat(:,round(length(dat_v)*rand(1,N_datos-length(dat_v))))+[rx*rand(1,N_datos-length(dat_v));ry*rand(1,N_datos-length(dat_v));rz*rand(1,N_datos-length(dat_v))];
else
    dat_v(:,1:N_datos)=dat(:,round(length(dat)*rand(1,N_datos))+1)+[rx*rand(1,N_datos);ry*rand(1,N_datos);rz*rand(1,N_datos)];
end

%figure,plot3(dat_v(1,:),dat_v(2,:),dat_v(3,:),'.'),xlabel('x'),ylabel('y')